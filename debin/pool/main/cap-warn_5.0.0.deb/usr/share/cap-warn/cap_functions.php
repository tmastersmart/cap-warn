<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.

function haversine($lat1, $lon1, $lat2, $lon2) {
    $R = 3959; // miles
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);

    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}


function parseNhcCycloneXml($xmlString) {
    $xml = simplexml_load_string($xmlString);
    $xml->registerXPathNamespace('nhc', 'http://www.nhc.noaa.gov');

    $cyclones = [];

    foreach ($xml->xpath('//nhc:Cyclone') as $c) {
        $cyclones[] = [
            'center'    => (string)$c->center,
            'type'      => (string)$c->type,
            'name'      => (string)$c->name,
            'wallet'    => (string)$c->wallet,
            'atcf'      => (string)$c->atcf,
            'datetime'  => (string)$c->datetime,
            'movement'  => (string)$c->movement,
            'pressure'  => (string)$c->pressure,
            'wind'      => (string)$c->wind,
            'headline'  => (string)$c->headline,
        ];
    }

    return $cyclones;
}

function filterActiveCyclones($cyclones) {
    $active = [];

    foreach ($cyclones as $c) {
        $wind = intval($c['wind']);
        $headline = strtoupper($c['headline']);
        $type = strtoupper($c['type']);

        if ($wind === 0) continue;
        if (str_contains($headline, 'DISSIPATED')) continue;
        if (str_contains($headline, 'POST-TROPICAL')) continue;
        if (str_contains($type, 'POST-TROPICAL')) continue;

        $active[] = $c;
    }

    return $active;
}

function getNewestCyclone($cyclones) {
    usort($cyclones, function($a, $b) {
        return strtotime($b['datetime']) - strtotime($a['datetime']);
    });

    return $cyclones[0] ?? null;
}

function isCycloneCurrent($cyclone, $maxAgeHours = 4) {

    if (!$cyclone || empty($cyclone['datetime'])) {
        return false;
    }

    $advisoryTime = strtotime($cyclone['datetime']);
    if ($advisoryTime === false) {
        return false;
    }

    $ageSec = time() - $advisoryTime;
    $ageHours = $ageSec / 3600;
    return ($ageHours <= $maxAgeHours);
}

function getCurrentCyclone($xmlString) {
    $cyclones = parseNhcCycloneXml($xmlString);
    $active   = filterActiveCyclones($cyclones);
    if (empty($active)) {        return null;    }
    $newest = getNewestCyclone($active);
    if (!isCycloneCurrent($newest)) {        return null;    }
    return $newest;
}

function fetchCapAlerts($lat, $lon, $cacheFile, $ver) {
    $datum  = date('m-d-Y H:i:s');

    print"$datum fetch alerts - ";
    $url = "https://api.weather.gov/alerts/active?point=$lat,$lon";
    $start = hrtime(true);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => [
            "Accept: application/cap+xml",
            "Accept-Language: en",
            "User-Agent: la2way.com $ver weather software"
        ]
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    $elapsed = round((hrtime(true) - $start) / 1e9, 2);

    // --- Error handling ---
    if ($response === false || $httpCode !== 200) {
        $status = "<error3>";

        if ($elapsed >= 10) {$status .= " timeout"; }

        save_task_log("weather API CAP Warn error $status $elapsed Sec.");
        print "$status $elapsed Sec.\n";

        if (file_exists($cacheFile)) { unlink($cacheFile);}
        return false;
    }

    // --- Save cache ---
    file_put_contents($cacheFile, $response, LOCK_EX);

    print "<ok> $elapsed Sec.\n";


    return true;
}

function fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, $cacheMinutes = 60, $cron = false) {
    $datum  = date('m-d-Y H:i:s');
    $url = "https://www.nhc.noaa.gov/" . ltrim($cycloneURL, "/");
    $now = time();
    $file=$cyclone;
    // --- Check Cache Age ---
    if (file_exists($file)) {
        $ageSec = $now - filemtime($file);
        $ageMin = floor($ageSec / 60);

        echo "$datum Cyclone cache age: {$ageMin} minutes (limit: {$cacheMinutes})\n";

        if ($ageMin < $cacheMinutes && !$cron) {
            echo "$datum Using cached cyclone data (fresh enough)\n";
            return true;
        }

        echo "$datum Cache expired — fetching new cyclone data\n";
    } else {
        echo "$datum No cyclone cache found — fetching new data\n";
    }

    // --- Fetch New Data ---
    $start = microtime(true);

    $headers = [
        "Accept: application/xml",
        "Accept-Language: en",
        "User-Agent: $ver 2way radio software"
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_FAILONERROR    => false,
    ]);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $elapsed = round(microtime(true) - $start, 2);

    // --- Error Handling ---
    if ($response === false || $httpCode >= 400) {
        echo "$datum NHC fetch error after {$elapsed} sec — keeping old cache\n";
        save_task_log("NHC fetch error, keeping old cache");
        return false;
    }

    // --- Save New Cache ---
    file_put_contents($file, $response, LOCK_EX);

    echo "$datum Cyclone data updated in {$elapsed} sec\n";
    save_task_log("Updated cyclone cache: $file");

    return true;
}


function save_task_log($status) {
    global $basename, $path,$logDir,$log ;

    $status = str_replace(',', ' ', $status);
    $datum  = date('m-d-Y H:i:s');



    // Ensure log directory exists
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

  // Build log line
    $line = "$datum,$status,$basename,,,\n";

  // Write to log
    file_put_contents($log, $line, FILE_APPEND | LOCK_EX);
}


function read_api($file) {
    global $NWheadline, $instruction, $headline, $event,
           $icon, $shortForcast, $detailedForecast,
           $url, $description, $apiVer;

    // Reset variables
    $NWheadline = "";
    $instruction = "";
    $headline = "";
    $event = "";
    $icon = "";
    $shortForcast = "";
    $detailedForecast = "";
    $url = "";
    $description = "";
    $apiVer = "";

    // Read + decode JSON
    $json = json_decode(file_get_contents($file), true);
    if (!$json) { save_task_log("JSON decode error in $file"); print "decode Error\n";       return false;    }

    // Extract version
    $apiVer = $json['@version'] ?? "";

    // Extract properties
    $props = $json['properties'] ?? [];

    $headline        = $props['headline']        ?? "";
    $description     = $props['description']     ?? "";
    $instruction     = $props['instruction']     ?? "";
    $event           = $props['event']           ?? "";
    $NWheadline      = implode("|", $props['NWSheadline'] ?? []);
    $url             = $props['forecast']        ?? "";
    $shortForcast    = $props['shortForecast']   ?? "";
    $detailedForecast= $props['detailedForecast']?? "";
    $icon            = $props['icon']            ?? "";

    // Normalize icon size
    if ($icon) { $icon = str_replace("size=medium", "size=small", $icon); }
    return true;
}






function isHurricane($type) {
    // Normalize to lowercase and trim whitespace
    $type = strtolower(trim($type));

    // Match only the word "hurricane"
    return $type === "hurricane";
}



// Helper function to parse coordinates from string like "38.3, -50.8"
function parseCoordinates($center) {
    $parts = explode(',', $center);
    if (count($parts) != 2) return [null, null];
    return [floatval(trim($parts[0])), floatval(trim($parts[1]))];
}










function watchdog(){
// not used in this release. 
// part of net down detection
}
function read_api_json_alerts($cacheFile) {
    global $event, $headline, $description, $instruction;

    $event = [];
    $headline = [];
    $description = [];
    $instruction = [];

    if (!file_exists($cacheFile)) {
        return false;
    }

    $json = file_get_contents($cacheFile);
    $data = json_decode($json, true);

    if (!isset($data['features']) || !is_array($data['features'])) {
        return false;
    }

    foreach ($data['features'] as $f) {
        if (!isset($f['properties'])) continue;

        $p = $f['properties'];

        $event[]       = $p['event']       ?? "";
        $headline[]    = $p['headline']    ?? "";
        $description[] = $p['description'] ?? "";
        $instruction[] = $p['instruction'] ?? "";
    }

    return true;
}