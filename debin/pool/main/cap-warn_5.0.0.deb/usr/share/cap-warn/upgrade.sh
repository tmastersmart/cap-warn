#!/bin/bash
# CAP-Warn upgrade script
# (c) 2026 KJ5MZL — la2way.com

echo "CAP-Warn upgrade: no actions required."
exit 0
