#!/bin/bash

# ============================================================
# © 2026 KJ5MZL — la2way.com
# All rights reserved.
#
# Licensed for use on personal nodes, repeaters, and hubs.
# Any hub or shared system must provide visible credit to KJ5MZL.
# This software may NOT be redistributed, repackaged, or included
# in ANY release or image without explicit written permission
# from the author.
# ============================================================

# -----------------------------
#  CAP Information Splash Screen
# -----------------------------
whiptail --title "CAP Warn Installer — © 2026 KJ5MZL" --msgbox "\
CAP Warn Setup Program
© 2023/2026 KJ5MZL — la2way.com
All rights reserved. Copyrighted software.

Licensed for use on personal nodes, repeaters, and hubs.
Any hub or shared system must provide visible credit to KJ5MZL.
This software may NOT be redistributed, repackaged, or included in
ANY release or image without explicit written permission from the author.

------------------------------------------------------------
What is CAP?
------------------------------------------------------------
The Common Alerting Protocol (CAP) is an XML-based standard used to
share emergency information across local, state, tribal, national,
and non-governmental organizations involved in emergency response.

The National Weather Service (NWS) produces CAP messages for watches,
warnings, advisories, and special weather statements. These messages
follow the CAP v1.2 standard defined by OASIS and comply with FEMA's
IPAWS CAP profile.

NWS CAP messages can trigger alerting systems, feed mobile apps,
launch Internet alerts, update radio/TV displays, highway signs,
and generate synthesized voice messages.

This system replaces older 'no warning' scripts with a modern,
fully CAP-compliant alerting engine.

Press OK to begin installation." 30 78

# -----------------------------
#  Cancel Handler Function
# -----------------------------
check_cancel() {
    if [ $? -ne 0 ]; then
        echo "Setup canceled."
        exit 1
    fi
}

CONFIG="/etc/cap-warn/config.php"
BACKUP="/etc/cap-warn/config.php.bak_$(date +%Y%m%d_%H%M%S)"


# -----------------------------
#  Backup existing config
# -----------------------------
if [ -f "$CONFIG" ]; then
    cp "$CONFIG" "$BACKUP"
    whiptail --title "Backup Created" --msgbox "Existing config.php backed up to:\n$BACKUP" 10 60
fi

# -----------------------------
#  VoiceRSS Warning
# -----------------------------
whiptail --title "IMPORTANT: VoiceRSS API Key Required" \
--msgbox "You must create a FREE account at https://www.voicerss.org/ and obtain an API key.\n\nWithout this key, the system will skip custom voice alerts using only stock sound.\n\nPress OK to continue." 12 60
check_cancel

# -----------------------------
#  Node Number
# -----------------------------
NODE=$(whiptail --inputbox "Enter your AllStar node number:" 10 60 "" --title "Node Number" 3>&1 1>&2 2>&3)
check_cancel

# -----------------------------
#  TTS API Key
# -----------------------------
TTSKEY=$(whiptail --inputbox "Enter your VoiceRSS API key:" 10 60 "" --title "TTS API Key" 3>&1 1>&2 2>&3)
check_cancel

# -----------------------------
#  GPS Coordinates (Alexandria LA defaults)
# -----------------------------
LAT=$(whiptail --inputbox "Enter repeater latitude:" 10 60 "31.3113" --title "GPS Latitude" 3>&1 1>&2 2>&3)
check_cancel

LON=$(whiptail --inputbox "Enter repeater longitude:" 10 60 "-92.4451" --title "GPS Longitude" 3>&1 1>&2 2>&3)
check_cancel

# -----------------------------
#  Hurricane Basin Selection
# -----------------------------
CHOICE=$(whiptail --title "Select Hurricane Basin" --menu "Choose one:" 15 60 4 \
"1" "Atlantic (gis-at.xml)" \
"2" "Eastern Pacific (gis-ep.xml)" \
"3" "Central Pacific (gis-cp.xml)" \
"0" "Disable hurricane detection" \
3>&1 1>&2 2>&3)
check_cancel

case $CHOICE in
    1) CYURL="/gis-at.xml"; DETECTCYCLONE=true ;;
    2) CYURL="/gis-ep.xml"; DETECTCYCLONE=true ;;
    3) CYURL="/gis-cp.xml"; DETECTCYCLONE=true ;;
    0) CYURL="disabled"; DETECTCYCLONE=false ;;
esac

# -----------------------------
#  Storm Radius
# -----------------------------
if [ "$DETECTCYCLONE" = true ]; then
    STORMRADIUS=$(whiptail --inputbox "Enter storm radius in miles (0 to disable):" 10 60 "600" --title "Storm Radius" 3>&1 1>&2 2>&3)
    check_cancel
else
    STORMRADIUS=0
fi

# -----------------------------
#  Expand Alerts
# -----------------------------
whiptail --yesno "Expand alerts with description?" 10 60
if [ $? -eq 0 ]; then EXPANALERT=true; else EXPANALERT=false; fi

# -----------------------------
#  Local Playback
# -----------------------------
whiptail --yesno "Play alerts locally only?" 10 60
if [ $? -eq 0 ]; then LOCAL=true; else LOCAL=false; fi

# -----------------------------
#  Quiet Hours
# -----------------------------
whiptail --yesno "Enable quiet hours (1am–6am)?" 10 60
if [ $? -eq 0 ]; then SLEEP=true; else SLEEP=false; fi

# -----------------------------
#  Talk Enable
# -----------------------------
whiptail --yesno "Enable voice playback?" 10 60
if [ $? -eq 0 ]; then TALKFLAG=true; else TALKFLAG=false; fi

# -----------------------------
#  Debug Mode (forced off)
# -----------------------------
DEBUG=false

# -----------------------------
#  Hold Timer
# -----------------------------
HOLDTIME=$(whiptail --inputbox "Minutes to wait before repeating the same alert:" 10 60 "25" --title "Hold Timer" 3>&1 1>&2 2>&3)
check_cancel

# -----------------------------
#  Cron Interval
# -----------------------------
CRONINT=$(whiptail --inputbox "How often should alerts run? (minutes)" 10 60 "13" --title "Cron Interval" 3>&1 1>&2 2>&3)
check_cancel

# -----------------------------
#  Write config.php
# -----------------------------
cat <<'EOF' > "$CONFIG"
<?php
$node = "__NODE__";
$tts  = "__TTSKEY__";

$lat = "__LAT__";
$lon = "__LON__";

$stormRadiusMiles = __STORMRADIUS__;
$detectCyclone    = __DETECTCYCLONE__;
$cycloneURL       = "__CYCLONEURL__";
$expanAlert       = __EXPANALERT__;

$local    = __LOCAL__;
$sleep    = __SLEEP__;
$talkFlag = __TALKFLAG__;
$debug    = __DEBUG__;

$theHoldtime = __HOLDTIME__;
$path = "/usr/share/cap-warn";          // program directory
$soundPath = "$path/sounds";            // sound files


$outTmp    ="/tmp/tmp.gsm"; 
$alertTxt  ="/tmp/skywarn.txt";
$tailfile  ="/tmp/skywarn-tail.gsm";
$alertTxtHeadline    ="/tmp/skywarn_headline.txt";
$alertTxtDescription ="/tmp/skywarn_description.txt";  
$clash       ="/tmp/mmweather-task.txt";
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/alert.json";
$currentxml  ="/tmp/current.xml"; 
$currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml";
$special     ="/tmp/skywarn_special-weather.gsm";
$specialGSM  ="/tmp/skywarn_special-weather-out.gsm";
$specialTXT  ="/tmp/skywarn_special-weather.txt";
$cyclone     ="/tmp/cyclone.xml";
$cycloneTxt  ="/tmp/cyclone.txt";

// Logs now live in /var/log/cap-warn
$logDir = "/var/log/cap-warn";
$log    = "$logDir/cap-warn.log";
?>
EOF

# Replace placeholders
sed -i "s/__NODE__/$NODE/" "$CONFIG"
sed -i "s/__TTSKEY__/$TTSKEY/" "$CONFIG"
sed -i "s/__LAT__/$LAT/" "$CONFIG"
sed -i "s/__LON__/$LON/" "$CONFIG"
sed -i "s/__STORMRADIUS__/$STORMRADIUS/" "$CONFIG"
sed -i "s/__DETECTCYCLONE__/$DETECTCYCLONE/" "$CONFIG"
sed -i "s#__CYCLONEURL__#$CYURL#" "$CONFIG"
sed -i "s/__EXPANALERT__/$EXPANALERT/" "$CONFIG"
sed -i "s/__LOCAL__/$LOCAL/" "$CONFIG"
sed -i "s/__SLEEP__/$SLEEP/" "$CONFIG"
sed -i "s/__TALKFLAG__/$TALKFLAG/" "$CONFIG"
sed -i "s/__DEBUG__/$DEBUG/" "$CONFIG"
sed -i "s/__HOLDTIME__/$HOLDTIME/" "$CONFIG"

# -----------------------------
#  Install Cron Job
# -----------------------------
crontab -l 2>/dev/null | grep -v "cap_warn.sh" > /tmp/cron.tmp
echo "*/$CRONINT * * * * /usr/local/bin/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1" >> /tmp/cron.tmp

crontab /tmp/cron.tmp
rm /tmp/cron.tmp


# -----------------------------
#  Done
# -----------------------------
whiptail --title "Installation Complete" \
--msgbox "Skywarn Weather System is now configured.\n\nCron is set to run every $CRONINT minutes.\nBackup saved to:\n$BACKUP" 12 60
# -----------------------------
#  Configure Log Rotation
# -----------------------------
LOGROTATE_CONF="/etc/logrotate.d/cap-warn"

# Ensure log directory exists
if [ ! -d "/var/log/cap-warn" ]; then
    mkdir -p /var/log/cap-warn
    chmod 755 /var/log/cap-warn
fi

# Create logrotate config
cat <<EOF > "$LOGROTATE_CONF"
/var/log/cap-warn/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
    create 644 root root
}
EOF

whiptail --title "Log Rotation Enabled" \
--msgbox "Log rotation has been configured for:\n/var/log/cap-warn/*.log\n\nLogs will rotate daily and keep 14 compressed backups." 12 60
