<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.

// this is the main config file. 
$node = "669640";  // set to the node you want to talk to
// get a API key here https://www.voicerss.org/ (text to speach disabled without it)
// the free plan works fine.
$tts  = "3db54e06f70747d6b84e400ecfbe7fd8";
// The Weather Service CAP2 system works by GPS position.
$lat = "31.9214"; 
$lon = "-92.6366";
// What Huricanes to test for.
// Turn off what you dont want
$stormRadiusMiles = 600; // typical for Gulf Coast
$detectCyclone=true; // turn on or off for huricane messages
$expanAlert=true;// adds the description. Off just reads the header

$local = true; // set to false to play global on a hub
$sleep = false; // dont talk between 1am and 6am 
$talkFlag = true; // yes talk 
$debug = true;   // debugging 

// theHoldtime (in minutes)
// ------------------------
// This setting controls how long the system waits before it is allowed
// to play the SAME alert again. Every time an alert is played, a "hold"
// file is created. As long as that file is younger than theHoldtime,
// playback is skipped to prevent repeating the same alert too often.
//
// Example:
//   theHoldtime = 25
//   → The system will not replay the same alert for 25 minutes.
//   → After 25 minutes, the hold expires and the alert may play again.
//
// Typical values:
//   15 minutes  = more frequent updates (good for fast-changing weather)
//   25 minutes  = balanced (recommended)
//   60 minutes  = fewer repeats (good for stable conditions)
//
// Note:
// - Cron runs can override the hold if needed.
// - This prevents unnecessary TTS/GSM API calls and avoids spamming users.
$theHoldtime = 25;

$path      ="/home/laweather";
$outTmp    ="/tmp/tmp.gsm"; 
$alertTxt  ="/tmp/skywarn.txt";
$tailfile  ="/tmp/skywarn-tail.gsm";
$alertTxtHeadline    ="/tmp/skywarn_headline.txt";
$alertTxtDescription ="/tmp/skywarn_description.txt";  
$clash       ="/tmp/mmweather-task.txt";
$forcastxml  ="/tmp/geocode.xml";
$forcastxml2 ="/tmp/forcast.xml";
$alertxml    ="/tmp/alert.json";
$currentxml  ="/tmp/current.xml"; 
$currentTxt  ="/tmp/current.txt";
$acuwxml     ="/tmp/accuweather.xml";
$special     ="/tmp/skywarn_special-weather.gsm";
$specialGSM  ="/tmp/skywarn_special-weather-out.gsm";
$specialTXT  ="/tmp/skywarn_special-weather.txt";
$cyclone         ="/tmp/cyclone.xml";
$cycloneTxt      ="/tmp/cyclone.txt";
$cycloneURL  = "/gis-at.xml"; // set from ones listed at cyclone update ///https://www.nhc.noaa.gov/aboutrss.shtml
//  Atlantic Basin GIS Data:  gis-at.xml
//  Eastern Pacific Basin GIS gis-ep.xml
//  Central Pacific Basin GIS gis-cp.xml 

$logDir = "$path/logs";
$log    = "$logDir/log.txt";

?>