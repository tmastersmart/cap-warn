<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// Placeholder: forces stop if setup has not been run.
// Includes 1960s mainframe humor for your enjoyment.

print "
============================================================
   *** CAP-Warn Setup Not Completed ***

   ALERT: The system has detected that setup.sh
   has NOT been run. In 1964 this would require
   an operator, three punch cards, and a prayer.

   Please complete setup immediately:

       cd /usr/share/cap-warn
       sudo bash setup.sh

   Remember: failure to run setup may cause
   unexpected behavior, such as:
     • Vacuum tubes overheating
     • Magnetic tape becoming grumpy
     • The computer demanding more punch cards
     • The operator blaming cosmic rays again

   Thank you for choosing software made in Louisiana.
   It's like a 1960s mainframe — but with fewer sparks.
============================================================
";

die;
?>
