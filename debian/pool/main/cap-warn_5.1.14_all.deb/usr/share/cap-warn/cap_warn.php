<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.
//
//
//What is CAP?
//Common Alerting Protocol (CAP)  is an XML-based information standard used to facilitate emergency information sharing and data exchange across
// local, state, tribal, national and non-governmental organizations of different professions that provide emergency response and management services.
//
//NWS produces CAP for NWS weather and hydrologic alerts including watches, warnings, advisories, and special statements. 
//NWS CAP messages follow the CAP v1.2 standard defined by the Organization for the Advancement of Structured Information Standards (OASIS) and 
//comply with the Federal Emergency Management Agency (FEMA) Integrated Public Alert and Warning System (IPAWS) CAP profile.  
//The National Weather Service (NWS) CAP v1.2 Documentation provided on this site supplements the OASIS CAP v1.2 standard and IPAWS CAP
// profile by identifying the formats of NWS information contained within NWS CAP messages. 

//Uses of CAP
//NWS CAP can be used to launch Internet messages, trigger alerting systems, feed mobile device applications, news feeds, television/radio display
// and audio, digital highway signs, synthesized voice over automated telephone calls, and much more.

// Replaces existing no warning scripts .

// v3.4 10-05-23  Major changes to weather API
// v3.5 10/14/2023  FEMAQ added
// v3.6 10/21/2023  Muting adjustments
// v3.7 10/31/2023  Logging improvements
// v3.8 11/02/2023  Fixed old files not clearing; removed legacy artifacts
// v3.9 11/07/2023  Stopped duplicate burst
// v4.0 11/20/2023  Debugging info on muting
// v4.2 01/13/2024  Cleanup and anti‑clash changes
// v4.3 01/17/2024  Bug fix in clear status
// v4.4 01/21/2024  Watch statement flags; new sounds
// v4.4 01/29/2024  Weather functions moved to separate file
// v4.5 02/11/2024  WAV playback bug; converted all to GSM; debug mode added
// v4.6 01/20/2025  Mods for the image
// v4.7 02/15/2025  Clash flag fix
// v4.8 03/28/2026  Full alert read for Special Weather Statement
// v5.0 05/11/2026  Created Standalone system with installers
// v5.0.6 05/24/2026 rebuilt functions from scratch for newer php

$pathI = "/usr/share/cap-warn";
$verFile = "$pathI/version.txt";
if (file_exists($verFile)) { $ver = "v" . trim(file_get_contents($verFile));} 
else { $ver = "v5.1.0";}
$release = "5/26/2026";

// Get system timezone cleanly
$zone = trim(shell_exec('timedatectl show -p Timezone --value'));
// Fallback if command fails
if (!$zone) {    $zone = 'America/Chicago';}
// Apply to PHP
date_default_timezone_set($zone);
// Optional: verify
$phpzone = date_default_timezone_get();

require_once("/etc/cap-warn/config.php");
require_once("/etc/cap-warn/advanced_config.php");
// Program directory for internal includes

include_once("$pathI/sound_db.php");
include_once("$pathI/cap_functions.php");

// Safety if no tailfile repair
if (!file_exists($tailfile)){  
 if (file_exists($alertTxt)){unlink($alertTxt);} 
 if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
}
//using the command cron resets the hold off timmer
$cron=false;if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;} }

$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m  -s -o -v');}



$phpVersion= phpversion();$CAPstatus="Clear";
$time= date('H:i');
$date =  date('m-d-Y');
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
print "
===================================================
Cap Warn NWS API  $ver 
(c)2023/2026 KJ5MZL WRXB288 LA2WAY.com LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
===================================================
$datum Node:$node UTC:$gmdatum 
$datum Model: $piVersion
";
$action=""; $event="";

$flag = "/tmp/alert-played.txt"; 

if (file_exists($flag)) {
    $ageSeconds  = time() - filemtime($flag);
    $ageMinutes  = floor($ageSeconds / 60);
    echo "$datum Hold flag age: {$ageMinutes} minutes (limit: {$theHoldtime} minutes)\n";
    if ($ageSeconds > ($theHoldtime * 60)) {        echo "$datum Hold expired — resetting play timer.\n";        unlink($flag);    }
    elseif ($cron) {        echo "$datum Cron override — resetting play timer.\n";        unlink($flag);    }
    else {        echo "$datum Skipping playback — still within hold window.\n";    }
}
else {    echo "$datum No hold flag — playback allowed.\n";}



// the clash file stops other processed from playing at the same time
if(file_exists($clash)){
 $out="Waiting for other thread. "; save_task_log($out);print"$datum $out\n";
 sleep(90);
 // safety clear abandoned flags
 if(file_exists($clash)){   // fix for file being erased in loop
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);} 
 } // 10 mins
}
$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);



//if (file_exists($tailfile)){print "$datum found: $tailfile\n";}   
//if (file_exists($alertTxt)){print "$datum found: $alertTxt\n";} 
//if (file_exists($alertTxtHeadline)){print "$datum found: $alertTxtHeadline\n";}
// test for mute move to start
$hour=date('H');$day=date('D');
if(!$cron){
$mute=false;
if($sleep){
 if($hour>=1 and $hour <=6){
 $mute=true;$out="Sleep Mute $day $hour am";save_task_log ($out);print "$datum $out\n";
  }
 }
}
else{$mute=false;}

$fetch=true;
// fetch updates....
if (file_exists($alertxml)) {
    $age_seconds = time() - filemtime($alertxml);
    $age_minutes = round($age_seconds / 60, 1); // one decimal place
    // Cache is fresh if age < 5 minutes
    if ($age_seconds < 300) {$fetch = false;}
    echo "$datum Alert cache age: {$age_minutes} minutes\n";
}

if($fetch){fetchCapAlerts($lat, $lon, $alertxml, $ver);}
else{print"$datum Using Cached file Alerts\n";}
read_api_json_alerts($alertxml);


if ($detectCyclone==true){
fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, 60, $cron);
$xmlString = file_get_contents($cyclone);
$cyclones  = parseNhcCycloneXml($xmlString);
$active    = filterActiveCyclones($cyclones);
$datum   = date('m-d-Y H:i:s');
foreach ($active as $cyclone) {
    // --- Freshness check ---
    if (!isCycloneCurrent($cyclone)) {
        print "$datum Skipping {$cyclone['name']} — advisory stale\n";
        continue;
    }
    // --- Distance check ---
    list($stormLat, $stormLon) = array_map('floatval', explode(',', $cyclone['center']));
    $distance = haversine($lat, $lon, $stormLat, $stormLon);
    if ($distance > $stormRadiusMiles) {
        print "$datum Skipping {$cyclone['name']} — too far away ({$distance} miles)\n";
        continue;
    }
    // --- Build event ---
    $eventName = $cyclone['type'] . " " . $cyclone['name'];
    $headline  = $cyclone['headline'];
    // --- Shorten description ---
    $sentences = preg_split('/(?<=[.?!])\s+/', $headline);
    $short     = trim(implode(' ', array_slice($sentences, 0, 2)));
    // --- Inject into alert arrays ---
    $event[]       = $eventName;
    $headline[]    = $headline;
    $description[] = $short;
    $instruction[] = "";
    print "$datum Cyclone added: $eventName ($distance miles away)\n";
}
}

$datum   = date('m-d-Y H:i:s');
$events       = "";
$headlines    = "";
$descriptions = "";
$instructions = "";

$count = count($event);
for ($i = 0; $i < $count; $i++) {

    if ($i == 0) {
        // first item: no leading separators
        $events       .= $event[$i];
        $headlines    .= $headline[$i];
        $descriptions .= $description[$i];
        $instructions .= $instruction[$i];
    } else {
        // subsequent items: prepend separators
        $events       .= "," . $event[$i];
        $headlines    .= "|" . $headline[$i];
        $descriptions .= "|" . $description[$i];
        $instructions .= "|" . $instruction[$i];
    }
}
str_replace(['\\n', '*', '#', '~'], ' ', $descriptions);// clean it up.




if($events){print"$datum Events: $events\n";}
else{all_clear("ok");$events="";}
// set the status
if ($events){
  $CAPstatus="new";
  if (file_exists($alertTxt) ){
  $test = file_get_contents($alertTxt);
  if ($test <> $events){print "$datum Events have changed\n";$CAPstatus="new";save_task_log ("new Alert $events");}
 else {$CAPstatus="no change";print "$datum Existing Event file [$CAPstatus]\n";}
 }
}
// there is already a audio file since its not changed.
if ($CAPstatus == "no change" && !file_exists($flag)) {
    $min = date('i');
    if ($debug) { $min = 30; } // force test window
       echo "$datum Minute check: current minute = $min (window: 10–50)\n";
       if ($min >= 10 && $min <= 50) {
       $file=$tailfile;playSoundOnly($out);
       $CAPstatus="Playing Tail File";
       $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}
 else { echo "$datum Skipping — outside 10–50 minute window (current: $min)\n"; $CAPstatus="mute";}
}
else {$CAPstatus="mute";}

// its diffrent we need to build the file.
$datum   = date('m-d-Y H:i:s');
if ($CAPstatus=="new"){

print "$datum Creating new event files.\n";
$fileOUT = fopen($alertTxt,'w');fwrite ($fileOUT,$events);fclose ($fileOUT);
$fileOUT = fopen($alertTxtHeadline,'w');fwrite ($fileOUT,$headlines);fclose ($fileOUT);
$fileOUT = fopen($alertTxtDescription,'w');fwrite ($fileOUT,$descriptions);fclose ($fileOUT);

save_task_log ($events); // save it to the log

$file = $tailfile;if(file_exists($file)){unlink($file);} // kill the last tail file to prevent it launching during play

// has-issued-a,has-expired,weather-station,weather,
check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_gsm_db  ("weather service");             if($file1){$action = "$action $file1";}

$watchSTATUS="alert";

$all = strtolower($events);
 if (strpos($all, "statement") !== false){ $watchSTATUS="Special Weather Statement";   }
 if (strpos($all, "advisory") !== false) { $watchSTATUS="advisory";       }
 if (strpos($all, "watch") !== false)    { $watchSTATUS="watch";        } 
 if (strpos($all, "warning") !== false)  { $watchSTATUS="warning";    }


print "$datum Alert(s) Detected $watchSTATUS\n";
if ($watchSTATUS){check_gsm_db ($watchSTATUS);if($file1){$action = "$action $file1";}} 

// if its a special weather statement we neeed to read it because it wont say what it is,
if ($watchSTATUS=="Special Weather Statement"){
// tts must be set if not we skip talking
if($talkFlag and $tts){



$firstSWS = "";
foreach ($event as $i => $ev) {
if (stripos($ev, "special weather statement") !== false || $expanAlert == true) {

        $firstSWS = trim($description[$i]);
        break; // only the first one matters
    }
$sentences = preg_split('/(?<=[.?!])\s+/', $firstSWS);
$firstSWS = trim(implode(' ', array_slice($sentences, 0, 2)));
}
}
$previous_text = '';if (file_exists($specialTXT)) {    $previous_text = file_get_contents($specialTXT);}
// Compare old vs new
$skip_build = false;if (trim($previous_text) === trim($firstSWS)) {echo "$datum Description unchanged \n";$skip_build = true;}

if (!$skip_build){
 if ($tts){
// Create an instance of the VoiceRSS class
$voiceRSS = new VoiceRSS();
// Define the settings for the speech request
$settings = array(
    'key' => $tts,
    'src' => $firstSWS, // Your text here
    'hl' => 'en-us', // Language (English - US)
    'v'  => 'Amy', // Voice (optional)
    'r'  => '0', // Rate (optional)
    'f'  => '8khz_16bit_mono',
    'c'  => 'wav', // Format 
);

// Call the speech function to get the response
$response = $voiceRSS->speech($settings);
// Check if there was an error in the response
if ($response['error']) {  echo "Error: " . $response['error'];}
else { $mp3Data = $response['response']; // The MP3 binary data
    if (file_put_contents($special, $mp3Data)) { 
    echo "$datum $special saved successfully \n";
    echo "$datum ALERT Transcribed $firstSWS \n";
    $fileOUT = fopen($specialTXT,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$firstSWS);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
    echo "$datum $specialTXT saved successfully \n";
    }
    else {echo "$datum Failed to save the file.\n";}
  }
 }
 else {
    // ---------------------------------------
    // Fallback path: use asl-tts (no API key)
    // ---------------------------------------
    $cmd = "asl-tts -t " . escapeshellarg($firstSWS) . " -f " . escapeshellarg($specialUL);
    exec($cmd, $output, $return);

    if ($return === 0) {
        echo "$datum $specialUL generated via asl-tts\n";
        file_put_contents($specialTXT, $firstSWS);
    }
 else { echo "$datum ERROR: asl-tts failed to generate audio\n";}
}
 
 
}// end skip build

//if (file_exists($special )){$action = "$action $special";}
  }// if ts end



// build that file
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space between them
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$u= explode(",",$events); 
$burnban=false;
foreach($u as $line){
$line = strtolower($line);
if($line){ check_gsm_db($line);if($file1){$action = "$action $file1";} } 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_gsm_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
 
}// end for loop

if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 
$datum   = date('m-d-Y H:i:s'); 

if(!$mute){
$file=$outTmp;
playSound($out); 
$fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}

// build the shorter tail file
// This is the same as above with the updated weather information notice
$action="";
check_gsm_db  ("silence1"); if($file1){$action = "$action $file1";}
$u= explode(",",$events);$burnban=false;

foreach($u as $line){
check_wav_db  ("star dull"); if($file1){$action = "$action $file1";}

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }

// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once Prevents dupes
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_gsm_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 


// $tailfile  ="/tmp/skywarn-tail.wav";  
exec ("sox $action $tailfile",$output,$return_var);
print "$datum Tailfile updated $tailfile\n";
 }
}// end if new

//else {all_clear("ok");}/// this is a dupe just to be safe 
if($piSystem && $piAlarms){include_once("$pathI/temp.php");}

$datum = date('m-d') . "-1965 " . date('H:i:s');
print "$datum End of Line. Next Punch Card Please.  \n";
print"===================================================\n";
if(file_exists($clash)){unlink($clash);}



function all_clear($in){
global $action,$file1,$file,$alertTxt,$tailfile,$node,$outTmp,$alertTxtHeadline,$local,$special,$specialTXT,$specialUL;

$action="";$file="";
$datum= date('m-d-Y H:i:s');
print "$datum Processing all Clear\n";
$outTmp    ="/tmp/tmp.gsm"; if (file_exists($outTmp)){unlink($outTmp);} 
if (file_exists($tailfile)){unlink($tailfile);}
if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
if (file_exists($special)){unlink($special);} 
if (file_exists($specialUL)){unlink($specialUL);} 
if (file_exists($specialTXT)){unlink($specialTXT);} 
// has-issued-a,has-expired,weather-station,weather,
// There has been a past alert so we need to clear
if (file_exists($alertTxt)){
 unlink($alertTxt);
 check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
 check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
 check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
 check_gsm_db  ("clear");                       if($file1){$action = "$action $file1";}
 //check_wav_db  ("star dull");                   if($file1){$action = "$action $file1";}

$file=$outTmp;playSound($out); 

$out ="All Events now Clear";save_task_log ($out);print "$datum $out\n";
 if(!$status){$status="OK";}
 }
}




?>
