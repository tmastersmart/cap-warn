#!/bin/bash
# CAP-Warn upgrade script
# (c) 2026 KJ5MZL — la2way.com

echo "----------------------------------------------"
exit 0
