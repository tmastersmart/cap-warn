<?php
/*
 FUNCTIONS  
 © 2023–2026 KJ5MZL / WRXB288
 la2way.com • lagmrs.com
 All rights reserved. This module and all functions within it
 are fully copyrighted and NOT open‑source.

 You are granted permission to use this software on your personal
 node or repeater. HUB operators must provide a link back to me
 in some form (website, dashboard, documentation, etc.).

 This software may NOT be modified, redistributed, repackaged,
 incorporated into any image, or included in any distribution
 without explicit written approval from KJ5MZL.

 Donations are appreciated.
 This software is provided as FreeViewWare.

 Software made in loUiSiAna — it's just better.
*/

function build_tts_audio($text, $wavFile, $txtFile, $ulFile, $node, $ttsKey, $logPrefix = "") {
    global $datum,$ttsFormat;
// VoiceRSS sound formats:
// 8 kHz  - Telephone quality (Asterisk-safe)
// 11 kHz - Slightly better
// 22 kHz - FM radio quality
// 44 kHz - CD quality
// 48 kHz - Studio quality
//
// Examples:
// '8khz_16bit_mono'   (HAM default)
// '44khz_16bit_mono'  (Desktop recommended)
// '48khz_16bit_stereo' (Highest quality)
$ttsFormat="8khz_16bit_mono";
// -----------------------------
// 1. Try VoiceRSS (if key exists)
// -----------------------------
if (!empty($ttsKey)) {
    print "$datum {$logPrefix}Building sound using VoiceRSS\n";

    $voiceRSS = new VoiceRSS();
    $settings = array(
        'key' => $ttsKey,
        'src' => $text,
        'hl'  => 'en-us',
        'v'   => 'Amy',
        'r'   => '0',
        'f'   => $ttsFormat,
        'c'   => 'wav'
    );

    $response = $voiceRSS->speech($settings);

    if (empty($response['error']) && !empty($response['response'])) {
        $audio = $response['response'];

        if (file_put_contents($wavFile, $audio)) {
            print "$datum {$logPrefix}Saved WAV: $wavFile\n";
            file_put_contents($txtFile, $text);
            return $wavFile;   // SUCCESS → STOP HERE
        }

        print "$datum {$logPrefix}ERROR: Failed to write $wavFile\n";
    } else {
        print "$datum {$logPrefix}TTS ERROR: {$response['error']}\n";
    }

    // DO NOT return here — continue to fallback
}


// -----------------------------
// 2. Try asl-tts (if installed)
// -----------------------------
if (shell_exec("command -v asl-tts")) {
    print "$datum {$logPrefix}Fallback: asl-tts\n";

    $ulBase = preg_replace('/\.[a-z0-9]+$/i', '', $ulFile);
    $cmd = "asl-tts -n $node -t " . escapeshellarg($text) . " -f " . escapeshellarg($ulBase);
    exec($cmd, $output, $return);

    if ($return === 0) {
        print "$datum {$logPrefix}Generated UL: $ulFile\n";
        file_put_contents($txtFile, $text);
        return $ulFile;   // SUCCESS → STOP HERE
    }

    print "$datum {$logPrefix}ERROR: asl-tts failed\n";
    // DO NOT return — continue to espeak fallback
}


// -----------------------------
// 3. Try espeak-ng (desktop fallback)
// -----------------------------
if (shell_exec("command -v espeak-ng")) {
    print "$datum {$logPrefix}Fallback: espeak-ng\n";

    $cmd = "espeak-ng -w " . escapeshellarg($wavFile) . " " . escapeshellarg($text);
    exec($cmd, $output, $return);

    if ($return === 0) {
        print "$datum {$logPrefix}Generated WAV via espeak-ng: $wavFile\n";
        file_put_contents($txtFile, $text);
        return $wavFile;   // SUCCESS → STOP HERE
    }

    print "$datum {$logPrefix}ERROR: espeak-ng failed\n";
}


// -----------------------------
// 4. All methods failed
// -----------------------------
print "$datum {$logPrefix}ERROR: No TTS method succeeded\n";
return false;

}



function archive_json($src) {
    if (!file_exists($src)) return;
    $dest = "/var/log/cap-warn/archive.log";
    $ts = date("Y-m-d H:i:s");
    $header = "\n===== $ts ===== " . basename($src) . " =====\n";
    $data = file_get_contents($src);
    file_put_contents($dest, $header . $data . "\n", FILE_APPEND);
}




function all_clear($in){
global $action,$file1,$file,$alertTxt,$tailfile,$node,$outTmp,$alertTxtHeadline,$local,$special,$specialTXT,$specialUL,$status;
$action="";$file="";
$datum= date('m-d-Y H:i:s');
$outTmp    ="/tmp/tmp.gsm"; if (file_exists($outTmp)){unlink($outTmp);} 
if (file_exists($tailfile)){unlink($tailfile);}
if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
if (file_exists($special)){unlink($special);} 
if (file_exists($specialUL)){unlink($specialUL);} 
if (file_exists($specialTXT)){unlink($specialTXT);} 
// has-issued-a,has-expired,weather-station,weather,
// There has been a past alert so we need to clear
if (file_exists($alertTxt)){
 unlink($alertTxt);
 $out="Processing All clear";save_task_log ($out);print "$datum $out\n";
 check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
 check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
 check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
 check_gsm_db  ("clear");                       if($file1){$action = "$action $file1";}
 //check_wav_db  ("star dull");                   if($file1){$action = "$action $file1";}
$file=$outTmp;playSound($out); 
if(!$status){$status="OK";}
 }
}

// Haversine formula:
// Calculates the great‑circle distance between two latitude/longitude points
// on the Earth’s surface. This gives an accurate “as‑the‑crow‑flies” distance
// over the curve of the planet 
function haversine($lat1, $lon1, $lat2, $lon2) {
    $R = 3959; // miles
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);

    $c = 2 * atan2(sqrt($a), sqrt(1-$a));

    return round($R * $c);  // <— clean integer
}

function buildStormSummary($cyclone) {
    // Normalize compass directions
    $movement = normalizeDirections($cyclone['movement'] ?? '');
    $center   = $cyclone['center'] ?? '';
    $wind     = $cyclone['wind'] ?? '';
    $parts = [];
    if (!empty($center)) {        $parts[] = "Located near $center.";    }
    if (!empty($wind)) {        $parts[] = "Wind Speed $wind.";    }
    if (!empty($movement)) {        $parts[] = "Moving $movement.";    }
    return implode(" ", $parts);
}
function normalizeDirections($text) {
    $dirs = [
        'NE' => 'Northeast',
        'NW' => 'Northwest',
        'SE' => 'Southeast',
        'SW' => 'Southwest',
        'N'  => 'North',
        'S'  => 'South',
        'E'  => 'East',
        'W'  => 'West',
    ];
    foreach ($dirs as $abbr => $full) {        $text = preg_replace('/\b' . $abbr . '\b/i', $full, $text);    }
    return $text;
}



function cleanCycloneHeadline($headline) {
    $h = trim($headline);
    // Remove NOAA ellipses
    $h = str_replace("...", " ", $h);
    // Remove weird punctuation
    $h = str_replace(["*", "•", "#", "|", "<", ">"], " ", $h);
    // Collapse whitespace
    $h = preg_replace('/\s+/', ' ', $h);
    // Fix ALL CAPS
    if (strtoupper($h) === $h) { $h = ucwords(strtolower($h));    }
    // Ensure ending punctuation
    if (!preg_match('/[.!?]$/', $h)) { $h .= ".";    }
    return trim($h);
}


function isNewCycloneAdvisory($storm) {
    global $datum, $cycloneLast;

    $id   = $storm['atcf'];
    $time = $storm['datetime'];   // raw or formatted, doesn't matter as long as consistent
    $key  = $id . "_" . $time;

    // Load all previous keys
    $seen = [];
    if (file_exists($cycloneLast)) {
        $seen = file($cycloneLast, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    }

    // If this key already exists → duplicate
    if (in_array($key, $seen)) {
        return false;
    }

    // Otherwise append it
    file_put_contents($cycloneLast, $key . "\n", FILE_APPEND);
    print "$datum Saving this storm $key\n";




    return true;
}




function buildCycloneTTS($type, $name, $headlines) {
    $ttsEvents = [];
    foreach ($headlines as $i => $rawHeadline) {
        $clean = cleanCycloneHeadline($rawHeadline);
        // Build event text
        if (count($headlines) > 1) {$ttsEvents[] = "Event " . ($i + 1) . ": $type $name $clean";} 
    else { $ttsEvents[] = "$type $name $clean"; }
    }
    // Combine into one long TTS string
    return implode(" ", $ttsEvents);
}

function normalizeCycloneDate($dt) {
    // If no year is present, append the current year
    if (!preg_match('/\b\d{4}\b/', $dt)) {
        $dt .= " " . date("Y");
    }
    return $dt;
}

// sample code from testing on orginal version
//<description>Atlantic Basin GIS Data for Active Tropical Cyclones</description>GULF OF HONDURAS
//      <description>...ERIN BECOMING BETTER ORGANIZED AS IT MOVES NORTH-NORTHWESTWARD... ...LIFE-THREATENING RIP CURRENTS EXPECTED ALONG U.S. EAST COAST BEACHES... As of 11:00 PM EDT Tue Aug 19 the center of Erin was located near 27.7, -73.0 with movement NNW at 12 mph. The minimum central pressure was 959 mb with maximum sustained winds of about 100 mph.</description>
//      <nhc:Cyclone>
//        <nhc:center>27.7, -73.0</nhc:center>
//        <nhc:type>Hurricane</nhc:type>
//        <nhc:name>Erin</nhc:name>
//        <nhc:wallet>AT5</nhc:wallet>
//        <nhc:atcf>AL052025</nhc:atcf>
//        <nhc:datetime>11:00 PM EDT Tue Aug 19</nhc:datetime>
//        <nhc:movement>NNW at 12 mph</nhc:movement>
//        <nhc:pressure>959 mb</nhc:pressure>
//        <nhc:wind>100 mph</nhc:wind>
//        <nhc:headline>...ERIN BECOMING BETTER ORGANIZED AS IT MOVES NORTH-NORTHWESTWARD... ...LIFE-THREATENING RIP CURRENTS EXPECTED ALONG U.S. EAST COAST BEACHES...</nhc:headline>
//      </nhc:Cyclone>
function parseNhcCycloneXml($xmlString) {
// manual parcer to get past changing feeds
    $storms = [];
    $Ctype=""; $Ccenter=""; $Cname=""; $Cdate="";
    $Cmovement=""; $Cwind=""; $Cheadline="";
    $Cpressure=""; $Cdesc=""; $atcf=""; $wallet="";$CdateGMT="";
    $inside = false;

    $lines = explode("\n", $xmlString);
    foreach ($lines as $line) {
        $line = trim($line);
    
            // <pubDate>Sat, 06 Jun 2026 02:33:02 GMT</pubDate>
        if (strpos($line, "<pubDate>") !== false){      $CdateGMT=   extract_xml($line);}   
        if (strpos($line, "<description>") !== false) {continue;} // skip description entirely
        if (strpos($line, "<nhc:Cyclone") !== false) {$inside = true;continue;}
        if (strpos($line, "</nhc:Cyclone>") !== false) {
            $storms[] = [
                'center'   => $Ccenter,
                'type'     => $Ctype,
                'name'     => $Cname,
                'wallet'   => $wallet,
                'atcf'     => $atcf,
                'datetime' => $Cdate,
                'movement' => $Cmovement,
                'pressure' => $Cpressure,
                'wind'     => $Cwind,
                'headline' => $Cheadline,
                'pubdate'  => $CdateGMT,
            ];
            $inside = false;
            $Ctype=$Ccenter=$Cname=$Cdate=$Cmovement=$Cwind=$Cheadline=$Cpressure=$atcf=$wallet="";
            continue;
        }

        if (!$inside) continue;
        // Extract fields
 
        if (strpos($line, "<nhc:center>") !== false){   $Ccenter =   extract_xml($line);}
        if (strpos($line, "<nhc:type>") !== false){     $Ctype =     extract_xml($line);}
        if (strpos($line, "<nhc:name>") !== false){     $Cname =     extract_xml($line);}
        if (strpos($line, "<nhc:wallet>") !== false){   $wallet =    extract_xml($line);}
        if (strpos($line, "<nhc:atcf>") !== false){     $atcf =      extract_xml($line);}
        if (strpos($line, "<nhc:datetime>") !== false){ $Cdate =     extract_xml($line);$Cdate = normalizeCycloneDate($Cdate);} // may be missing a year
        if (strpos($line, "<nhc:movement>") !== false){ $Cmovement = extract_xml($line);}
        if (strpos($line, "<nhc:pressure>") !== false){ $Cpressure = extract_xml($line);}
        if (strpos($line, "<nhc:wind>") !== false){     $Cwind =     extract_xml($line);}
        if (strpos($line, "<nhc:headline>") !== false){ $Cheadline = extract_xml($line);}
    }
    return $storms;
}

function extract_xml($xmlString){
    $start = strpos($xmlString, '>') + 1;
    $end   = strrpos($xmlString, '<');
    return trim(substr($xmlString, $start, $end - $start));
}





function filterActiveCyclones($cyclones) {
    $active = [];

    foreach ($cyclones as $c) {
        $wind = intval($c['wind']);
        $headline = strtoupper($c['headline']);
        $type = strtoupper($c['type']);

        if ($wind === 0) continue;
        if (str_contains($headline, 'DISSIPATED')) continue;
        if (str_contains($headline, 'POST-TROPICAL')) continue;
        if (str_contains($type, 'POST-TROPICAL')) continue;

        $active[] = $c;
    }

    return $active;
}

function getNewestCyclone($cyclones) {
    usort($cyclones, function($a, $b) {
        return strtotime($b['datetime']) - strtotime($a['datetime']);
    });

    return $cyclones[0] ?? null;
}

function isCycloneCurrent($cyclone, $maxAgeHours = 5) {

    if (!$cyclone || empty($cyclone['pubdate'])) {
        return false;
    }

    $advisoryTime = strtotime($cyclone['pubdate']);
    if ($advisoryTime === false) {
        return false;
    }

    $ageSec = time() - $advisoryTime;
    $ageHours = $ageSec / 3600;
    return ($ageHours <= $maxAgeHours);
}

function getCurrentCyclone($xmlString) {
    $cyclones = parseNhcCycloneXml($xmlString);
    $active   = filterActiveCyclones($cyclones);
    if (empty($active)) {        return null;    }
    $newest = getNewestCyclone($active);
    if (!isCycloneCurrent($newest)) {        return null;    }
    return $newest;
}

function decodeZonesFromPointFile($pointFile) {
    if (!file_exists($pointFile)) {        return false;    }
    $json = json_decode(file_get_contents($pointFile), true);
    if (!$json || !isset($json["features"])) {return false;}
    // Look for the first feature with zone info
    foreach ($json["features"] as $f) {
        if (!isset($f["properties"])) { continue; }
        $p = $f["properties"];
        $zones = [
            "forecast" => null,
            "county"   => null
        ];
        // forecastZone URL → extract LAZxxx
        if (isset($p["forecastZone"])) {$zones["forecast"] = basename($p["forecastZone"]);  }
        // county URL → extract LACxxx
        if (isset($p["county"])) {$zones["county"] = basename($p["county"]); }
        // If we found both, return them
        if ($zones["forecast"] && $zones["county"]) {return $zones;}
    }

    return false;
}

function fetchZoneAlerts($zone1, $zone2, $outfile, $ver) {

    $datum = date('m-d-Y H:i:s');
    print "$datum fetch zone alerts - ";

    $urls = [
        "zone1" => "https://api.weather.gov/alerts/active?zone=$zone1",
        "zone2" => "https://api.weather.gov/alerts/active?zone=$zone2"
    ];

    $allFeatures = [];

    foreach ($urls as $label => $url) {

        $debugFile = "/tmp/{$label}_debug.json";

        $start = hrtime(true);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER => true,
            CURLOPT_HTTPHEADER => [
                "Accept: application/cap+xml",
                "Accept-Language: en",
                "User-Agent: la2way.com $ver weather software"
            ]
        ]);

        $raw = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        $elapsed = round((hrtime(true) - $start) / 1e9, 2);

        $headers  = substr($raw, 0, $headerSize);
        $response = substr($raw, $headerSize);

        // ALWAYS save debug file
        file_put_contents($debugFile, $response);

        if ($raw === false || $httpCode !== 200) {

            $debug  = "NWS Zone Fetch Failure ($label):\n";
            $debug .= "URL: $url\n";
            $debug .= "HTTP Code: $httpCode\n";
            $debug .= "Curl Error: $curlErr\n";
            $debug .= "Elapsed: {$elapsed}s\n";
            $debug .= "Headers:\n$headers\n";
            $debug .= "Body saved to: $debugFile\n";

            save_task_log($debug);
            print "\n$debug\n";
            continue;
        }

        // Decode JSON body
        $json = json_decode($response, true);
        if (isset($json["features"])) {
            $allFeatures = array_merge($allFeatures, $json["features"]);
        }
    }

    // Deduplicate by ID
    $unique = [];
    foreach ($allFeatures as $alert) {
        $unique[$alert["id"]] = $alert;
    }

    $final = [
        "type" => "FeatureCollection",
        "features" => array_values($unique)
    ];

    // Save merged zone alerts (even if empty)
    file_put_contents($outfile, json_encode($final, JSON_PRETTY_PRINT));

    print "<ok> $elapsed Sec.\n";
}





function getZonesFromPointsApi($lat, $lon, $ver) {
    global $debugFile;
    $datum = date('m-d-Y H:i:s');
    $url   = "https://api.weather.gov/points/$lat,$lon";
    

    print "$datum fetch zones from points API - ";

    $start = hrtime(true);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => [
            "Accept: application/geo+json",
            "Accept-Language: en",
            "User-Agent: la2way.com $ver weather software"
        ]
    ]);

    $raw = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $elapsed = round((hrtime(true) - $start) / 1e9, 2);

    // Split header/body
    $headers  = substr($raw, 0, $headerSize);
    $response = substr($raw, $headerSize);

    // ALWAYS save the body for debugging
    file_put_contents($debugFile, $response);

    // Error handling
    if ($raw === false || $httpCode !== 200) {

        $debug  = "NWS Points Zone Fetch Failure:\n";
        $debug .= "URL: $url\n";
        $debug .= "HTTP Code: $httpCode\n";
        $debug .= "Curl Error: $curlErr\n";
        $debug .= "Elapsed: {$elapsed}s\n";
        $debug .= "Headers:\n$headers\n";
        $debug .= "Body saved to: $debugFile\n";

        save_task_log($debug);
        print "\n$debug\n";
        print "Error $elapsed Sec.\n";

        return false;
    }

    // Decode JSON
    $json = json_decode($response, true);
    if (!$json || !isset($json["properties"])) {
        print "Invalid points JSON (saved to $debugFile)\n";
        return false;
    }

    $p = $json["properties"];

    $zones = [
        "forecast" => isset($p["forecastZone"]) ? basename($p["forecastZone"]) : null,
        "county"   => isset($p["county"])       ? basename($p["county"])       : null
    ];

    if ($zones["forecast"] && $zones["county"]) {
        print "<ok> $elapsed Sec.\n";
        return $zones;
    }

    print "Missing zone info (see $debugFile)\n";
    return false;
}




function merge_alerts($pointFile, $zoneFile, $mergedFile) {

    $pointData = file_exists($pointFile)
        ? json_decode(file_get_contents($pointFile), true)
        : ["features" => []];

    $zoneData = file_exists($zoneFile)
        ? json_decode(file_get_contents($zoneFile), true)
        : ["features" => []];

    $combined = array_merge($pointData["features"], $zoneData["features"]);

    // Deduplicate by alert ID
    $unique = [];
    foreach ($combined as $alert) {
        $unique[$alert["id"]] = $alert;
    }

    $merged = [
        "type" => "FeatureCollection",
        "features" => array_values($unique)
    ];

    file_put_contents($mergedFile, json_encode($merged, JSON_PRETTY_PRINT));
}





function fetchCapAlerts($lat, $lon, $cacheFile, $ver) {
    $datum  = date('m-d-Y H:i:s');

    print "$datum fetch alerts - ";
    $url = "https://api.weather.gov/alerts/active?point=$lat,$lon";
    $start = hrtime(true);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HEADER => true,   // capture headers for debugging
        CURLOPT_HTTPHEADER => [
            "Accept: application/cap+xml",
            "Accept-Language: en",
            "User-Agent: la2way.com $ver weather software"
        ]
    ]);

    $raw = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $elapsed = round((hrtime(true) - $start) / 1e9, 2);

    // Split header + body
    $headers = substr($raw, 0, $headerSize);
    $response = substr($raw, $headerSize);

    // --- Error handling ---
    if ($raw === false || $httpCode !== 200) {

        $status = "Error";
        if ($elapsed >= 10) { $status .= " timeout"; }

        // Build detailed debug log
        $debug  = "NWS Fetch Failure:\n";
        $debug .= "URL: $url\n";
        $debug .= "HTTP Code: $httpCode\n";
        $debug .= "Curl Error: $curlErr\n";
        $debug .= "Elapsed: {$elapsed}s\n";
        $debug .= "Headers:\n$headers\n";
        $debug .= "Body (first 500 bytes):\n" . substr($response, 0, 500) . "\n";

        save_task_log($debug);print "\n$debug\n";
        
        print "$status $elapsed Sec.\n";

        if (file_exists($cacheFile)) { unlink($cacheFile); }
        return false;
    }

    // --- Save cache ---
    file_put_contents($cacheFile, $response, LOCK_EX);

    print "<ok> $elapsed Sec.\n";
    return true;
}

function fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, $cacheMinutes = 60, $cron = false) {
    $datum  = date('m-d-Y H:i:s');
    $url = "https://www.nhc.noaa.gov/" . ltrim($cycloneURL, "/");
    $now = time();
    $file=$cyclone;
    // --- Check Cache Age ---
    if (file_exists($file)) {
        $ageSec = $now - filemtime($file);
        $ageMin = floor($ageSec / 60);

        echo "$datum Cyclone cache age: {$ageMin} minutes (limit: {$cacheMinutes})\n";

        if ($ageMin < $cacheMinutes && !$cron) {
            echo "$datum Using cached cyclone data (fresh enough)\n";
            return true;
        }

        echo "$datum Cache expired — fetching new cyclone data\n";
    } else {
        echo "$datum No cyclone cache found — fetching new data\n";
    }

    // --- Fetch New Data ---
    $start = microtime(true);
    print"$datum Polling nhc.noaa.gov .... $cycloneURL\n"; save_task_log("Polling $url");
    $headers = [
        "Accept: application/xml",
        "Accept-Language: en",
        "User-Agent: $ver ca-warn HAM Allstar"
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_FAILONERROR    => false,
    ]);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $elapsed = round(microtime(true) - $start, 2);

    // --- Error Handling ---
    if ($response === false || $httpCode >= 400) {
        echo "$datum NHC fetch error after {$elapsed} sec — keeping old cache\n";
        save_task_log("NHC fetch error, keeping old cache");
        return false;
    }

    // --- Save New Cache ---
    file_put_contents($file, $response, LOCK_EX);

    echo "$datum Cyclone data updated in {$elapsed} sec\n";
    save_task_log("Updated cyclone cache: $file");

    return true;
}


function save_task_log($status) {
    global $basename, $path,$logDir,$log ;

    $status = str_replace(',', ' ', $status);
    $datum  = date('m-d-Y H:i:s');



    // Ensure log directory exists
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

  // Build log line
    $line = "$datum,$status,$basename,,,\n";

  // Write to log
    file_put_contents($log, $line, FILE_APPEND | LOCK_EX);
}


function read_api($file) {
    global $NWheadline, $instruction, $headline, $event,
           $icon, $shortForcast, $detailedForecast,
           $url, $description, $apiVer;

    // Reset variables
    $NWheadline = "";
    $instruction = "";
    $headline = "";
    $event = "";
    $icon = "";
    $shortForcast = "";
    $detailedForecast = "";
    $url = "";
    $description = "";
    $apiVer = "";

    // Read + decode JSON
    $json = json_decode(file_get_contents($file), true);
    if (!$json) { save_task_log("JSON decode error in $file"); print "decode Error\n";       return false;    }

    // Extract version
    $apiVer = $json['@version'] ?? "";

    // Extract properties
    $props = $json['properties'] ?? [];

    $headline        = $props['headline']        ?? "";
    $description     = $props['description']     ?? "";
    $instruction     = $props['instruction']     ?? "";
    $event           = $props['event']           ?? "";
    $NWheadline      = implode("|", $props['NWSheadline'] ?? []);
    $url             = $props['forecast']        ?? "";
    $shortForcast    = $props['shortForecast']   ?? "";
    $detailedForecast= $props['detailedForecast']?? "";
    $icon            = $props['icon']            ?? "";

    // Normalize icon size
    if ($icon) { $icon = str_replace("size=medium", "size=small", $icon); }
    return true;
}





function isHurricane($type) {
    $type = strtolower(trim($type));
    return strpos($type, "hurricane") !== false;
}



// Helper function to parse coordinates from string like "38.3, -50.8"
function parseCoordinates($center) {
    $parts = explode(',', $center);
    if (count($parts) != 2) return [null, null];
    return [floatval(trim($parts[0])), floatval(trim($parts[1]))];
}


function watchdog(){
// not used in this release. 
// part of net going down detection
}
function read_api_json_alerts($file) {
    global $event, $headline, $description, $instruction,$debug,$datum;


    $event = [];
    $headline = [];
    $description = [];
    $instruction = [];

    if (!file_exists($file)) {
        print"$datum File not found $file\n";
        return false;
    }

    $json = file_get_contents($file);
    $data = json_decode($json, true);

    if (!isset($data['features']) || !is_array($data['features'])) {
        return false;
    }

    foreach ($data['features'] as $f) {
        if (!isset($f['properties'])) continue;

        $p = $f['properties'];

        $event[]       = $p['event']       ?? "";
        $headline[]    = $p['headline']    ?? "";
        $description[] = $p['description'] ?? "";
        $instruction[] = $p['instruction'] ?? "";
    }

    return true;
}
// (c)2026 module to play through ASL3
// $FILE MUST BE THE OUTPUT
function playSound($out){
   global $file,$action,$node,$status,$local,$outTmp,$out,$datum;
//   print"$datum 'sox $action $file' \n";
   exec ("sox $action $file",$output,$return_var);
   playSoundOnly($out);
}

function playSoundOnly($out){
   global $file,$action,$node,$status,$local,$outTmp,$out;
   $datum   = date('m-d-Y H:i:s');$out ="Playing file $file";save_task_log ($out);print "$datum $out\n";
   $base = pathinfo($file, PATHINFO_FILENAME);
   if($local){  exec("sudo asterisk -rx 'rpt localplay $node /tmp/$base'",$output,$return_var);}
   else{  exec("sudo asterisk -rx 'rpt playback $node /tmp/$base'",$output,$return_var);}
$action="";// clear the buffer
$filesize = filesize($file);   // bytes
$duration = $filesize / 1650;         // seconds (GSM 13.2kbps)
$duration = ceil($duration);          // round up for safety
print "$datum GSM duration approx $duration seconds\n";
sleep($duration);
sleep(9);
}



//
// Special use
function playSoundDesktop() {
   global $file,$action,$outTmp,$datum;
   $desktopMode = !file_exists("/usr/sbin/asterisk");
   exec("sox $action $file", $output, $return_var);
   $datum = date('m-d-Y H:i:s');$msg = "Playing file $file";save_task_log($msg);print "$datum $msg\n";
   exec("nohup cvlc --play-and-exit --gain=2.0 '$file' >/dev/null 2>&1 &");
}

function detectAudioFormat($audioData) {

    // MP3 signatures
    if (substr($audioData, 0, 2) === "\xFF\xFB" ||
        substr($audioData, 0, 2) === "\xFF\xF3" ||
        substr($audioData, 0, 2) === "\xFF\xF2") {
        return "mp3";
    }

    // WAV signature
    if (substr($audioData, 0, 4) === "RIFF" &&
        substr($audioData, 8, 4) === "WAVE") {

        // Extract data chunk size
        $pos = strpos($audioData, "data");
        if ($pos !== false) {
            $sizeBytes = substr($audioData, $pos + 4, 4);
            $expected = unpack("V", $sizeBytes)[1];
            $actual   = strlen($audioData) - ($pos + 8);

            // If mismatch → it's actually MP3
            if ($expected !== $actual) {
                return "mp3";
            }

            return "wav";
        }
    }

    // Unknown → treat as MP3
    return "mp3";
}




?>

