<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// This is for advanced users you likely should not touch
//
// Some of these are for future use. 
//
// You may copy anything here into your config to overide these values
//
// yes it can talk global but only for special uses. 
// 
// Danger set to false and its global. For use on a hub not connected to external networks.
// Dont blame me if people yell at you . this is included for my use,
// Never turn off local on a node or repeater.


$local    = true;
// Turns the speach off. just for testing will be part of something else.
$talkFlag = true;
// standard flag to display extra debuging data in testing

$specialExpand=false;  // will the expanded repeat.

// Skiping alerts was in older version and removed.
// Its still here in case I want to reinstall it.
$SoundType= "ASL";// for desktop sound switching.
$sayWarn     =true;
$sayWatch    =true;
$sayAdvisory =true;
$sayStatement=true;

// for the PI temp reporting.
// set the way you want to prevent false alarms
//$hot=57; 
//$high=60;
$nodeName="node"; // Like node temp is high
$reportAll=false;// debugging for temp. Reports everything

// there are unused paths for expansion with my time clock and forcasting.
$path = "/usr/share/cap-warn";
$pathI = "/usr/share/cap-warn";

// I use this on my hub set before connecting to another hub. 
// unlink when you disconnect that way it wont talk during a net. 
// could use cron to create it during nets.
$linked_file = "/tmp/linked_true.txt";


$outTmp    ="/tmp/tmp.gsm"; 
$alertTxt  ="/tmp/warn.txt";
$tailfile  ="/tmp/warn-tail.gsm";

// if debug is on it reads this fake file
$debug    = false;
$testalertxml ="$pathI/test_alert.xml";

// undervoltage high temp holdback (antispammer)
$flag2    = "/tmp/alert-temp-played.txt"; 
$uv_file  = "/tmp/temp_alarm_counter.txt";
$uv_limit = 10;   // max alarms per day

// This file exists when any of my other scripts start talking it prevents 
// overtalk however als3 may not do that anymore. included for old support
$clash       ="/tmp/mmweather-task.txt";
$logDir = "/var/log/cap-warn";

$alertxml    ="/tmp/alert.json";  // What we get from the NWS
$alertxml_point = "/tmp/alerts_point.json";
$alertxml_zone  = "/tmp/alerts_zone.json";
$debugFile = "/tmp/points_zone_debug.json";

// reserved for the forcast module. not yet implimented in stand alone mode..

$forcastxml  ="/tmp/geocode.xml"; // just held in memory now,
$forcastxml2 ="/tmp/forcast.xml"; // weather

$currentxml  ="/tmp/current.xml"; // weather future
$currentTxt  ="/tmp/current.txt"; // weather future


$alertTxtHeadline    ="/tmp/warn_headline.txt";
$alertTxtDescription ="/tmp/warn_description.txt";  
$special     ="/tmp/warn_special-weather.gsm";
$specialUL   ="/tmp/warn_special-weather.ul";
$specialGSM  ="/tmp/warn_special-weather-out.gsm";
$specialTXT  ="/tmp/warn_special-weather.txt";
$cyclone     ="/tmp/cyclone.xml";// comes from the huricane center feed 
$cycloneTxt  ="/tmp/cyclone.txt";// parsed standard text 

$flag  = "/tmp/alert-played.txt"; 


$cycloneWAV="/tmp/cyclone.wav";
$cycloneGSM="/tmp/cyclone.gsm";
$cycloneMP3="/tmp/cyclone.mp3";
$cycloneUL ="/tmp/cyclone.ul";

$cycloneLast = "$logDir/cyclone_key.log";

// set in config.php
//$cycloneURL  = "/gis-at.xml"; // set from ones listed at cyclone update ///https://www.nhc.noaa.gov/aboutrss.shtml
//  Atlantic Basin GIS Data:  gis-at.xml
//  Eastern Pacific Basin GIS gis-ep.xml
//  Central Pacific Basin GIS gis-cp.xml 

$soundPath = "$path/sounds";
$log    = "$logDir/cap-warn.log";


// Upgrade protection for older versions
// Ignore this. It prevents older users from having to run setup
// to get new options. Basic delault settings
$hurOnly = false; 



?>
