<?php
//  ------------------------------------------------------------
//  (c) 2023/2026  by KJ5MZL WRXB288 lagmrs.com all rights reserved
//
//    for allstar gmrs nodes to keep track of the temp
// -------------------------------------------------------------
//
//   _____ _____  _    _   _______                     __  __             _ _             
//  / ____|  __ \| |  | | |__   __|                   |  \/  |           (_) |            
// | |    | |__) | |  | |    | | ___ _ __ ___  _ __   | \  / | ___  _ __  _| |_ ___  _ __ 
// | |    |  ___/| |  | |    | |/ _ \ '_ ` _ \| '_ \  | |\/| |/ _ \| '_ \| | __/ _ \| '__|
// | |____| |    | |__| |    | |  __/ | | | | | |_) | | |  | | (_) | | | | | || (_) | |   
//  \_____|_|     \____/     |_|\___|_| |_| |_| .__/  |_|  |_|\___/|_| |_|_|\__\___/|_|   
//                                            | |                                         
//                                            |_| 


//
// From the PI specs: https://www.raspberrypi.com/documentation/computers/processors.html
//Pi must stay below 85c at all times. To be safe 70 is my danger zone. 
//The PI will regulate its own temp by throttling down when its hot, 
//but throttling down reduces cpu cycles. 
//
//
//  ------------------------------------------------------------
//   MODULE: TEMP.PHP
//   DO NOT FOLD, SPINDLE, OR MUTILATE
//   IF RUN STAND-ALONE: EXIT ON FAILURE
//   IF INCLUDED: RETURN CONTROL TO CALLER
//   ------------------------------------------------------------ 
//   
// v2.4 09/18/23 intergration into odd_min.php chron.
// v2.5 12/10/23 Bug fix systax error con printout
// v2.6 12/31/23 Tagline cleanup 
// v2.7 1/10/24 temp log moved and purging added.
// v2.8 10/25/25
// v2.9 05/25/2026 Conversion to a module of cap-warn
require_once("/etc/cap-warn/config.php");
require_once("/etc/cap-warn/advanced_config.php");
// Program directory for internal includes
$pathI = "/usr/share/cap-warn";
include_once("$pathI/sound_db.php");
include_once("$pathI/cap_functions.php");

$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else( continue;)// this is a safety likely will remove later



$out="";
//$log    = "$logDir/cap-warn.log";  Log is set in config 
//$log="$path/logs/cpu_temp_log.txt";

$datum = date('m-d-Y-H:i:s');
$temp="";$tempf="";
// /sys/class/thermal/thermal_zone0/temp
// /opt/vc/bin/vcgencmd measure_temp
// --- Try vcgencmd first ---
$line = exec("sudo /usr/bin/vcgencmd measure_temp 2", $output, $return_var);

if ($return_var === 0 && !empty($line) && strpos($line, 'temp=') !== false) {
    // vcgencmd worked
    $line = trim($line);
    $line = str_replace("'", "", $line);
    $parts = explode("=", $line);
    $temp = isset($parts[1]) ? (float)trim($parts[1]) : 0;
} else {
    // --- Fallback: /sys/class/thermal (Pi 5 safe, no vcgencmd needed) ---
    $sys_temp = @file_get_contents('/sys/class/thermal/thermal_zone0/temp');
    if ($sys_temp !== false) {
        $temp = $sys_temp / 1000;  // millidegrees → °C
    } else {
        $temp = 0;

    }
}




$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum Temp is $tempf F $temp C \n";

// ----  vcgencmd throttle monitor  ----
// Runs every 10 min from cron / PHP scheduler

$cmd   = '/usr/bin/vcgencmd get_throttled';
$line  = trim(shell_exec("sudo $cmd 2>/dev/null"));
if (!$line) { save_task_log('ERROR: vcgencmd failed');}
// Example output: throttled=0x50005
if (!preg_match('/^throttled=0x([0-9a-f]+)$/i', $line, $m)) { save_task_log("ERROR: unexpected output: $line");}

$hex = $m[1];                     // e.g. "50005"
$val = hexdec($hex);              // integer 327685

// ----  Bit definitions (official Raspberry Pi)  ----
$messages = [];

if ($val & 0x00001) $messages[] = 'under-voltage-detected';
if ($val & 0x00002) $messages[] = 'arm-frequency-capped';
if ($val & 0x00004) $messages[] = 'currently-throttled';
if ($val & 0x00008) $messages[] = 'soft-temp-limit-active';

// these stick till a reboot,,,, 
//if ($val & 0x10000) $messages[] = 'under-voltage-has-occurred';
//if ($val & 0x20000) $messages[] = 'arm-frequency-capping-has-occurred';
//if ($val & 0x40000) $messages[] = 'throttling-has-occurred';
//if ($val & 0x80000) $messages[] = 'soft-temp-limit-has-occurred';

$throttled = $messages ? implode('_ ', $messages) : '';

// under-voltage-detected,-currently-throttled,-under-voltage-has-occurred,-throttling-has-occurred
// ----  Log / output  ----
$datum = date('Y-m-d H:i:s');
if($throttled){save_task_log($throttled);echo "$datum $throttled\n";}



if (!$reportAll and $temp <=$hot and !$throttled){$TMPstatus="ok";}
else{
$TMPstatus="REPORT";
$cmd=""; $action="";
check_sound("star dull");if($file1){$action = "$action $file1";}
check_sound($nodeName);if($file1){$action = "$action $file1";} // Name (server,repeater,node,tower,temperature) or any name in the database.");
list($whole, $decimal) = explode('.', $temp);
$oh=false;make_number ($whole);$action = "$action $actionOut";
if($decimal>=1){
check_sound("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";
}
check_sound("degrees");if($file1){$action = "$action $file1";} 
check_sound("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){ //emergency,beep,attention-required 
  $status ="CPU HOT $temp";save_task_log ($status);
 if ($temp >=$high){// 2 phase alert hot and emergency
  check_sound("emergency");if($file1){$action = "$action $file1";}
  check_sound("warning");if($file1){$action = "$action $file1";}
  check_sound("attention-required");if($file1){$action = "$action $file1";}
  } 
else{
  check_sound ("alert");if($file1){$action = "$action $file1";}
  check_sound ("high");if($file1){$action = "$action $file1";}
  }

check_sound("beep");if($file1){$action = "$action $file1";} 
}// end of high


if ($throttled){
   check_sound ($throttled);if($file1){$action = "$action $file1";}  
   check_sound("star dull");if($file1){$action = "$action $file1";}
}
check_sound ("silence1");if($file1){$action = "$action $file1";}

// $outtmp is our temp file shared
$file=$outTmp;playSound($out); 

}






?>

