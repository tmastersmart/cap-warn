<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.
//
//
//CAP‑Warn is a modern weather alert system designed as a full replacement for older Skywarn and Skywarn2 scripts.  
//It uses the current National Weather Service (NWS) alert format and provides a far more reliable, 
//automated experience for repeaters and AllStar nodes.
//
//Because CAP‑Warn is distributed through an APT repository, your system automatically receives updates
// — no manual patching, editing, or file replacement required.
//
//CAP‑Warn retrieves alerts directly from the National Weather Service CAP system and the 
//National Hurricane Center (nhc.noaa.gov).  
//These alerts are converted into high‑quality audio and played over your node, keeping operators informed even
//during rapidly changing weather conditions.
//
//Although the NWS API returns alerts in GeoJSON/JSON‑LD, the underlying data is still CAP 1.2, the official federal
// standard for public warning messages.
//The API simply transforms the raw CAP XML into a clean, consistent JSON structure. This avoids the formatting issues, 
//namespace problems, and broken XML that caused many older scripts to fail when legacy CAP endpoints were deprecated.
//
//CAP‑Warn uses the modern, supported, and recommended NWS API format, ensuring long‑term compatibility with the current
// alerting system.
//
//On Raspberry Pi systems, CAP‑Warn can also monitor CPU temperature and issue high‑temperature alarms.

// Replaces existing no warning scripts .

// Why PHP it works better sharing code with the webserver and works anywhere.

// v3.4 10-05-23  Major changes to weather API
// v3.5 10/14/2023  FEMAQ added
// v3.6 10/21/2023  Muting adjustments
// v3.7 10/31/2023  Logging improvements
// v3.8 11/02/2023  Fixed old files not clearing; removed legacy artifacts
// v3.9 11/07/2023  Stopped duplicate burst
// v4.0 11/20/2023  Debugging info on muting
// v4.2 01/13/2024  Cleanup and anti‑clash changes
// v4.3 01/17/2024  Bug fix in clear status
// v4.4 01/21/2024  Watch statement flags; new sounds
// v4.4 01/29/2024  Weather functions moved to separate file
// v4.5 02/11/2024  WAV playback bug; converted all to GSM; debug mode added
// v4.6 01/20/2025  Mods for the image
// v4.7 02/15/2025  Clash flag fix
// v4.8 03/28/2026  Full alert read for Special Weather Statement
// v5.0 05/11/2026  Created Standalone system with installers
// v5.0.6 05/24/2026 rebuilt functions from scratch for newer php
// v5.1._ 05/31/2026 Moving huricane into seperate module for easer maintance

$pathI = "/usr/share/cap-warn";
$verFile = "$pathI/version.txt";
$relFile = "$pathI/release.txt";
if (file_exists($verFile)) { $ver = "v" . trim(file_get_contents($verFile));} 
else { $ver = "v5.1.0";}
if (file_exists($relFile)) {  $release = trim(file_get_contents($relFile));}
else { $release = "6/6/2026";}
$zone = trim(shell_exec('timedatectl show -p Timezone --value'));
if (!$zone) {    $zone = 'America/Chicago';}
date_default_timezone_set($zone);
$phpzone = date_default_timezone_get();
require_once("/etc/cap-warn/advanced_config.php");// load first allows config to overide
require_once("/etc/cap-warn/config.php");
include_once("$pathI/sound_db.php");
include_once("$pathI/cap_functions.php");
$lat = trim($lat);$lat = preg_replace('/[^0-9\.\-]/', '', $lat);
$lon = trim($lon);$lon = preg_replace('/[^0-9\.\-]/', '', $lon);

// Safety if no tailfile repair
if (!file_exists($tailfile)){  
 if (file_exists($alertTxt)){unlink($alertTxt);} 
 if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
}
//using the command cron resets the hold off timmer
$cron=false;if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;} }
$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m  -s -o -v');}
$phpVersion= phpversion();$CAPstatus="Clear";
$time= date('H:i');
$date =  date('m-d-Y');
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
$action=""; $event="";
print "
=====================================================================
Cap Warm $ver 
Storm tracking alert system 
(c)2023/2026 KJ5MZL WRXB288 LA2WAY.com LAGMRS.com all rights reserved
$phpzone PHP v$phpVersion   Release date:$release
=====================================================================
$datum Node:$node UTC:$gmdatum 
$datum Model: $piVersion
$datum Lat:$lat Lon:$lon
";
if (!$local){print"$datum IN GLOBAL MODE\n";}
if ($tts){print"$datum Using voicerss.org API\n";}


if (file_exists($flag)) {
    $ageSeconds  = time() - filemtime($flag);
    $ageMinutes  = floor($ageSeconds / 60);
    echo "$datum Hold flag age: {$ageMinutes} minutes (limit: {$theHoldtime} minutes)\n";
    if ($ageSeconds > ($theHoldtime * 60)) {        echo "$datum Hold expired — resetting play timer.\n";        unlink($flag);    }
    elseif ($cron) {        echo "$datum Cron override — resetting play timer.\n";        unlink($flag);    }
    else {        echo "$datum Skipping playback — still within hold window.\n";    }
}
//else {    echo "$datum No hold flag — playback allowed.\n";}



// the clash file stops other processed from playing at the same time
if(file_exists($clash)){
 $out="Waiting for other threads. "; print"$datum $out\n"; if($debug){save_task_log ($out);}
 sleep(90);
 // safety clear abandoned flags
 if(file_exists($clash)){   // fix for file being erased in loop
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);} 
 } // 10 mins
}
$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);



//if (file_exists($tailfile)){print "$datum found: $tailfile\n";}   
//if (file_exists($alertTxt)){print "$datum found: $alertTxt\n";} 
//if (file_exists($alertTxtHeadline)){print "$datum found: $alertTxtHeadline\n";}
// test for mute move to start
$hour=date('H');$day=date('D');
if(!$cron){
$mute=false;
if($sleep){
 if($hour>=1 and $hour <=6){
 $mute=true;$out="Sleep Mute $day $hour am";save_task_log ($out);print "$datum $out\n";
  }
 }
}
else{$mute=false;}

$fetch=true;



// fetch updates....
if (file_exists($alertxml)) {
    $age_seconds = time() - filemtime($alertxml);
    $age_minutes = round($age_seconds / 60, 1); // one decimal place
    // Cache is fresh if age < 5 minutes
    if ($age_seconds < 300) {$fetch = false;}
    echo "$datum Alert cache age: {$age_minutes} minutes\n";
}

if($fetch){
fetchCapAlerts($lat, $lon, $alertxml_point, $ver);
//Get zones from points API 
$zones = getZonesFromPointsApi($lat, $lon, $ver);

    if ($zones) {
        $zone1 = $zones["forecast"];$zone2 = $zones["county"];
        echo "$datum Alert zones $zone1 $zone2\n";
        fetchZoneAlerts($zone1, $zone2, $alertxml_zone, $ver);
        // 4) Merge point + zone into main file
        merge_alerts($alertxml_point, $alertxml_zone, $alertxml);
    }
else{copy($alertxml_point, $alertxml);}
}

                                                  
else{print"$datum Using Cached file Alerts\n";}
                                                           
if ($debug) {
$alertxml=$testalertxml;
$out="Test Alert DEBUG mode [FAKE] $alertxml ";save_task_log ($out);print "$datum $out\n";
// change the filename to point to the test file

}                                                                 
read_api_json_alerts($alertxml);                                                             
                                                             
                                                             



$datum   = date('m-d-Y H:i:s');
$events       = "";
$headlines    = "";
$descriptions = "";
$instructions = "";

$count = count($event);
for ($i = 0; $i < $count; $i++) {

    if ($i == 0) {
        // first item: no leading separators
        $events       .= $event[$i];
        $headlines    .= $headline[$i];
        $descriptions .= $description[$i];
        $instructions .= $instruction[$i];
    } else {
        // subsequent items: prepend separators
        $events       .= "," . $event[$i];
        $headlines    .= "|" . $headline[$i];
        $descriptions .= "|" . $description[$i];
        $instructions .= "|" . $instruction[$i];
    }
}
$descriptions = str_replace(["\n", "\r", "*", "#", "~"], " ", $descriptions);
$descriptions = trim($descriptions);


if($events){print"$datum Events: $events\n";}
else{all_clear("ok");$events="";}
// set the status
if ($events){
  $CAPstatus="new";
  if (file_exists($alertTxt) ){
  $test = file_get_contents($alertTxt);
  if ($test <> $events){print "$datum Events have changed\n";$CAPstatus="new";save_task_log ("new Alert $events");}
 else {$CAPstatus="no change";print "$datum Existing Event file [$CAPstatus]\n";}
 }
}
// there is already a audio file since its not changed.
if ($CAPstatus == "no change" && !file_exists($flag)) {
    $min = date('i');
    if ($debug) { $min = 30; } // force test window
       echo "$datum Minute check: current minute = $min (window: 10–50)\n";
       if ($min >= 10 && $min <= 50) {
       $file=$tailfile;playSoundOnly($out);
       $CAPstatus="Playing Tail File";
       $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}
 else { echo "$datum Skipping — outside 10–50 minute window (current: $min)\n"; $CAPstatus="mute";}
}
//else {$CAPstatus="mute";}

// its diffrent we need to build the file.
$datum   = date('m-d-Y H:i:s');
if ($CAPstatus=="new"){

print "$datum Creating new event files.\n";
$fileOUT = fopen($alertTxt,'w');fwrite ($fileOUT,$events);fclose ($fileOUT);
$fileOUT = fopen($alertTxtHeadline,'w');fwrite ($fileOUT,$headlines);fclose ($fileOUT);
$fileOUT = fopen($alertTxtDescription,'w');fwrite ($fileOUT,$descriptions);fclose ($fileOUT);
// lets save some log data on the events, 
archive_json($alertxml);
archive_json($alertxml_point);
archive_json($alertxml_zone);
archive_json($debugFile);


save_task_log ($events); // save it to the log

$file = $tailfile;if(file_exists($file)){unlink($file);} // kill the last tail file to prevent it launching during play

// has-issued-a,has-expired,weather-station,weather,
check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_gsm_db  ("weather service");             if($file1){$action = "$action $file1";}

$watchSTATUS="alert";

$all = strtolower($events);
 if (strpos($all, "statement") !== false){ $watchSTATUS="Special Weather Statement";   }
 if (strpos($all, "advisory") !== false) { $watchSTATUS="advisory";       }
 if (strpos($all, "watch") !== false)    { $watchSTATUS="watch";        } 
 if (strpos($all, "warning") !== false)  { $watchSTATUS="warning";    }


print "$datum Alert(s) Detected $watchSTATUS\n";
if ($watchSTATUS){check_gsm_db ($watchSTATUS);if($file1){$action = "$action $file1";}} 

// break out the desct to create a tts file

$firstSWS = "";
foreach ($event as $i => $ev) {
if (stripos($ev, "special weather statement") !== false || $expanAlert == true) {

        // CLEAN DESCRIPTION
        $ds = $description[$i];

        // Remove formatting
        $ds = str_replace(["*", "•", "- "], " ", $ds);
        $ds = preg_replace('/\b(WHAT|WHERE|WHEN|IMPACTS|ADDITIONAL DETAILS)\b[:]?/i', '', $ds);
        $ds = preg_replace('/\s+/', ' ', $ds);
        $ds = trim($ds);

        // Extract first 1–2 sentences
        $sentences = preg_split('/(?<=[.?!])\s+/', $ds);
        $firstSWS = trim(implode(' ', array_slice($sentences, 0, 2)));
        
        print"$datum TTS on Desc \n";
        break; // only the first one matters
    }
$sentences = preg_split('/(?<=[.?!])\s+/', $firstSWS);
$firstSWS = trim(implode(' ', array_slice($sentences, 0, 2)));
}

$previous_text = "";if (file_exists($specialTXT)) {    $previous_text = file_get_contents($specialTXT);}
// Compare old vs new
$skip_build = false;if (trim($previous_text) === trim($firstSWS)) {echo "$datum Description unchanged \n";$skip_build = true;}

if (!$skip_build){



 if ($tts){
 print "$datum Building sound TTS Key\n";
// Create an instance of the VoiceRSS class
$voiceRSS = new VoiceRSS();
// Define the settings for the speech request
$settings = array(
    'key' => $tts,
    'src' => $firstSWS, // Your text here
    'hl' => 'en-us', // Language (English - US)
    'v'  => 'Amy', // Voice (optional)
    'r'  => '0', // Rate (optional)
    'f'  => '8khz_16bit_mono',
    'c'  => 'wav', // Format 
);

// Call the speech function to get the response
$response = $voiceRSS->speech($settings);
// Check if there was an error in the response
if ($response['error']) {  echo "Error: " . $response['error'];}
else { $mp3Data = $response['response']; // The MP3 binary data
    if (file_put_contents($special, $mp3Data)) { 
    echo "$datum $special saved successfully \n";
    echo "$datum ALERT Transcribed $firstSWS \n";
    $fileOUT = fopen($specialTXT,'w');flock ($fileOUT, LOCK_EX );fwrite ($fileOUT,$firstSWS);flock ($fileOUT, LOCK_UN );fclose ($fileOUT);
    echo "$datum $specialTXT saved successfully \n";
    }
    else {$out="Failed to save $specialTXT";save_task_log ($out);print "$datum $out\n";}
  }
 }// end of if TSS
 else {
    // ---------------------------------------
    // Fallback path: use asl-tts (no API key)
    // ---------------------------------------
    print "$datum Building sound asl-tts \n";
 $specialUL_noext = preg_replace('/\.[a-z0-9]+$/i', '', $specialUL);
    $cmd = "asl-tts -n $node -t " . escapeshellarg($firstSWS) . " -f " . escapeshellarg($specialUL_noext);
    exec($cmd, $output, $return);

    if ($return === 0) {
        echo "$datum $specialUL generated via asl-tts\n";
        file_put_contents($specialTXT, $firstSWS);
    }
 else { $out="ERROR: asl-tts failed to generate audio";save_task_log ($out);print "$datum $out\n";}
}
 
 
}// end skip build
else {print "$datum Skip TTS build\n";}




// build that file
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space between them
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$u= explode(",",$events); 
$burnban=false;
foreach($u as $line){
$line = strtolower($line);
if($line){ check_gsm_db($line);if($file1){$action = "$action $file1";} } 
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_gsm_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
 
}// end for loop

if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 
$datum   = date('m-d-Y H:i:s'); 

if(!$mute){
$file=$outTmp;
playSound($out); 
$fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}

// build the shorter tail file
// This is the same as above with the updated weather information notice
$action="";
check_gsm_db  ("silence1"); if($file1){$action = "$action $file1";}
$u= explode(",",$events);$burnban=false;

foreach($u as $line){
check_wav_db  ("star dull"); if($file1){$action = "$action $file1";}

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }

// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message once Prevents dupes
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){
 if(!$burnban){
   check_gsm_db ("Burn Ban");
   if($file1){ $action = "$action $file1"; $burnban=true;}
  }
 }
if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 


// $tailfile  ="/tmp/skywarn-tail.wav";  
exec ("sox $action $tailfile",$output,$return_var);
$out="Tailfile updated $tailfile";save_task_log ($out);print "$datum $out\n";
 }
}// end if new

if($detectCyclone==true)  {include_once("$pathI/cap_cyclones.php");}
else{print"$datum Cyclone disabled\n";}


$min = intval(date('i'));
if ($detectCyclone == true) {
    // Only run cyclone logic between :10 and :50
    if ($min >= 10 && $min <= 50) { print "$datum Cyclone window OK (minute=$min)\n"; include_once("$pathI/cap_cyclones.php"); }
   else { print "$datum Cyclone check skipped — outside 10–50 minute window (minute=$min)\n"; }
 } 
 else {print "$datum Cyclone disabled\n";}



if($piSystem && $piAlarms){include_once("$pathI/cap_temp.php");}








$datum = date('m-d') . "-1965 " . date('H:i:s');
print "$datum End of Line. Next Punch Card Please.  \n";
print"=====================================================================\n";
if(file_exists($clash)){unlink($clash);}

// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.





?>