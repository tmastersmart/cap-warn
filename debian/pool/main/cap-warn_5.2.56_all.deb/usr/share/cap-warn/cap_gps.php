<?php
// (c) 2026 KJ5MZL / WRXB288

// Cap-Warn-GPS mark II 6/23/26


$Gdebug=false;
function  fetchGPS() {
global  $cdebug,$datum ,$Gdebug  ;// glob 
$fix=false;
$det=shell_exec("pgrep gpsd") ;

// i dont have one of these GPSD units sio this is beta code 
if($det){
debug1("GPSD detected");
$in=shell_exec("gpspipe -w -n 5 2>/dev/null | grep TPV | head -n 1");debug1($in);
$read=json_decode($in,true);

if ($read['lat'] && $read['lon']){$fix=true;}
else {$fix=false;}
if($read && !$fix){print"$datum GPSD (mode={$read['mode']})\n";}
if($fix){ print"$datum GPS: Using GPSD\n";return [$read['lat'],$read['lon']];}


}// end if det

// NEMA 100% working now.
$u=glob("/dev/serial/by-id/*");
foreach($u as $d){
 $p=fetchNema($d);
 if($p==="NOFIX")continue;
 if(is_array($p)){print"$datum GPS:$d\n";return $p;}
}

$u=glob("/dev/ttyACM*");
foreach($u as $d){
 $p=fetchNema($d);
 if($p==="NOFIX")continue;
 if(is_array($p)){print"$datum GPS:$d\n";return $p;}
}

$u=glob("/dev/ttyUSB*");
foreach($u as $d){
 $p=fetchNema($d);
 if($p==="NOFIX")continue;
 if(is_array($p)){print"$datum GPS:$d\n";return $p;}
 }// end usb


}// end fun

function  debug1($inD){
global  $cdebug,$datum ,$Gdebug  ;// glob 
if (!$Gdebug){return;}
$cdebug++;
print "$datum Debug $cdebug $inD\n";
}

function fetchNema($device){
global  $cdebug,$datum ,$Gdebug  ;// glob 

$raw=shell_exec("timeout 1 cat $device 2>/dev/null | grep GGA | head -n 1");
if($raw){debug1("NEMA $raw");}
else {debug1("NEMA NULL");return false;}

$u=explode(",",$raw);
$fix=0;$st=0;
if(isset($u[6]) && is_numeric($u[6])){$fix=$u[6];}
if(isset($u[7]) && is_numeric($u[7])){$st=$u[7];}

$type="Uk";

if($fix==0){$type="No Fix";}
if($fix==1){$type="GPS Fix";}
if($fix==2){$type="DGPS Fix";}
if($fix==4){$type="RTK Fixed";}
if($fix==5){$type="RTK Float";}
if($fix==6){$type="Dead Reck";}
if($fix==7){$type="Manual";}
if($fix==8){$type="Sim";}
if($fix==0||$st=="00") { print "$datum GPS $device Sats:$st Fix:$type\n"; return "NOFIX"; }


if (isset($u[8])){$hdop=$u[8];}
else{$hdop="N/A";}
$rate="Unk";
$acc="N/A";
if(is_numeric($hdop)){
   if($hdop<=1){$rate="Greatt";}
   if($hdop>1 && $hdop<=2){$rate="Good";}
   if($hdop>2 && $hdop<=5){$rate="Fair";}
   if($hdop>5 && $hdop<=10){$rate="Poor";}
   if($hdop>10){$rate="Bad";}
   $acc=round($hdop*5,1);// meters 
 }// end hop
print "$datum GPS sat:$st fix:$type hdop:$hdop $rate $acc m)\n";

return Ndecode($raw);
}


function Ndecode($in){
global  $cdebug,$datum ,$Gdebug  ;// glob 

$explod=explode(",",$in);$count=count($explod);
if ($count<6){ return false;}
$latRaw=$explod[2];$lonRaw=$explod[4];
// check or invalid fields
if(!$latRaw||!$lonRaw){return false;}
if(!is_numeric($latRaw)||!is_numeric($lonRaw)){ return false;}

$latHem=$explod[3];$lonHem=$explod[5];

$lat=floor($latRaw/100);$lat=$lat+fmod($latRaw,100)/60;
$lon=floor($lonRaw/100);$lon=$lon+fmod($lonRaw,100)/60;

if ($latHem==="S") $lat=-$lat;
if ($lonHem==="W") $lon=-$lon;

return [round($lat,4),round($lon,4)];

}


?>
