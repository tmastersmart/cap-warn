<?php
/*
 © 2023–2026 KJ5MZL / WRXB288
 la2way.com • lagmrs.com
 All rights reserved. This module and all functions within it
 are fully copyrighted and NOT open‑source.

 You are granted permission to use this software on your personal
 node or repeater. HUB operators must provide a link back to me
 in some form (website, dashboard, documentation, etc.).

 This software may NOT be modified, redistributed, repackaged,
 incorporated into any image, or included in any distribution
 without explicit written approval from KJ5MZL.

 Donations are appreciated.
 This software is provided as FreeViewWare.

 Software made in loUiSiAna — it's just better.
*/

// v1 of cyclone module (moved into a module seperate froom the core

// setup for seperate testing
$pathI = "/usr/share/cap-warn";
require_once("/etc/cap-warn/advanced_config.php");// load first allows config to overide
require_once("/etc/cap-warn/config.php");
include_once("$pathI/sound_db.php");
include_once("$pathI/cap_functions.php");

//$debug = true;
$Cevent[] ="";
$verFile = "$pathI/version.txt";
$relFile = "$pathI/release.txt";
if (file_exists($verFile)) { $ver = "v" . trim(file_get_contents($verFile));} 
else { $ver = "v5.1.0";}
if (file_exists($relFile)) {  $release = trim(file_get_contents($relFile));}
else { $release = "5/26/2026";}
$zone = trim(shell_exec('timedatectl show -p Timezone --value'));
if (!$zone) {    $zone = 'America/Chicago';}
date_default_timezone_set($zone);
$phpzone = date_default_timezone_get();
$cron=false;if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;} }

if(!$cron){
$mute=false;
if($sleep){
 if($hour>=1 and $hour <=6){
 $mute=true;$out="Sleep Mute $day $hour am";save_task_log ($out);print "$datum $out\n";
  }
 }
}
else{$mute=false;}

$datum   = date('m-d-Y H:i:s');
print"$datum Start Cyclone Module\n";

fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, 60, $cron);

if ($debug){$cyclone= "/usr/share/cap-warn/test_cyclone_alert.xml";}// for testing overide

print "$datum Loading $cyclone\n";
$xmlString = file_get_contents($cyclone);
if ($xmlString === false) {print "$datum ERROR: Failed to read cyclone file: $cyclone\n";}
$cyclones  = parseNhcCycloneXml($xmlString);
if (empty($cyclones)) { print "$datum None detected\n";}
else {
print "$datum " . count($cyclones) . " entries\n";
//    print_r($cyclones[0]);



$active    = filterActiveCyclones($cyclones);
if (empty($active)) {print "$datum None Active\n";}
 else {
    print "$datum " . count($active) . " entries Active\n";
  //   print_r($active[0]);
 }

// Hur only mode set by setup
if ($hurOnly === true) {
    $active = array_filter($active, 'isHurricane');
    if (empty($active)) { print "$datum No Hurricanes Active\n";}
   else {print "$datum " . count($active) . " Hurricanes Active\n";}
}

$datum   = date('m-d-Y H:i:s');
      
if ($active) {
$Cevent       = [];
$Cheadline    = [];
$Cdescription = [];
$Ctype        = [];
$Cname        = [];  
    foreach ($active as $cyclone) {
        // Skip stale advisories unless debug mode
        if ($debug === false) {
            if (!isCycloneCurrent($cyclone)) {
                print "$datum Skipping {$cyclone['name']} — advisory stale\n";
                continue;
            }
        }

        // Distance filter
        list($stormLat, $stormLon) = array_map('floatval', explode(',', $cyclone['center']));
        $distance = haversine($lat, $lon, $stormLat, $stormLon);

        if ($distance > $stormRadiusMiles) {
            print "$datum Skipping {$cyclone['name']} — too far away ({$distance} miles)\n";
            continue;
        }

        // Only announce if advisory changed
        if ($debug === false) {
         if (!isNewCycloneAdvisory($cyclone)) {
            print "$datum Skipping {$cyclone['name']} — already announced\n";
            continue;
        }
       }
        // Clean headline
        $cyclone['headline'] = cleanCycloneHeadline($cyclone['headline']);
        $headline  = $cyclone['headline'];
//        $sentences = preg_split('/(?<=[.?!])\s+/', $headline);
//        $short     = trim(implode(' ', array_slice($sentences, 0, 2)));
        $summary = buildStormSummary($cyclone);
        $Cevent[] =  $cyclone['type'] . " " . $cyclone['name'] . ". " . $headline. " " . $summary;// better formated TTS see function to adjust
//        $Cevent[] = "Test 123"; 
    

print "$datum Cyclone added: "
    . "Type: {$cyclone['type']} "
    . "Name: {$cyclone['name']} "
    . "Code: {$cyclone['atcf']} "
    . "Date: {$cyclone['datetime']} "
    . "Distance: $distance miles\n";


    } // end foreach active cyclones


    // Build TTS only if we have events
 if ($Cevent) {
    $ttsEvents = [];
    foreach ($Cevent as $i => $ev) {
       if ($ev !== "") {$ttsEvents[] = $ev;}
    }
    // Build final TTS string
    if (count($ttsEvents) == 1) {$ttsString = $ttsEvents[0];}
 else {
        $parts = [];
        foreach ($ttsEvents as $i => $txt) {$parts[] = "Event " . ($i + 1) . ": $txt";}
        $ttsString = implode(" ", $parts);
    }
    print "$datum $ttsString\n";




 


 if ($tts){
 print "$datum Building sound TTS Key\n";
// Create an instance of the VoiceRSS class
$voiceRSS = new VoiceRSS();
// Define the settings for the speech request
$settings = array(
    'key' => $tts,
    'src' => $ttsString, // Your text here
    'hl' => 'en-us', // Language (English - US)
    'v'  => 'Amy', // Voice (optional)
    'r'  => '0', // Rate (optional)
    'f'  => '8khz_16bit_mono',
    'c'  => 'wav', // Format 
);

// Call the speech function to get the response
$response = $voiceRSS->speech($settings);
// Check if there was an error in the response
 // FULL DEBUG
//print "$datum Raw TTS response:\n";var_dump($response);
if (!empty($response['error'])) {    print "$datum TTS ERROR: {$response['error']}\n";}
if (empty($response['response'])) {    print "$datum TTS ERROR: Empty audio response from VoiceRSS\n";}

 
 
$audioData = $response['response'];
$format = detectAudioFormat($audioData);
if ($format == "wav"){$tmpFile=$cycloneWAV;}
if ($format == "gsm"){$tmpFile=$cycloneGSM;}
if ($format == "mp3"){$tmpFile=$cycloneMP3;} 
print "$datum Received $format Audio length: " . strlen($audioData) . " bytes\n";  
//$tmpFile ="/tmp/test.mp3"; 
// Save raw audio
if (file_put_contents($tmpFile, $audioData) === false) {    print "$datum ERROR: Failed to write $tmpFile\n";} 
 else {    print "$datum Saved raw audio to $tmpFile\n";}

 }// end of if TSS
 else {
    // ---------------------------------------
    // Fallback path: use asl-tts (no API key)
    // ---------------------------------------
    print "$datum Building sound asl-tts \n";
 //sudo -u asterisk asl-tts -n 460181 -t "${AUD_TEXT}" -f /tmp/netstartsin5
    $cmd = "asl-tts -n $node -t " . escapeshellarg($ttsString) . " -f " . escapeshellarg("/tmp/cyclone" );
    exec($cmd, $output, $return);

    if ($return === 0) {
        echo "$datum $cycloneUL generated via asl-tts\n";
        //file_put_contents($specialTXT, $ttsString);
    }
 else { $out="ERROR: asl-tts failed to generate audio";save_task_log ($out);print "$datum $out\n";}
}
 
//now we have a sound file its either GSM or UL 
if(!$mute){
$out="";
if ($tts){$file=$tmpFile;}
else{$file = $cycloneUL;}

$action="";
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space between them
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$action="$action $file";
//print"$action\n";
$file=$outTmp;
playSound($out); 
} 

  }// end if Cevent
}// end of none active
}// end none
print"$datum End Cyclone Module\n";

// I mark each closing brace with a short label so it's obvious which
// block it closes. This makes the structure easier to follow and helps
// prevent mistakes when editing nested logic. (c)2026 KJ5MZL