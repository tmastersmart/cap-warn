<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.
//
//
//CAP‑Warn is a modern weather alert system designed as a full replacement for older Skywarn and Skywarn2 scripts.  
//It uses the current National Weather Service (NWS) alert format and provides a far more reliable, 
//automated experience for repeaters and AllStar nodes.
//
//Because CAP‑Warn is distributed through an APT repository, your system automatically receives updates
// — no manual patching, editing, or file replacement required.
//
//CAP‑Warn retrieves alerts directly from the National Weather Service CAP system and the 
//National Hurricane Center (nhc.noaa.gov).  
//These alerts are converted into high‑quality audio and played over your node, keeping operators informed even
//during rapidly changing weather conditions.
//
//Although the NWS API returns alerts in GeoJSON/JSON‑LD, the underlying data is still CAP 1.2, the official federal
// standard for public warning messages.
//The API simply transforms the raw CAP XML into a clean, consistent JSON structure. This avoids the formatting issues, 
//namespace problems, and broken XML that caused many older scripts to fail when legacy CAP endpoints were deprecated.
//
//CAP‑Warn uses the modern, supported, and recommended NWS API format, ensuring long‑term compatibility with the current
// alerting system.
//
//On Raspberry Pi systems, CAP‑Warn can also monitor CPU temperature and issue high‑temperature alarms.

// Replaces existing no warning scripts .

// Why PHP it works better sharing code with the webserver and works anywhere.

 // v3.4     10/05/2023   Major changes to weather API
 // v3.5     10/14/2023   FEMAQ added. later removed
 // v3.6     10/21/2023   Muting adjustments
 // v3.7     10/31/2023   Logging improvements
 // v3.8     11/02/2023   Fixed old files not clearing; removed legacy artifacts
 // v3.9     11/07/2023   Stopped duplicate burst

 // v4.0     11/20/2023   Debugging info on muting
 // v4.2     01/13/2024   Cleanup and anti‑clash changes
 // v4.3     01/17/2024   Bug fix in clear status
 // v4.4     01/21/2024   Watch statement flags; new sounds
 // v4.4.1   01/29/2024   Weather functions moved to separate file
 // v4.5     02/11/2024   WAV playback bug; converted all to GSM; debug mode added
 // v4.6     01/20/2025   Mods for the image
 // v4.7     02/15/2025   Clash flag fix
 // v4.8     03/28/2026   Full alert read for Special Weather Statement

 // v5.0     05/11/2026   Created standalone system with installers
 // v5.0.6   05/24/2026   Rebuilt functions from scratch for newer PHP
 // v5.1     05/31/2026   Moving hurricane into separate module for easier maintenance
 // v5.2.30  06/08/2026   Added GPS system. Moved sound into modules for code sharing
 // v5.2.42  06/15/2026   Option to skip expanded alerts. Product ID added for later use
 //                       Minor tweeks in sounds and a slight bug in $out not defined
 //                       Pushover support. Sound updates.
//  v5.5.50  06/20/2026   Correct sound files change for multi alerts.. 
//                        Trying to fix file patchs for desktop version to share code base.

$pathUSR = "/usr/share/cap-warn";$pathI = $pathUSR;// till its all changed over
$pathETC = "/etc/cap-warn";

$verFile = "$pathUSR/version.txt";
$relFile = "$pathUSR/release.txt";
if (file_exists($verFile)) { $ver = "v" . trim(file_get_contents($verFile));} 
else { $ver = "v5.2.50";}
if (file_exists($relFile)) {  $release = trim(file_get_contents($relFile));}
else { $release = "06/20/2026";}
$zone = trim(shell_exec('timedatectl show -p Timezone --value'));
if (!$zone) {    $zone = 'America/Chicago';}
date_default_timezone_set($zone);
$phpzone = date_default_timezone_get();
require_once("$pathETC/advanced_config.php");// load first allows config to overide
require_once("$pathETC/config.php");
include_once("$pathUSR/sound_db.php");
include_once("$pathUSR/cap_functions.php");
include_once("$pathUSR/cap_gps.php");
if($user_key and $api_token){include_once("$pathUSR/cap_pushover.php");}
$lat = trim($lat);$lat = preg_replace('/[^0-9\.\-]/', '', $lat);
$lon = trim($lon);$lon = preg_replace('/[^0-9\.\-]/', '', $lon);

//$user_key   
//$api_token     
//$pushNotify  

//$debug=true;

// Safety if no tailfile repair
if (!file_exists($tailfile)){  
 if (file_exists($alertTxt)){unlink($alertTxt);} 
 if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
}
//using the command cron resets the hold off timmer
$cron=false;if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;} }
$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
else {$piVersion =	exec('uname -m  -s -o -v');}
$phpVersion= phpversion();$CAPstatus="Clear";
$time= date('H:i');
$date =  date('m-d-Y');
$year =  date('Y');
$datum   = date('m-d-Y H:i:s');
$gmdatum = gmdate('m-d-Y H:i:s');
$action=""; $event="";$serial=serial();$out="";
print "
=====================================================================
Cap Warm $ver - (Storm tracking alert system with GPS)
(c)2023/$year KJ5MZL WRXB288 LA2WAY.com LAGMRS.com all rights reserved
TZ: $phpzone PHP: $phpVersion  Release date: $release
Instance ID [$serial]
=====================================================================
$datum Node:$node UTC:$gmdatum 
$datum Model: $piVersion
";
if (!$local){print"$datum IN GLOBAL MODE\n";}
if ($tts){print"$datum Using voicerss.org API\n";}
if ($user_key && $api_token){print"$datum Using pushover.net \n";}






// support for the gps
$gps = detect_gps_position();
if ($gps) {list($lat, $lon) = $gps;print "$datum Using GPS Lat:$lat Lon:$lon [lock]\n";}
else {print "$datum Using Lat:$lat Lon:$lon\n";}





if (file_exists($flag)) {
    $ageSeconds  = time() - filemtime($flag);
    $ageMinutes  = floor($ageSeconds / 60);
    echo "$datum Hold flag age: {$ageMinutes} minutes (limit: {$theHoldtime} minutes)\n";
    if ($ageSeconds > ($theHoldtime * 60)) {        echo "$datum Hold expired — resetting play timer.\n";        unlink($flag);    }
    elseif ($cron) {        echo "$datum Cron override — resetting play timer.\n";        unlink($flag);    }
    else {        echo "$datum Skipping playback — still within hold window.\n";    }
}
//else {    echo "$datum No hold flag — playback allowed.\n";}


// Manual external muting flag  We want to exit not mute. 
//$linked_file = "/tmp/linked_true.txt";// move to conf
if (file_exists($linked_file)) {
    $out="Mute link file exists";save_task_log ($out);print"$datum $out\n";
    $age_seconds = time() - filemtime($linked_file);
    $age_hours = round($age_seconds / 3600);
    if ($age_hours > 10) { unlink($linked_file);}// 10 hrs is to long must be stuck
}
if (file_exists($linked_file)) {$out="ABORTING we are linked";save_task_log ($out);print"$datum [$linked_file] exists. $out. Kill the file first\n";die;}




// the clash file stops other processed from playing at the same time
if(file_exists($clash)){
 $out="Waiting for other threads. "; print"$datum $out\n"; if($debug){save_task_log ($out);}
 sleep(90);
 // safety clear abandon ed flags
 if(file_exists($clash)){   // fix for file being erased in loop
 $ft = time()-filemtime($clash);
 $ft = round(($ft)/60); 
 if ($ft > 10){unlink($clash);} 
 } // 10 mins
}
$fileOUT = fopen($clash,'w');fwrite ($fileOUT,$datum);fclose ($fileOUT);



//if (file_exists($tailfile)){print "$datum found: $tailfile\n";}   
//if (file_exists($alertTxt)){print "$datum found: $alertTxt\n";} 
//if (file_exists($alertTxtHeadline)){print "$datum found: $alertTxtHeadline\n";}
// test for mute move to start
$hour=date('H');$day=date('D');
if(!$cron){
$mute=false;
if($sleep){
 if($hour>=1 and $hour <=6){
 $mute=true;$out="Sleep Mute $day $hour am";save_task_log ($out);print "$datum $out\n";
  }
 }
}
else{$mute=false;}

$fetch=true;



// fetch updates....
if (file_exists($alertxml)) {
    $age_seconds = time() - filemtime($alertxml);
    $age_minutes = round($age_seconds / 60, 1); // one decimal place
    // Cache is fresh if age < 5 minutes
    if ($age_seconds < 300) {$fetch = false;}
    echo "$datum Alert cache age: {$age_minutes} minutes\n";
}

if($fetch){
fetchCapAlerts($lat, $lon, $alertxml_point, $ver);
//Get zones from points API 
$zones = getZonesFromPointsApi($lat, $lon, $ver);

    if ($zones) {
        $zone1 = $zones["forecast"];$zone2 = $zones["county"];
        echo "$datum Alert zones $zone1 $zone2\n";
        fetchZoneAlerts($zone1, $zone2, $alertxml_zone, $ver);
        // 4) Merge point + zone into main file
        merge_alerts($alertxml_point, $alertxml_zone, $alertxml);
    }
else{copy($alertxml_point, $alertxml);}
}

                                                  
else{print"$datum Using Cached file Alerts\n";}
                                                           
if ($debug) {
$alertxml=$testalertxml;
$out="Test Alert DEBUG mode [FAKE] $alertxml ";save_task_log ($out);print "$datum $out\n";
// change the filename to point to the test file

}                                                                 
read_api_json_alerts($alertxml);                                                             
                                                             
                                                             



$datum   = date('m-d-Y H:i:s');
$events       = "";
$headlines    = "";
$descriptions = "";
$instructions = "";

$count = count($event);
for ($i = 0; $i < $count; $i++) {

    if ($i == 0) {
        // first item: no leading separators
        $events       .= $event[$i];
        $headlines    .= $headline[$i];
        $descriptions .= $description[$i];
        $instructions .= $instruction[$i];
    } else {
        // subsequent items: prepend separators
        $events       .= "," . $event[$i];
        $headlines    .= "|" . $headline[$i];
        $descriptions .= "|" . $description[$i];
        $instructions .= "|" . $instruction[$i];
    }
}
$descriptions = str_replace(["\n", "\r", "*", "#", "~"], " ", $descriptions);
$descriptions = trim($descriptions);


if($events){print"$datum Events: $events\n";}
else{all_clear("ok");$events="";}
// set the status
if ($events){
  $CAPstatus="new";
  if (file_exists($alertTxt) ){
  $test = file_get_contents($alertTxt);
  if ($test <> $events){print "$datum Events have changed\n";$CAPstatus="new";save_task_log ("new Alert $events");}
 else {$CAPstatus="no change";print "$datum Existing Event file [$CAPstatus]\n";}
 }
}
// there is already a audio file since its not changed.
if ($CAPstatus == "no change" && !file_exists($flag)) {
    $min = date('i');$out="";
    if ($debug) { $min = 30; } // force test window
       echo "$datum Minute check: current minute = $min (window: 10–50)\n";
       if ($min >= 10 && $min <= 50) {
       $file=$tailfile;playSoundOnly($out);
       $CAPstatus="Playing Tail File";
       $fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
}
 else { echo "$datum Skipping — outside 10–50 minute window (current: $min)\n"; $CAPstatus="mute";}
}
//else {$CAPstatus="mute";}

// its diffrent we need to build the file.
$datum   = date('m-d-Y H:i:s');
if ($CAPstatus=="new"){

print "$datum Creating new event files.\n";
$fileOUT = fopen($alertTxt,'w');fwrite ($fileOUT,$events);fclose ($fileOUT);
$fileOUT = fopen($alertTxtHeadline,'w');fwrite ($fileOUT,$headlines);fclose ($fileOUT);
$fileOUT = fopen($alertTxtDescription,'w');fwrite ($fileOUT,$descriptions);fclose ($fileOUT);
// lets save some log data on the events, 
archive_json($alertxml);
archive_json($alertxml_point);
archive_json($alertxml_zone);
archive_json($debugFile);


save_task_log ($events); // save it to the log

$file = $tailfile;if(file_exists($file)){unlink($file);} // kill the last tail file to prevent it launching during play

// has-issued-a,has-expired,weather-station,weather,
check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
check_gsm_db  ("weather service");             if($file1){$action = "$action $file1";}

$watchSTATUS="alert";

$all = strtolower($events);
 if (strpos($all, "statement") !== false){ $watchSTATUS="Special Weather Statement";   }
 if (strpos($all, "advisory") !== false) { $watchSTATUS="advisory";       }
 if (strpos($all, "watch") !== false)    { $watchSTATUS="watch";        } 
 if (strpos($all, "warning") !== false)  { $watchSTATUS="warning";    }


print "$datum Alert(s) Detected $watchSTATUS\n";
if ($watchSTATUS){check_gsm_db ($watchSTATUS);if($file1){$action = "$action $file1";}} 


// Better plays all descriptions 
// Break out the description to create a TTS file
// Special formating and cleaning for the text conversion
$firstSWS = "";
$allDescriptions = [];

foreach ($event as $i => $ev) {
    if (stripos($ev, "special weather statement") !== false || $expanAlert == true) {
        $ds = $description[$i];
        // Clean the description
 // Remove NOAA leading/trailing ellipses
$ds = preg_replace('/^\.\.\.\s*/', '', $ds);   // leading ...
$ds = preg_replace('/\s*\.\.\.$/', '', $ds);   // trailing ...
$ds = str_replace("...", " ", $ds);            // inline ...
    
$ds = str_replace(["*", "•", "- ", ","], " ", $ds);   // Remove commas too
    // Remove common NWS product codes (FFWSHV, TORLIX, SVRLCH, etc.)
$ds = preg_replace('/\b[A-Z]{3,4}[A-Z]{3}\b/', '', $ds);     // Catches most PIL codes like FFWSHV, TORLIX
// Remove other common junk
$ds = preg_replace('/\b(WGUS\d+|K[A-Z]{3}|NWS|National Weather Service in)\b/i', '', $ds);
// Remove common NWS section headers (makes TTS sound much better)
        $ds = preg_replace('/\b(WHAT|WHERE|WHEN|IMPACTS|ADDITIONAL DETAILS|HAZARD|SOURCE|DISCUSSION)\b[:]?/i', '', $ds);
        $ds = preg_replace('/\s+/', ' ', $ds);   // Collapse multiple spaces
        $ds = trim($ds);
        // Take first 2 sentences
        $sentences = preg_split('/(?<=[.?!])\s+/', $ds);
        $cleanDesc = trim(implode(' ', array_slice($sentences, 0, 2)));
        if (!empty($cleanDesc)) { $allDescriptions[] = $cleanDesc;}
        print "$datum TTS on Desc #$i $cleanDesc\n";
    }
}

// Now combine all descriptions
if (!empty($allDescriptions)) {
    $combined = "";
    foreach ($allDescriptions as $idx => $desc) {
        $eventNum = $idx + 1;
        $combined .= "[Event $eventNum:] $desc. ";
    if($user_key && $api_token && $pushNotify == "all"){send_pushover_notification($desc);}
    }
    $firstSWS = trim($combined);
} 
else {    $firstSWS = "";}

// Check against previous text
$previous_text = "";
if (file_exists($specialTXT)) {    $previous_text = file_get_contents($specialTXT);}

$skip_build = false;
if (trim($previous_text) === trim($firstSWS)) {
    echo "$datum Description unchanged \n";
    $skip_build = true;
} 
else {    echo "$datum New combined description built with " . count($allDescriptions) . " event(s)\n";}


// After building $firstSWS
$max_chars = 8000;   // Safe limit for VoiceRSS
if (strlen($firstSWS) > $max_chars) {
    echo "$datum TTS to long (" . strlen($firstSWS) . " chars). Truncating...\n";
    $firstSWS = substr($firstSWS, 0, $max_chars - 50) . "... End of alert.";
}






if (!$skip_build){

build_tts_audio($firstSWS, $special, $specialTXT, $specialUL, $node, $tts, "SPECIAL: ");
// New pushover send the text we got.....Only if on all
//if($user_key && $api_token && $pushNotify == "all"){send_pushover_notification($firstSWS);}

$pushItOut="";


// build that file
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space between them
check_wav_db  ("strong click");if($file1){$action = "$action $file1";}
$u= explode(",",$events); 

foreach($u as $line){
$line = strtolower($line);
if($line){ check_gsm_db($line);if($file1){$action = "$action $file1";} } 

//// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
// Sets a burnband message 
// This has been a local problem diffrent alerts being used 
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){ // most dont know what this is clearer alert
check_gsm_db ("Burn Ban"); if($file1){ $action = "$action $file1";} // lets throw in a burn ban message
 }
$pushItOut="$pushItOut $line";

}// end for loop
if($user_key && $api_token && $pushNotify == "all"){send_pushover_notification($pushItOut);}

if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space at the end
$datum   = date('m-d-Y H:i:s'); 


//We are goint to play this new alert even if muted
//so mute only slows us down not stops us
//if(!$mute){
$min = date('i');
if (!$debug && $mute) {
    print "$datum Testing safe to talk ";
    // Wait while in the danger window (:50 → :10)
    while ($min >= 50 || $min < 10) {
        echo ".";               // progress indicator
        sleep(30);              // wait 30 seconds
        $min = date('i');       // refresh minute
    }
    print "OK\n";
}


$file=$outTmp;playSound($out); 
$fileOUT = fopen($flag, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);


// This pre builds the sound file so it will work faster
// 
$action="";
check_gsm_db  ("silence1"); if($file1){$action = "$action $file1";}
$u= explode(",",$events);

foreach($u as $line){
check_wav_db  ("star dull"); if($file1){$action = "$action $file1";}

if($line){ check_wav_db($line); if($file1){$action = "$action $file1";} }
check_gsm_db  ("silence1"); if($file1){$action = "$action $file1";}// need this after the beep
// check for major warrnings.
// persons in path of 
if($line=="Tornado Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("tornado");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Severe Thunderstorm Warning"){
check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
check_gsm_db ("thunderstorm");if($file1){$action = "$action $file1";}
check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

if($line=="Hurricane Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("hurricane");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}
if($line=="Blizzard Warning"){
 check_gsm_db ("persons in path of");if($file1){$action = "$action $file1";}
 check_gsm_db ("blizzard");if($file1){$action = "$action $file1";}
 check_gsm_db ("advised to seek shelter");if($file1){$action = "$action $file1";}
}

// Sets a burnband message 
// This has been a local problem diffrent alerts being used 
if($line=="Red Flag Warning" or $line=="Fire Weather Watch"){ // most dont know what this is clearer alert
check_gsm_db ("Burn Ban"); if($file1){ $action = "$action $file1";} // lets throw in a burn ban message
 }

}// end for loop
// changing this setting wont affect a built sound file only the next alert
if($specialExpand){
 if (file_exists($special )){$action = "$action $special";} // if theres a special file add that. 
 if (file_exists($specialUL)){$action = "$action $specialUL";} // if theres a special file add that. 
}
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space at the end

// $tailfile  ="/tmp/skywarn-tail.wav";  
exec ("sox $action $tailfile",$output,$return_var);
$out="Tailfile updated $tailfile";save_task_log ($out);print "$datum $out\n";
 
}// end skip build
}// end if new


$min = intval(date('i'));
if ($detectCyclone == true) {
    // Only run cyclone logic between :10 and :50
    if ($min >= 10 && $min <= 50) { print "$datum Cyclone window OK (minute=$min)\n"; include_once("$pathI/cap_cyclones.php"); }
   else { print "$datum Cyclone check skipped — outside 10–50 minute window (minute=$min)\n"; }
 } 
 else {print "$datum Cyclone disabled\n";}


// dont even install if we are not using. Saves memory
if($piSystem && $piAlarms){include_once("$pathI/cap_temp.php");}








$datum = date('m-d') . "-1965 " . date('H:i:s');
print "$datum End of Line. Next Punch Card Please.  \n";
print"=====================================================================\n";
if(file_exists($clash)){unlink($clash);}

// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.





?>