<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
// 
// GPS module 
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.
$GPS_DEBUG=false;

function detect_gps_position() {
    global $datum, $GPS_DEBUG;

// -----------------------------
// 1. gpsd (best option)
// -----------------------------
if (shell_exec("pgrep gpsd")) {

    if ($GPS_DEBUG) print "$datum GPSD detected, reading TPV…\n";

    $json = shell_exec("gpspipe -w -n 5 2>/dev/null | grep TPV | head -n 1");

    if ($GPS_DEBUG) print "$datum GPSD RAW: $json\n";

    $data = json_decode($json, true);

    // If gpsd returned something but no fix
    if (!empty($data) && (empty($data['lat']) || empty($data['lon']))) {
        print "$datum GPSD detected but no fix yet (mode={$data['mode']})\n";
        // mode meanings:
        // 1 = no fix
        // 2 = 2D fix
        // 3 = 3D fix
    }

    // If gpsd has a valid fix
    if (!empty($data['lat']) && !empty($data['lon'])) {
        print "$datum GPS: Using GPSD non NEMA\n";
        return [$data['lat'], $data['lon']];
    }
}


    // -----------------------------
    // 2. /dev/serial/by-id (stable path)
    // -----------------------------
    foreach (glob("/dev/serial/by-id/*") as $dev) {
     $pos = read_nmea_from_device($dev);
     if ($pos === "NOFIX") { $gps_found_no_fix = true; continue;}
     if (is_array($pos)) {print "$datum GPS: Using $dev\n";return $pos;}  
    }

    // -----------------------------
    // 3. ttyACM* (CDC GPS)
    // -----------------------------
    foreach (glob("/dev/ttyACM*") as $dev) {
    $pos = read_nmea_from_device($dev);
    if ($pos === "NOFIX") { $gps_found_no_fix = true; continue;}
   if (is_array($pos)) { print "$datum GPS: Using $dev\n";return $pos;}
    }

    // -----------------------------
    // 4. ttyUSB* (serial GPS)
    // -----------------------------
    foreach (glob("/dev/ttyUSB*") as $dev) {
    $pos = read_nmea_from_device($dev);
    if ($pos === "NOFIX") {$gps_found_no_fix = true; continue;}
    if (is_array($pos)) {print "$datum GPS: Using $dev\n";return $pos;}
    }
    return false;
}


function read_nmea_from_device($dev) {
    global $GPS_DEBUG, $datum;
    $line = shell_exec("timeout 1 cat $dev 2>/dev/null | grep GGA | head -n 1");
    if ($GPS_DEBUG) {if ($line) print "$datum NMEA from $dev: $line\n";
        else print "$datum No GGA from $dev\n";
    }

    if (!$line) return false;

    // -----------------------------
    // NEW: detect "no fix" GGA
    // -----------------------------
    $p = explode(",", $line);

    // GGA fields:
    // p[6] = fix quality (0 = no fix)
    // p[7] = satellites in use
    $fix = isset($p[6]) ? $p[6] : "0";
    $sats = isset($p[7]) ? $p[7] : "0";

    if ($fix == "0" || $sats == "00") {
        print "$datum GPS detected at $dev no fix yet (sats=$sats)\n";
        return "NOFIX";   // special return value
    }
// Translate fix type
$fixType = [
    "0" => "No Fix",
    "1" => "GPS Fix",
    "2" => "DGPS Fix",
    "4" => "RTK Fixed",
    "5" => "RTK Float",
    "6" => "Dead Reckoning",
    "7" => "Manual Input",
    "8" => "Simulation"
];
$hdop = isset($p[8]) ? $p[8] : "N/A";

$hdopRating =
    ($hdop <= 1.0) ? "Excellent" :
    (($hdop <= 2.0) ? "Good" :
    (($hdop <= 5.0) ? "Fair" :
    (($hdop <= 10.0) ? "Poor" : "Very Poor")));


$type = isset($fixType[$fix]) ? $fixType[$fix] : "Unknown";
$accuracy_m = round($hdop * 5, 1); // rough rule of thumb

// Status line
print "$datum GPS (satellites=$sats, fix=$type, hdop=$hdop $hdopRating, Accuracy {$accuracy_m}m)\n";





    // -----------------------------
    // If we reach here, try to parse
    // -----------------------------
    return parse_nmea_gga($line);
}



function parse_nmea_gga($line) {
    $p = explode(",", $line);
    if (count($p) < 6) return false;

    $latRaw = $p[2];
    $latHem = $p[3];
    $lonRaw = $p[4];
    $lonHem = $p[5];

    if (!$latRaw || !$lonRaw) return false;

    // Convert DDMM.MMMM → decimal degrees
    $lat = floor($latRaw / 100) + fmod($latRaw, 100) / 60;
    if ($latHem === "S") $lat = -$lat;

    $lon = floor($lonRaw / 100) + fmod($lonRaw, 100) / 60;
    if ($lonHem === "W") $lon = -$lon;

    return [round($lat, 4), round($lon, 4)];
}


//$gps = detect_gps_position();

// usage
//
//if ($gps) {list($LAT, $LON) = $gps;print "$datum Using GPS override: $LAT, $LON\n";}
//else {print "$datum Using configured GPS: $LAT, $LON\n";}





?>