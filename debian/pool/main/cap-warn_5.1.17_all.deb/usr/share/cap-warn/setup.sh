#!/bin/bash
# ------------------------------------------------------------
# CAP-Warn Setup Utility
# ------------------------------------------------------------
# This setup program configures CAP-Warn for your node.
# In the spirit of 1960s computer rooms:
#   "Please do not fold, spindle, or mutilate this installer."
#
# And as Buckaroo Banzai wisely said:
#   "Wherever you go... there you are."
# ------------------------------------------------------------

cd /usr/share/cap-warn

# ------------------------------------------------------------
# Commodore 64 Style Boot Screen
# ------------------------------------------------------------
echo " "
echo " **** COMMODORE 64 BASIC V2 ****"
echo " "
echo " 64K RAM SYSTEM  38911 BASIC BYTES FREE"
echo " "
echo "READY."
sleep 1
echo "LOAD \"CAP-WARN SETUP\",8,1"
sleep 1
echo "SEARCHING FOR CAP-WARN SETUP"
sleep 1
echo "LOADING"
sleep 2
echo "READY."
sleep 1
echo "RUN"
sleep 1
echo " "
echo "Hang loose… CAP‑Warn is loading its cosmic subroutines."
sleep 2
echo "Outta sight… CAP‑Warn is warming up.."
sleep 2
echo " "

# ------------------------------------------------------------
# Logging
# ------------------------------------------------------------
LOGDIR="/var/log/cap-warn"
LOGFILE="$LOGDIR/install.log"
mkdir -p "$LOGDIR"
touch "$LOGFILE"
chmod 644 "$LOGFILE"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $1" | tee -a "$LOGFILE"
}

log "===== CAP-WARN INSTALLER STARTED ====="

# ------------------------------------------------------------
# Paths
# ------------------------------------------------------------
CONFIG="/etc/cap-warn/config.php"
mkdir -p /etc/cap-warn
chmod 755 /etc/cap-warn
log "Ensured /etc/cap-warn exists."

# ------------------------------------------------------------
# Auto-increment installer version (persists forever)
# ------------------------------------------------------------
SETUPVERFILE="/usr/share/cap-warn/setup_version.txt"

if [ ! -f "$SETUPVERFILE" ]; then
    echo "1" > "$SETUPVERFILE"
fi

SETUPVER=$(cat "$SETUPVERFILE")
NEWSETUPVER=$((SETUPVER + 1))
echo "$NEWSETUPVER" > "$SETUPVERFILE"
INSTALLER_VERSION="v$NEWSETUPVER"
log "Installer version: $INSTALLER_VERSION"

# ------------------------------------------------------------
# Load existing config values (if present)
# ------------------------------------------------------------
OLD_NODE=""
OLD_TTS=""
OLD_LAT=""
OLD_LON=""
OLD_STORMRADIUS=""
OLD_DETECTCYCLONE=""
OLD_CYURL=""
OLD_EXPANALERT=""
OLD_SLEEP=""
OLD_HOLDTIME=""
OLD_CRONINT=""
OLD_PIALARMS=""
OLD_SOFT=""
OLD_HOT=""

if [ -f "$CONFIG" ]; then
    log "Loading existing configuration from $CONFIG"
    OLD_NODE=$(php -r "include '$CONFIG'; echo \$node ?? '';")
    OLD_TTS=$(php -r "include '$CONFIG'; echo \$tts ?? '';")
    OLD_LAT=$(php -r "include '$CONFIG'; echo \$lat ?? '';")
    OLD_LON=$(php -r "include '$CONFIG'; echo \$lon ?? '';")
    OLD_STORMRADIUS=$(php -r "include '$CONFIG'; echo \$stormRadiusMiles ?? '';")
    OLD_DETECTCYCLONE=$(php -r "include '$CONFIG'; echo \$detectCyclone ?? '';")
    OLD_CYURL=$(php -r "include '$CONFIG'; echo \$cycloneURL ?? '';")
    OLD_EXPANALERT=$(php -r "include '$CONFIG'; echo \$expanAlert ?? '';")
    OLD_SLEEP=$(php -r "include '$CONFIG'; echo \$sleep ?? '';")
    OLD_HOLDTIME=$(php -r "include '$CONFIG'; echo \$theHoldtime ?? '';")
    OLD_CRONINT=$(php -r "include '$CONFIG'; echo \$cronInt ?? '';")
    OLD_PIALARMS=$(php -r "include '$CONFIG'; echo \$piAlarms ?? '';")
    OLD_SOFT=$(php -r "include '$CONFIG'; echo \$soft ?? '';")
    OLD_HOT=$(php -r "include '$CONFIG'; echo \$hot ?? '';")
fi

# Smart defaults when missing
[ -z "$OLD_STORMRADIUS" ] && OLD_STORMRADIUS="600"
[ -z "$OLD_HOLDTIME" ] && OLD_HOLDTIME="25"
[ -z "$OLD_CRONINT" ] && OLD_CRONINT="13"
[ -z "$OLD_SOFT" ] && OLD_SOFT="65"
[ -z "$OLD_HOT" ] && OLD_HOT="75"

# ------------------------------------------------------------
# Splash
# ------------------------------------------------------------
whiptail --title "CAP Warn Installer — Setup:$INSTALLER_VERSION" --msgbox "\
CAP-Warn Setup Program
(c) 2023–2026 KJ5MZL — la2way.com
All rights reserved.

CAP-Warn is an automated alerting system that retrieves
National Weather Service CAP (Common Alerting Protocol)
messages, processes them, and plays alerts over your
AllStar node or repeater.

This installer will configure:
 1 Your node number
 2 GPS coordinates
 3 Hurricane tracking region
 4 Alert behavior and timing
 5 Text-to-speech options

Press OK to begin installation." 30 78
log "Displayed splash screen."

# ------------------------------------------------------------
# Backup existing config
# ------------------------------------------------------------
if [ -f "$CONFIG" ]; then
    BACKUP="/etc/cap-warn/config.php.bak_$(date +%Y%m%d_%H%M%S)"
    cp "$CONFIG" "$BACKUP"
    log "Backed up existing config.php to $BACKUP"
    whiptail --title "Backup Created" --msgbox "Existing config.php backed up to:\n$BACKUP" 10 60
else
    BACKUP="(none - fresh install)"
fi

# ------------------------------------------------------------
# TTS Engine Information
# ------------------------------------------------------------
whiptail --title "Text‑to‑Speech Options" \
--msgbox "CAP‑Warn supports two text‑to‑speech engines:\n
1. VoiceRSS (Recommended)
   - Most natural, human‑sounding voice
   - Requires internet and a FREE API key
   - Used when cloud TTS is available\n
2. Piper / asl‑tts (Offline Mode)
   - No API key required
   - Works without internet
   - Slightly more robotic\n
NOTE: CAP‑Warn still requires internet to download NWS alerts. 
Offline TTS only affects how alerts are spoken, not how they are received.\n
If you enter a VoiceRSS key, CAP‑Warn will use the high‑quality cloud voice.
If you skip the key, CAP‑Warn will automatically use the offline Piper voice." \
12 70
log "Displayed TTS engine information."

# ------------------------------------------------------------
# TTS API Key (Optional)
# ------------------------------------------------------------
TTSKEY=$(whiptail --inputbox "Enter your VoiceRSS API key (leave blank to use offline Piper TTS):" \
10 70 "$OLD_TTS" --title "VoiceRSS API Key (Optional)" 3>&1 1>&2 2>&3)
log "TTS API key entered (blank means offline mode)."

# ------------------------------------------------------------
# Node Number
# ------------------------------------------------------------
NODE=$(whiptail --inputbox "Enter your AllStar node number:" 10 60 "$OLD_NODE" --title "Node Number" 3>&1 1>&2 2>&3)
log "Node number entered: $NODE"
# Clear buffered newline so next dialog doesn't auto-accept
read -t 0.1 -n 10000 discard 2>/dev/null
# ------------------------------------------------------------
# GPS Coordinates
# ------------------------------------------------------------
LAT=$(whiptail --inputbox "Enter repeater latitude:" 10 60 "$OLD_LAT" --title "GPS Latitude" 3>&1 1>&2 2>&3)
log "Latitude entered: $LAT"

# Clear buffered newline so next dialog doesn't auto-accept
read -t 0.1 -n 10000 discard 2>/dev/null

LON=$(whiptail --inputbox "Enter repeater longitude:" 10 60 "$OLD_LON" --title "GPS Longitude" 3>&1 1>&2 2>&3)
log "Longitude entered: $LON"

# ------------------------------------------------------------
# Hurricane Basin
# ------------------------------------------------------------
DEFAULT_CHOICE="0"
case "$OLD_CYURL" in
    "/gis-at.xml") DEFAULT_CHOICE="1" ;;
    "/gis-ep.xml") DEFAULT_CHOICE="2" ;;
    "/gis-cp.xml") DEFAULT_CHOICE="3" ;;
    *) DEFAULT_CHOICE="0" ;;
esac

CHOICE=$(whiptail --default-item "$DEFAULT_CHOICE" --title "Select Hurricane Feed (NHC GIS)" --menu "\
Choose the region closest:

1. Gulf & East Coast LA,TX,MS,AL,FL,GA,SC,NC,VA,MD,NJ,NY,MA,ME
2. Eastern Pacific West Coast CA,AZ Baja & Mexico West Coast
3. Central Pacific Hawaii
0. Disable hurricane detection
" 22 75 10 \
"1" "Atlantic (Louisiana → New York)" \
"2" "Eastern Pacific (California / Baja)" \
"3" "Central Pacific (Hawaii)" \
"0" "Disable hurricane detection" \
3>&1 1>&2 2>&3)

case $CHOICE in
    1) CYURL="/gis-at.xml"; DETECTCYCLONE=true ;;
    2) CYURL="/gis-ep.xml"; DETECTCYCLONE=true ;;
    3) CYURL="/gis-cp.xml"; DETECTCYCLONE=true ;;
    0) CYURL="disabled"; DETECTCYCLONE=false ;;
esac

log "Cyclone detection: $DETECTCYCLONE, URL: $CYURL"

# ------------------------------------------------------------
# Storm Radius
# ------------------------------------------------------------
if [ "$DETECTCYCLONE" = true ]; then
    STORMRADIUS=$(whiptail --inputbox "Enter storm radius in miles (0 to disable):" 10 60 "$OLD_STORMRADIUS" --title "Storm Radius" 3>&1 1>&2 2>&3)
else
    STORMRADIUS=0
fi
log "Storm radius: $STORMRADIUS"

# ------------------------------------------------------------
# Expand Alerts
# ------------------------------------------------------------
if [[ "$OLD_EXPANALERT" == "true" ]]; then
    whiptail --yesno "Expand alerts with description?" 10 60
else
    whiptail --defaultno --yesno "Expand alerts with description?" 10 60
fi
EXPANALERT=$([ $? -eq 0 ] && echo true || echo false)
log "Expand alerts: $EXPANALERT"

# ------------------------------------------------------------
# Quiet Hours
# ------------------------------------------------------------
if [[ "$OLD_SLEEP" == "true" ]]; then
    whiptail --yesno "Enable quiet hours (1am–6am)?" 10 60
else
    whiptail --defaultno --yesno "Enable quiet hours (1am–6am)?" 10 60
fi
SLEEP=$([ $? -eq 0 ] && echo true || echo false)
log "Quiet hours: $SLEEP"

# ------------------------------------------------------------
# Hold Timer
# ------------------------------------------------------------
HOLDTIME=$(whiptail --inputbox "Minutes to wait before repeating the same alert:" 10 60 "$OLD_HOLDTIME" --title "Hold Timer" 3>&1 1>&2 2>&3)
log "Hold time: $HOLDTIME"

# ------------------------------------------------------------
# Cron Interval
# ------------------------------------------------------------
CRONINT=$(whiptail --inputbox "How often should alerts run? (minutes)" 10 60 "$OLD_CRONINT" --title "Cron Interval" 3>&1 1>&2 2>&3)
log "Cron interval: $CRONINT"

# ------------------------------------------------------------
# Detect Raspberry Pi hardware
# ------------------------------------------------------------
piSystem=false
if [[ -r /proc/device-tree/model ]]; then
    piSystem=true
    piVersion=$(tr -d '\0' < /proc/device-tree/model)
else
    piVersion="$(uname -m -s -o -v)"
fi
log "Detected system: $piVersion"

# Defaults
piAlarms="${OLD_PIALARMS:-false}"
piSoftTemp="$OLD_SOFT"
piHotTemp="$OLD_HOT"

# ------------------------------------------------------------
# Raspberry Pi alarm options
# ------------------------------------------------------------
if [[ "$piSystem" == true ]]; then
    if [[ "$piAlarms" == "true" ]]; then
        ALARM_CHOICE=0
        whiptail --yesno "Detected: $piVersion

Raspberry Pi alarms are currently ENABLED.

Would you like to keep them enabled?" \
        18 70
        [ $? -ne 0 ] && piAlarms="false"
    else
        whiptail --yesno "Detected: $piVersion

Would you like to enable the following alarms?

 • High CPU Temperature
 • Throttling Detection
 • Low Voltage Alerts

Recommended for Raspberry Pi nodes." \
        18 70
        [ $? -eq 0 ] && piAlarms="true"
    fi

    if [[ "$piAlarms" == "true" ]]; then
        whiptail --title "Raspberry Pi Temperature Guidance" --msgbox "\
Detected: $piVersion

Raspberry Pi boards have built-in thermal protection:
 • Soft throttling begins around 80°C
 • Hard throttling begins around 85°C
 • Emergency shutdown occurs near 90°C

Recommended alarm levels:
 • Soft Warning: 65°C
 • Critical Alarm: 75°C

You may manually adjust later in config files.

You will now be asked to enter your preferred thresholds." \
        22 75

        piSoftTemp=$(whiptail --inputbox "Detected: $piVersion

Enter SOFT warning temperature (°C):" \
            12 60 "$piSoftTemp" --title "Soft Temp Warning" 3>&1 1>&2 2>&3)

        piHotTemp=$(whiptail --inputbox "Detected: $piVersion

Enter CRITICAL temperature (°C):" \
            12 60 "$piHotTemp" --title "Critical Temp Alarm" 3>&1 1>&2 2>&3)
    fi
fi

log "Pi alarms: $piAlarms, soft: $piSoftTemp, hot: $piHotTemp"

# ------------------------------------------------------------
# Write config.php
# ------------------------------------------------------------
log "Writing config.php..."

cat > "$CONFIG" <<EOF
<?php
// ------------------------------------------------------------
// CAP-Warn Configuration File
// ------------------------------------------------------------
// This file is generated automatically by setup.sh.
// Running setup.sh again will update these values using
// your previous configuration as defaults.
//
// System detected: $piVersion
// Installer version: $INSTALLER_VERSION
// ------------------------------------------------------------
\$installerVer      = "$INSTALLER_VERSION";
\$node              = "$NODE";
\$tts               = "$TTSKEY";
\$lat               = "$LAT";
\$lon               = "$LON";
\$stormRadiusMiles  = $STORMRADIUS;
\$detectCyclone     = $DETECTCYCLONE;
\$cycloneURL        = "$CYURL";
\$expanAlert        = $EXPANALERT;
\$sleep             = $SLEEP;
\$theHoldtime       = $HOLDTIME;
\$cronInt           = $CRONINT;

// Raspberry Pi temperature alarms
\$piAlarms = $piAlarms;
\$soft     = $piSoftTemp;   // Soft warning temperature
\$hot      = $piHotTemp;    // Critical temperature
?>
EOF

log "config.php written successfully."

# ------------------------------------------------------------
# Install Cron Job
# ------------------------------------------------------------
log "Installing cron job..."

CRON_FILE="/etc/cron.d/cap-warn"
echo "*/$CRONINT * * * * root /usr/bin/cap-warn/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1" > "$CRON_FILE"
chmod 644 "$CRON_FILE"
chown root:root "$CRON_FILE"

log "Cron job installed via /etc/cron.d/cap-warn."

# ------------------------------------------------------------
# Log Rotation
# ------------------------------------------------------------
log "Configuring logrotate..."

cat > /etc/logrotate.d/cap-warn <<EOF
/var/log/cap-warn/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
    create 644 root root
}
EOF

log "Logrotate configured."

whiptail --title "Installation Complete" \
--msgbox "\
CAP-Warn is now fully configured.

Cron will run the alert processor every $CRONINT minutes.
Previous configuration backup:
$BACKUP

Installer version used:
$INSTALLER_VERSION

Press OK to finish." 15 70
log "Displayed installation complete message."

echo ""
echo "============================================================"
echo " CAP-Warn Installation Complete"
echo "------------------------------------------------------------"
echo "System: $piVersion"
echo "Installer: $INSTALLER_VERSION"
echo "You can run CAP-Warn manually at any time using:"
echo "    /usr/bin/cap-warn/cap_warn.sh"
echo ""
echo "Running it manually will preload all data immediately."
echo ""
echo "As they used to say back in the '60s:"
echo "   \"Keep on truckin'... the weather waits for no one.\""
echo "============================================================"
echo ""

log "===== INSTALLER COMPLETE ====="
