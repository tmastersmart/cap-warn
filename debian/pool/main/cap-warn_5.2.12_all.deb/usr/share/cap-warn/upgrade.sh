#!/bin/bash
# CAP-Warn upgrade script
# (c) 2026 KJ5MZL — la2way.com
echo "Testing for upgrades .."
# Remove old WX sound directory if it exists
if [ -d "/var/lib/cap-warn/sounds/wx" ]; then
    rm -rf /var/lib/cap-warn/sounds/wx
    echo "Sound Upgrade.."
fi

echo "ok"
exit 0
