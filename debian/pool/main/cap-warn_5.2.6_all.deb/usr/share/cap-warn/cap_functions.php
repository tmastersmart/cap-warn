<?php
/*
 © 2023–2026 KJ5MZL / WRXB288
 la2way.com • lagmrs.com
 All rights reserved. This module and all functions within it
 are fully copyrighted and NOT open‑source.

 You are granted permission to use this software on your personal
 node or repeater. HUB operators must provide a link back to me
 in some form (website, dashboard, documentation, etc.).

 This software may NOT be modified, redistributed, repackaged,
 incorporated into any image, or included in any distribution
 without explicit written approval from KJ5MZL.

 Donations are appreciated.
 This software is provided as FreeViewWare.

 Software made in loUiSiAna — it's just better.
*/

function all_clear($in){
global $action,$file1,$file,$alertTxt,$tailfile,$node,$outTmp,$alertTxtHeadline,$local,$special,$specialTXT,$specialUL,$status;
$action="";$file="";
$datum= date('m-d-Y H:i:s');
$outTmp    ="/tmp/tmp.gsm"; if (file_exists($outTmp)){unlink($outTmp);} 
if (file_exists($tailfile)){unlink($tailfile);}
if (file_exists($alertTxtHeadline)){unlink($alertTxtHeadline);} 
if (file_exists($special)){unlink($special);} 
if (file_exists($specialUL)){unlink($specialUL);} 
if (file_exists($specialTXT)){unlink($specialTXT);} 
// has-issued-a,has-expired,weather-station,weather,
// There has been a past alert so we need to clear
if (file_exists($alertTxt)){
 unlink($alertTxt);
 $out="Processing All clear";save_task_log ($out);print "$datum $out\n";
 check_gsm_db  ("silence1");                    if($file1){$action = "$action $file1";}
 check_gsm_db  ("updated weather information"); if($file1){$action = "$action $file1";}
 check_wav_db  ("strong click");                if($file1){$action = "$action $file1";}
 check_gsm_db  ("clear");                       if($file1){$action = "$action $file1";}
 //check_wav_db  ("star dull");                   if($file1){$action = "$action $file1";}
$file=$outTmp;playSound($out); 
if(!$status){$status="OK";}
 }
}


function haversine($lat1, $lon1, $lat2, $lon2) {
    $R = 3959; // miles
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);

    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}


function parseNhcCycloneXml($xmlString) {
    $xml = simplexml_load_string($xmlString);
    $xml->registerXPathNamespace('nhc', 'http://www.nhc.noaa.gov');

    $cyclones = [];

    foreach ($xml->xpath('//nhc:Cyclone') as $c) {
        $cyclones[] = [
            'center'    => (string)$c->center,
            'type'      => (string)$c->type,
            'name'      => (string)$c->name,
            'wallet'    => (string)$c->wallet,
            'atcf'      => (string)$c->atcf,
            'datetime'  => (string)$c->datetime,
            'movement'  => (string)$c->movement,
            'pressure'  => (string)$c->pressure,
            'wind'      => (string)$c->wind,
            'headline'  => (string)$c->headline,
        ];
    }

    return $cyclones;
}

function filterActiveCyclones($cyclones) {
    $active = [];

    foreach ($cyclones as $c) {
        $wind = intval($c['wind']);
        $headline = strtoupper($c['headline']);
        $type = strtoupper($c['type']);

        if ($wind === 0) continue;
        if (str_contains($headline, 'DISSIPATED')) continue;
        if (str_contains($headline, 'POST-TROPICAL')) continue;
        if (str_contains($type, 'POST-TROPICAL')) continue;

        $active[] = $c;
    }

    return $active;
}

function getNewestCyclone($cyclones) {
    usort($cyclones, function($a, $b) {
        return strtotime($b['datetime']) - strtotime($a['datetime']);
    });

    return $cyclones[0] ?? null;
}

function isCycloneCurrent($cyclone, $maxAgeHours = 4) {

    if (!$cyclone || empty($cyclone['datetime'])) {
        return false;
    }

    $advisoryTime = strtotime($cyclone['datetime']);
    if ($advisoryTime === false) {
        return false;
    }

    $ageSec = time() - $advisoryTime;
    $ageHours = $ageSec / 3600;
    return ($ageHours <= $maxAgeHours);
}

function getCurrentCyclone($xmlString) {
    $cyclones = parseNhcCycloneXml($xmlString);
    $active   = filterActiveCyclones($cyclones);
    if (empty($active)) {        return null;    }
    $newest = getNewestCyclone($active);
    if (!isCycloneCurrent($newest)) {        return null;    }
    return $newest;
}

function decodeZonesFromPointFile($pointFile) {
    if (!file_exists($pointFile)) {        return false;    }
    $json = json_decode(file_get_contents($pointFile), true);
    if (!$json || !isset($json["features"])) {return false;}
    // Look for the first feature with zone info
    foreach ($json["features"] as $f) {
        if (!isset($f["properties"])) { continue; }
        $p = $f["properties"];
        $zones = [
            "forecast" => null,
            "county"   => null
        ];
        // forecastZone URL → extract LAZxxx
        if (isset($p["forecastZone"])) {$zones["forecast"] = basename($p["forecastZone"]);  }
        // county URL → extract LACxxx
        if (isset($p["county"])) {$zones["county"] = basename($p["county"]); }
        // If we found both, return them
        if ($zones["forecast"] && $zones["county"]) {return $zones;}
    }

    return false;
}

function fetchZoneAlerts($zone1, $zone2, $outfile, $ver) {

    $datum = date('m-d-Y H:i:s');
    print "$datum fetch zone alerts - ";

    $urls = [
        "zone1" => "https://api.weather.gov/alerts/active?zone=$zone1",
        "zone2" => "https://api.weather.gov/alerts/active?zone=$zone2"
    ];

    $allFeatures = [];

    foreach ($urls as $label => $url) {

        $debugFile = "/tmp/{$label}_debug.json";

        $start = hrtime(true);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER => true,
            CURLOPT_HTTPHEADER => [
                "Accept: application/cap+xml",
                "Accept-Language: en",
                "User-Agent: la2way.com $ver weather software"
            ]
        ]);

        $raw = curl_exec($ch);
        $curlErr  = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);

        $elapsed = round((hrtime(true) - $start) / 1e9, 2);

        $headers  = substr($raw, 0, $headerSize);
        $response = substr($raw, $headerSize);

        // ALWAYS save debug file
        file_put_contents($debugFile, $response);

        if ($raw === false || $httpCode !== 200) {

            $debug  = "NWS Zone Fetch Failure ($label):\n";
            $debug .= "URL: $url\n";
            $debug .= "HTTP Code: $httpCode\n";
            $debug .= "Curl Error: $curlErr\n";
            $debug .= "Elapsed: {$elapsed}s\n";
            $debug .= "Headers:\n$headers\n";
            $debug .= "Body saved to: $debugFile\n";

            save_task_log($debug);
            print "\n$debug\n";
            continue;
        }

        // Decode JSON body
        $json = json_decode($response, true);
        if (isset($json["features"])) {
            $allFeatures = array_merge($allFeatures, $json["features"]);
        }
    }

    // Deduplicate by ID
    $unique = [];
    foreach ($allFeatures as $alert) {
        $unique[$alert["id"]] = $alert;
    }

    $final = [
        "type" => "FeatureCollection",
        "features" => array_values($unique)
    ];

    // Save merged zone alerts (even if empty)
    file_put_contents($outfile, json_encode($final, JSON_PRETTY_PRINT));

    print "<ok> $elapsed Sec.\n";
}





function getZonesFromPointsApi($lat, $lon, $ver) {
    global $debugFile;
    $datum = date('m-d-Y H:i:s');
    $url   = "https://api.weather.gov/points/$lat,$lon";
    

    print "$datum fetch zones from points API - ";

    $start = hrtime(true);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => [
            "Accept: application/geo+json",
            "Accept-Language: en",
            "User-Agent: la2way.com $ver weather software"
        ]
    ]);

    $raw = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $elapsed = round((hrtime(true) - $start) / 1e9, 2);

    // Split header/body
    $headers  = substr($raw, 0, $headerSize);
    $response = substr($raw, $headerSize);

    // ALWAYS save the body for debugging
    file_put_contents($debugFile, $response);

    // Error handling
    if ($raw === false || $httpCode !== 200) {

        $debug  = "NWS Points Zone Fetch Failure:\n";
        $debug .= "URL: $url\n";
        $debug .= "HTTP Code: $httpCode\n";
        $debug .= "Curl Error: $curlErr\n";
        $debug .= "Elapsed: {$elapsed}s\n";
        $debug .= "Headers:\n$headers\n";
        $debug .= "Body saved to: $debugFile\n";

        save_task_log($debug);
        print "\n$debug\n";
        print "Error $elapsed Sec.\n";

        return false;
    }

    // Decode JSON
    $json = json_decode($response, true);
    if (!$json || !isset($json["properties"])) {
        print "Invalid points JSON (saved to $debugFile)\n";
        return false;
    }

    $p = $json["properties"];

    $zones = [
        "forecast" => isset($p["forecastZone"]) ? basename($p["forecastZone"]) : null,
        "county"   => isset($p["county"])       ? basename($p["county"])       : null
    ];

    if ($zones["forecast"] && $zones["county"]) {
        print "<ok> $elapsed Sec.\n";
        return $zones;
    }

    print "Missing zone info (see $debugFile)\n";
    return false;
}




function merge_alerts($pointFile, $zoneFile, $mergedFile) {

    $pointData = file_exists($pointFile)
        ? json_decode(file_get_contents($pointFile), true)
        : ["features" => []];

    $zoneData = file_exists($zoneFile)
        ? json_decode(file_get_contents($zoneFile), true)
        : ["features" => []];

    $combined = array_merge($pointData["features"], $zoneData["features"]);

    // Deduplicate by alert ID
    $unique = [];
    foreach ($combined as $alert) {
        $unique[$alert["id"]] = $alert;
    }

    $merged = [
        "type" => "FeatureCollection",
        "features" => array_values($unique)
    ];

    file_put_contents($mergedFile, json_encode($merged, JSON_PRETTY_PRINT));
}





function fetchCapAlerts($lat, $lon, $cacheFile, $ver) {
    $datum  = date('m-d-Y H:i:s');

    print "$datum fetch alerts - ";
    $url = "https://api.weather.gov/alerts/active?point=$lat,$lon";
    $start = hrtime(true);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HEADER => true,   // capture headers for debugging
        CURLOPT_HTTPHEADER => [
            "Accept: application/cap+xml",
            "Accept-Language: en",
            "User-Agent: la2way.com $ver weather software"
        ]
    ]);

    $raw = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $elapsed = round((hrtime(true) - $start) / 1e9, 2);

    // Split header + body
    $headers = substr($raw, 0, $headerSize);
    $response = substr($raw, $headerSize);

    // --- Error handling ---
    if ($raw === false || $httpCode !== 200) {

        $status = "Error";
        if ($elapsed >= 10) { $status .= " timeout"; }

        // Build detailed debug log
        $debug  = "NWS Fetch Failure:\n";
        $debug .= "URL: $url\n";
        $debug .= "HTTP Code: $httpCode\n";
        $debug .= "Curl Error: $curlErr\n";
        $debug .= "Elapsed: {$elapsed}s\n";
        $debug .= "Headers:\n$headers\n";
        $debug .= "Body (first 500 bytes):\n" . substr($response, 0, 500) . "\n";

        save_task_log($debug);print "\n$debug\n";
        
        print "$status $elapsed Sec.\n";

        if (file_exists($cacheFile)) { unlink($cacheFile); }
        return false;
    }

    // --- Save cache ---
    file_put_contents($cacheFile, $response, LOCK_EX);

    print "<ok> $elapsed Sec.\n";
    return true;
}

function fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, $cacheMinutes = 60, $cron = false) {
    $datum  = date('m-d-Y H:i:s');
    $url = "https://www.nhc.noaa.gov/" . ltrim($cycloneURL, "/");
    $now = time();
    $file=$cyclone;
    // --- Check Cache Age ---
    if (file_exists($file)) {
        $ageSec = $now - filemtime($file);
        $ageMin = floor($ageSec / 60);

        echo "$datum Cyclone cache age: {$ageMin} minutes (limit: {$cacheMinutes})\n";

        if ($ageMin < $cacheMinutes && !$cron) {
            echo "$datum Using cached cyclone data (fresh enough)\n";
            return true;
        }

        echo "$datum Cache expired — fetching new cyclone data\n";
    } else {
        echo "$datum No cyclone cache found — fetching new data\n";
    }

    // --- Fetch New Data ---
    $start = microtime(true);

    $headers = [
        "Accept: application/xml",
        "Accept-Language: en",
        "User-Agent: $ver 2way radio software"
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_FAILONERROR    => false,
    ]);

    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $elapsed = round(microtime(true) - $start, 2);

    // --- Error Handling ---
    if ($response === false || $httpCode >= 400) {
        echo "$datum NHC fetch error after {$elapsed} sec — keeping old cache\n";
        save_task_log("NHC fetch error, keeping old cache");
        return false;
    }

    // --- Save New Cache ---
    file_put_contents($file, $response, LOCK_EX);

    echo "$datum Cyclone data updated in {$elapsed} sec\n";
    save_task_log("Updated cyclone cache: $file");

    return true;
}


function save_task_log($status) {
    global $basename, $path,$logDir,$log ;

    $status = str_replace(',', ' ', $status);
    $datum  = date('m-d-Y H:i:s');



    // Ensure log directory exists
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

  // Build log line
    $line = "$datum,$status,$basename,,,\n";

  // Write to log
    file_put_contents($log, $line, FILE_APPEND | LOCK_EX);
}


function read_api($file) {
    global $NWheadline, $instruction, $headline, $event,
           $icon, $shortForcast, $detailedForecast,
           $url, $description, $apiVer;

    // Reset variables
    $NWheadline = "";
    $instruction = "";
    $headline = "";
    $event = "";
    $icon = "";
    $shortForcast = "";
    $detailedForecast = "";
    $url = "";
    $description = "";
    $apiVer = "";

    // Read + decode JSON
    $json = json_decode(file_get_contents($file), true);
    if (!$json) { save_task_log("JSON decode error in $file"); print "decode Error\n";       return false;    }

    // Extract version
    $apiVer = $json['@version'] ?? "";

    // Extract properties
    $props = $json['properties'] ?? [];

    $headline        = $props['headline']        ?? "";
    $description     = $props['description']     ?? "";
    $instruction     = $props['instruction']     ?? "";
    $event           = $props['event']           ?? "";
    $NWheadline      = implode("|", $props['NWSheadline'] ?? []);
    $url             = $props['forecast']        ?? "";
    $shortForcast    = $props['shortForecast']   ?? "";
    $detailedForecast= $props['detailedForecast']?? "";
    $icon            = $props['icon']            ?? "";

    // Normalize icon size
    if ($icon) { $icon = str_replace("size=medium", "size=small", $icon); }
    return true;
}






function isHurricane($type) {
    // Normalize to lowercase and trim whitespace
    $type = strtolower(trim($type));

    // Match only the word "hurricane"
    return $type === "hurricane";
}



// Helper function to parse coordinates from string like "38.3, -50.8"
function parseCoordinates($center) {
    $parts = explode(',', $center);
    if (count($parts) != 2) return [null, null];
    return [floatval(trim($parts[0])), floatval(trim($parts[1]))];
}


function watchdog(){
// not used in this release. 
// part of net going down detection
}
function read_api_json_alerts($file) {
    global $event, $headline, $description, $instruction,$debug,$datum;


    $event = [];
    $headline = [];
    $description = [];
    $instruction = [];

    if (!file_exists($file)) {
        print"$datum File not found $file\n";
        return false;
    }

    $json = file_get_contents($file);
    $data = json_decode($json, true);

    if (!isset($data['features']) || !is_array($data['features'])) {
        return false;
    }

    foreach ($data['features'] as $f) {
        if (!isset($f['properties'])) continue;

        $p = $f['properties'];

        $event[]       = $p['event']       ?? "";
        $headline[]    = $p['headline']    ?? "";
        $description[] = $p['description'] ?? "";
        $instruction[] = $p['instruction'] ?? "";
    }

    return true;
}
// (c)2026 module to play through ASL3
// $FILE MUST BE THE OUTPUT
function playSound($out){
   global $file,$action,$node,$status,$local,$outTmp,$out;
   exec ("sox $action $file",$output,$return_var);
   playSoundOnly($out);
}

function playSoundOnly($out){
   global $file,$action,$node,$status,$local,$outTmp,$out;
   $datum   = date('m-d-Y H:i:s');$out ="Playing file $file";save_task_log ($out);print "$datum $out\n";
   $base = pathinfo($file, PATHINFO_FILENAME);
   if($local){  exec("sudo asterisk -rx 'rpt localplay $node /tmp/$base'",$output,$return_var);}
   else{  exec("sudo asterisk -rx 'rpt playback $node /tmp/$base'",$output,$return_var);}
$action="";// clear the buffer
$filesize = filesize($file);   // bytes
$duration = $filesize / 1650;         // seconds (GSM 13.2kbps)
$duration = ceil($duration);          // round up for safety
print "$datum GSM duration approx $duration seconds\n";
sleep($duration);
sleep(20);
}



//
// Special use
function playSoundDesktop() {
   global $file,$action,$outTmp,$datum;
   $desktopMode = !file_exists("/usr/sbin/asterisk");
   exec("sox $action $file", $output, $return_var);
   $datum = date('m-d-Y H:i:s');$msg = "Playing file $file";save_task_log($msg);print "$datum $msg\n";
   exec("nohup cvlc --play-and-exit --gain=2.0 '$file' >/dev/null 2>&1 &");
}





?>

