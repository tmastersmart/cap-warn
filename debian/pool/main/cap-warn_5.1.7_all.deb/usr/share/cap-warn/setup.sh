#!/bin/bash
# ------------------------------------------------------------
# CAP-Warn Setup Utility
# ------------------------------------------------------------
# This setup program configures CAP-Warn for your node.
# In the spirit of 1960s computer rooms:
#   "Please do not fold, spindle, or mutilate this installer."
#
# Running setup.sh again will overwrite your settings,
# much like feeding a fresh stack of punch cards into the reader.
#
# And as Buckaroo Banzai wisely said:
#   "Wherever you go... there you are."
# ------------------------------------------------------------

# ------------------------------------------------------------
# Commodore 64 Style Boot Screen
# ------------------------------------------------------------
cd /usr/share/cap-warn

echo " "
echo " **** COMMODORE 64 BASIC V2 ****"
echo " "
echo " 64K RAM SYSTEM  38911 BASIC BYTES FREE"
echo " "
echo "READY."
sleep 1
echo "LOAD \"CAP-WARN SETUP\",8,1"
sleep 1
echo "SEARCHING FOR CAP-WARN SETUP"
sleep 1
echo "LOADING"
sleep 2
echo "READY."
sleep 1
echo "RUN"
sleep 1
echo " "
echo "Hang loose… CAP‑Warn is loading its cosmic subroutines."
sleep 2
echo "Outta sight… CAP‑Warn is warming up.."
sleep 2
echo " "




VERSION="v1.0.9"

LOGFILE="/var/log/cap-warn/install.log"
mkdir -p /var/log/cap-warn
touch "$LOGFILE"
chmod 644 "$LOGFILE"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $1" | tee -a "$LOGFILE"
}

log "===== CAP-WARN INSTALLER STARTED ====="

CONFIG="/etc/cap-warn/config.php"
BACKUP="/etc/cap-warn/config.php.bak_$(date +%Y%m%d_%H%M%S)"

mkdir -p /etc/cap-warn
chmod 755 /etc/cap-warn

log "Ensured /etc/cap-warn exists."

whiptail --title "CAP Warn Installer — (c) 2026 KJ5MZL Setup:$VERSION" --msgbox "\
CAP-Warn Setup Program
(c) 2023–2026 KJ5MZL — la2way.com
All rights reserved.

CAP-Warn is an automated alerting system that retrieves
National Weather Service CAP (Common Alerting Protocol)
messages, processes them, and plays alerts over your
AllStar node or repeater.

This installer will configure:
 1 Your node number
 2 GPS coordinates
 3 Hurricane tracking region
 4 Alert behavior and timing
 5 Text-to-speech options


Press OK to begin installation." 30 78
log "Displayed splash screen."



# ------------------------------------------------------------
# Backup existing config
# ------------------------------------------------------------
if [ -f "$CONFIG" ]; then
    cp "$CONFIG" "$BACKUP"
    log "Backed up existing config.php to $BACKUP"
    whiptail --title "Backup Created" --msgbox "Existing config.php backed up to:\n$BACKUP" 10 60
fi

# ------------------------------------------------------------
# VoiceRSS Warning
# ------------------------------------------------------------
# ------------------------------------------------------------
# TTS Engine Information
# ------------------------------------------------------------
whiptail --title "Text‑to‑Speech Options" \
--msgbox "CAP‑Warn supports two text‑to‑speech engines:\n
1. VoiceRSS (Recommended)
   - Most natural, human‑sounding voice
   - Requires internet and a FREE API key
   - Used when cloud TTS is available\n
2. Piper / asl‑tts (Offline Mode)
   - No API key required
   - Works without internet
   - Slightly more robotic\n
NOTE: CAP‑Warn still requires internet to download NWS alerts. 
Offline TTS only affects how alerts are spoken, not how they are received.\n
If you enter a VoiceRSS key, CAP‑Warn will use the high‑quality cloud voice.
If you skip the key, CAP‑Warn will automatically use the offline Piper voice." \
12 70

log "Displayed TTS engine information."


# ------------------------------------------------------------
# TTS API Key (Optional)
# ------------------------------------------------------------
TTSKEY=$(whiptail --inputbox "Enter your VoiceRSS API key (leave blank to use offline Piper TTS):" \
10 70 "" --title "VoiceRSS API Key (Optional)" 3>&1 1>&2 2>&3)

log "TTS API key entered (blank means offline mode)."




# ------------------------------------------------------------
# Node Number
# ------------------------------------------------------------
NODE=$(whiptail --inputbox "Enter your AllStar node number:" 10 60 "" --title "Node Number" 3>&1 1>&2 2>&3)
log "Node number entered: $NODE"


# ------------------------------------------------------------
# GPS Coordinates
# ------------------------------------------------------------
LAT=$(whiptail --inputbox "Enter repeater latitude:" 10 60 "" --title "GPS Latitude" 3>&1 1>&2 2>&3)
log "Latitude entered: $LAT"

LON=$(whiptail --inputbox "Enter repeater longitude:" 10 60 "" --title "GPS Longitude" 3>&1 1>&2 2>&3)
log "Longitude entered: $LON"

# ------------------------------------------------------------
# Hurricane Basin
# ------------------------------------------------------------
CHOICE=$(whiptail --title "Select Hurricane Feed (NHC GIS)" --menu "\
Choose the region closest:

1. Gulf & East Coast LA,TX,MS,AL,FL,GA,SC,NC,VA,MD,NJ,NY,MA,ME
2. Eastern Pacific West Coast CA,AZ Baja & Mexico West Coast
3. Central Pacific Hawaii
0. Disable hurricane detection
" 22 75 10 \
"1" "Atlantic (Louisiana → New York)" \
"2" "Eastern Pacific (California / Baja)" \
"3" "Central Pacific (Hawaii)" \
"0" "Disable hurricane detection" \
3>&1 1>&2 2>&3)

log "Hurricane basin : https://www.nhc.noaa.gov/$CHOICE"

case $CHOICE in
    1) CYURL="/gis-at.xml"; DETECTCYCLONE=true ;;
    2) CYURL="/gis-ep.xml"; DETECTCYCLONE=true ;;
    3) CYURL="/gis-cp.xml"; DETECTCYCLONE=true ;;
    0) CYURL="disabled"; DETECTCYCLONE=false ;;
esac

log "Cyclone detection: $DETECTCYCLONE, URL: $CYURL"

# ------------------------------------------------------------
# Storm Radius
# ------------------------------------------------------------
if [ "$DETECTCYCLONE" = true ]; then
    STORMRADIUS=$(whiptail --inputbox "Enter storm radius in miles (0 to disable):" 10 60 "600" --title "Storm Radius" 3>&1 1>&2 2>&3)
else
    STORMRADIUS=0
fi

log "Storm radius: $STORMRADIUS"

# ------------------------------------------------------------
# Expand Alerts
# ------------------------------------------------------------
whiptail --yesno "Expand alerts with description?" 10 60
EXPANALERT=$([ $? -eq 0 ] && echo true || echo false)
log "Expand alerts: $EXPANALERT"

# ------------------------------------------------------------
# Quiet Hours
# ------------------------------------------------------------
whiptail --yesno "Enable quiet hours (1am–6am)?" 10 60
SLEEP=$([ $? -eq 0 ] && echo true || echo false)
log "Quiet hours: $SLEEP"


# ------------------------------------------------------------
# Hold Timer
# ------------------------------------------------------------
HOLDTIME=$(whiptail --inputbox "Minutes to wait before repeating the same alert:" 10 60 "25" --title "Hold Timer" 3>&1 1>&2 2>&3)
log "Hold time: $HOLDTIME"

# ------------------------------------------------------------
# Cron Interval
# ------------------------------------------------------------
CRONINT=$(whiptail --inputbox "How often should alerts run? (minutes)" 10 60 "13" --title "Cron Interval" 3>&1 1>&2 2>&3)
log "Cron interval: $CRONINT"


# ------------------------------------------------------------
# Detect Raspberry Pi hardware
# ------------------------------------------------------------
piSystem=false
if [[ -r /proc/device-tree/model ]]; then
    piSystem=true
    piVersion=$(tr -d '\0' < /proc/device-tree/model)
else
    piVersion="$(uname -m -s -o -v)"
fi

log "Detected system: $piVersion"

# Default values
piAlarms="false"
piSoftTemp="70"
piHotTemp="80"

# ------------------------------------------------------------
# Only show Pi alarm options if this is a Raspberry Pi
# ------------------------------------------------------------
if [[ "$piSystem" == true ]]; then

    ALARM_CHOICE=$(whiptail --title "Raspberry Pi Detected" \
        --yesno "Detected: $piVersion

Would you like to enable the following alarms?

 • High CPU Temperature
 • Throttling Detection
 • Low Voltage Alerts

Recommended for Raspberry Pi nodes." \
        18 70 3>&1 1>&2 2>&3)

    if [[ $? -eq 0 ]]; then
        # User selected YES
        piAlarms="true"


# ------------------------------------------------------------
# Raspberry Pi Temperature Info Screen
# ------------------------------------------------------------
if [[ "$piSystem" == true ]]; then

    whiptail --title "Raspberry Pi Temperature Guidance" --msgbox "\
Detected: $piVersion

Raspberry Pi boards have built-in thermal protection:
 • Soft throttling begins around 80°C
 • Hard throttling begins around 85°C
 • Emergency shutdown occurs near 90°C

Recommended alarm levels:
 • Soft Warning: 65°C
 • Critical Alarm: 75°C

Use lower values ONLY for special cases:
 • Hot car installations
 • Fan failure detection
 • Enclosures with poor airflow

For example:
 • Car nodes may use 55°C / 64°C
 • Repeater sites should use 65°C / 75°C

You may manualy adjust later in config files

You will now be asked to enter your preferred thresholds." \
        22 75
fi





        # Soft warning temperature
        piSoftTemp=$(whiptail --inputbox "Detected: $piVersion

Enter SOFT warning temperature (°C):" \
            12 60 "70" --title "Soft Temp Warning" 3>&1 1>&2 2>&3)

        # Critical temperature
        piHotTemp=$(whiptail --inputbox "Detected: $piVersion

Enter CRITICAL temperature (°C):" \
            12 60 "80" --title "Critical Temp Alarm" 3>&1 1>&2 2>&3)

    else
        # User selected NO
        piAlarms="false"
    fi
fi









# ------------------------------------------------------------
# Write config.php
# ------------------------------------------------------------
log "Writing config.php..."

cat > "$CONFIG" <<EOF
<?php
// ------------------------------------------------------------
// CAP-Warn Configuration File
// ------------------------------------------------------------
// This file is generated automatically by setup.sh.
// You *can* adjust these values manually if you're brave,
// but remember: running setup.sh again will overwrite them.
//
// As the old 1960s computer operators used to say:
//   "If you don't like the output, feed the machine better cards."
//
// And in the immortal words of Buckaroo Banzai:
//   "Wherever you go... there you are."
// 
// System detected $piVersion
// ------------------------------------------------------------
\$installerVer = "$VERSION";
\$node = "$NODE";
\$tts  = "$TTSKEY";
\$lat = "$LAT";
\$lon = "$LON";
\$stormRadiusMiles = $STORMRADIUS;
\$detectCyclone    = $DETECTCYCLONE;
\$cycloneURL       = "$CYURL";
\$expanAlert       = $EXPANALERT;
\$sleep    = $SLEEP;
\$theHoldtime = $HOLDTIME;

// Raspberry Pi temperature alarms
\$piAlarms = $piAlarms;
\$soft = $piSoftTemp;   // Soft warning temperature
\$hot  = $piHotTemp;    // Critical temperature

?>
EOF

log "config.php written successfully."


# ------------------------------------------------------------
# Install Cron Job (Debian-style, always root)
# ------------------------------------------------------------
log "Installing cron job..."

CRON_FILE="/etc/cron.d/cap-warn"

echo "*/$CRONINT * * * * root /usr/bin/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1" | sudo tee $CRON_FILE > /dev/null

sudo chmod 644 $CRON_FILE
sudo chown root:root $CRON_FILE

log "Cron job installed via /etc/cron.d/cap-warn."


# ------------------------------------------------------------
# Log Rotation
# ------------------------------------------------------------
log "Configuring logrotate..."

cat > /etc/logrotate.d/cap-warn <<EOF
/var/log/cap-warn/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
    create 644 root root
}
EOF

log "Logrotate configured."

whiptail --title "Installation Complete" \
--msgbox "\
CAP-Warn is now fully configured.

Cron will run the alert processor every $CRONINT minutes.
Your previous configuration was backed up to:
$BACKUP

Press OK to finish." 15 70
log "Displayed installation complete message."

echo ""
echo "============================================================"
echo " CAP-Warn Installation Complete $piVersion"
echo "------------------------------------------------------------"
echo "You can run CAP-Warn manually at any time using:"
echo "    /usr/local/bin/cap_warn.sh"
echo ""
echo "Running it manually will preload all data immediately."
echo ""
echo "As they used to say back in the '60s:"
echo "   \"Keep on truckin'... the weather waits for no one.\""
echo "============================================================"
echo ""




log "===== INSTALLER COMPLETE ====="

