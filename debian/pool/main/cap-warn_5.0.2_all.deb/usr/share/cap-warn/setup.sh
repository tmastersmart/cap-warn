#!/bin/bash

VERSION="v1.0.2"

LOGFILE="/var/log/cap-warn/install.log"
mkdir -p /var/log/cap-warn
touch "$LOGFILE"
chmod 644 "$LOGFILE"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $1" | tee -a "$LOGFILE"
}

log "===== CAP-WARN INSTALLER STARTED ====="

CONFIG="/etc/cap-warn/config.php"
BACKUP="/etc/cap-warn/config.php.bak_$(date +%Y%m%d_%H%M%S)"

mkdir -p /etc/cap-warn
chmod 755 /etc/cap-warn

log "Ensured /etc/cap-warn exists."

whiptail --title "CAP Warn Installer — (c) 2026 KJ5MZL Setup:$VERSION" --msgbox "\
CAP-Warn Setup Program
(c) 2023–2026 KJ5MZL — la2way.com
All rights reserved.

CAP-Warn is an automated alerting system that retrieves
National Weather Service CAP (Common Alerting Protocol)
messages, processes them, and plays alerts over your
AllStar node or repeater.

This installer will configure:
 1 Your node number
 2 GPS coordinates
 3 Hurricane tracking region
 4 Alert behavior and timing
 5 Text-to-speech options

IMPORTANT — VoiceRSS API Key Required
-------------------------------------
CAP-Warn uses the VoiceRSS Text-to-Speech service for
custom spoken alerts. You must obtain a FREE API key at:

    https://www.voicerss.org/

If you do not provide a valid API key during setup,
text-to-speech will be DISABLED and alerts will be preset sounds.

Press OK to begin installation." 30 78
log "Displayed splash screen."



# ------------------------------------------------------------
# Backup existing config
# ------------------------------------------------------------
if [ -f "$CONFIG" ]; then
    cp "$CONFIG" "$BACKUP"
    log "Backed up existing config.php to $BACKUP"
    whiptail --title "Backup Created" --msgbox "Existing config.php backed up to:\n$BACKUP" 10 60
fi

# ------------------------------------------------------------
# VoiceRSS Warning
# ------------------------------------------------------------
whiptail --title "IMPORTANT: VoiceRSS API Key Required" \
--msgbox "You must create a FREE account at https://www.voicerss.org/ and obtain an API key.\n\nPress OK to continue." 12 60
log "Displayed VoiceRSS warning."

# ------------------------------------------------------------
# Node Number
# ------------------------------------------------------------
NODE=$(whiptail --inputbox "Enter your AllStar node number:" 10 60 "" --title "Node Number" 3>&1 1>&2 2>&3)
log "Node number entered: $NODE"

# ------------------------------------------------------------
# TTS API Key
# ------------------------------------------------------------
TTSKEY=$(whiptail --inputbox "Enter your VoiceRSS API key:" 10 60 "" --title "TTS API Key" 3>&1 1>&2 2>&3)
log "TTS API key entered."

# ------------------------------------------------------------
# GPS Coordinates
# ------------------------------------------------------------
LAT=$(whiptail --inputbox "Enter repeater latitude:" 10 60 "" --title "GPS Latitude" 3>&1 1>&2 2>&3)
log "Latitude entered: $LAT"

LON=$(whiptail --inputbox "Enter repeater longitude:" 10 60 "" --title "GPS Longitude" 3>&1 1>&2 2>&3)
log "Longitude entered: $LON"

# ------------------------------------------------------------
# Hurricane Basin
# ------------------------------------------------------------
CHOICE=$(whiptail --title "Select Hurricane Feed (NHC GIS)" --menu "\
Choose the region closest to your repeater:

1. Atlantic — Gulf & East Coast  LA, TX, MS, AL, FL, GA, SC, NC,
   VA, MD, NJ, NY, MA, ME
2. Eastern Pacific — West Coast  CA, AZ Baja & Mexico West Coast
3. Central Pacific — Hawaii
0. Disable hurricane detection
" 22 75 10 \
"1" "Atlantic (Louisiana → New York)" \
"2" "Eastern Pacific (California / Baja)" \
"3" "Central Pacific (Hawaii)" \
"0" "Disable hurricane detection" \
3>&1 1>&2 2>&3)

log "Hurricane basin : https://www.nhc.noaa.gov/$CHOICE"

case $CHOICE in
    1) CYURL="/gis-at.xml"; DETECTCYCLONE=true ;;
    2) CYURL="/gis-ep.xml"; DETECTCYCLONE=true ;;
    3) CYURL="/gis-cp.xml"; DETECTCYCLONE=true ;;
    0) CYURL="disabled"; DETECTCYCLONE=false ;;
esac

log "Cyclone detection: $DETECTCYCLONE, URL: $CYURL"

# ------------------------------------------------------------
# Storm Radius
# ------------------------------------------------------------
if [ "$DETECTCYCLONE" = true ]; then
    STORMRADIUS=$(whiptail --inputbox "Enter storm radius in miles (0 to disable):" 10 60 "600" --title "Storm Radius" 3>&1 1>&2 2>&3)
else
    STORMRADIUS=0
fi

log "Storm radius: $STORMRADIUS"

# ------------------------------------------------------------
# Expand Alerts
# ------------------------------------------------------------
whiptail --yesno "Expand alerts with description?" 10 60
EXPANALERT=$([ $? -eq 0 ] && echo true || echo false)
log "Expand alerts: $EXPANALERT"

# ------------------------------------------------------------
# Local Playback
# ------------------------------------------------------------
whiptail --yesno "Play alerts locally only?" 10 60
LOCAL=$([ $? -eq 0 ] && echo true || echo false)
log "Local playback: $LOCAL"

# ------------------------------------------------------------
# Quiet Hours
# ------------------------------------------------------------
whiptail --yesno "Enable quiet hours (1am–6am)?" 10 60
SLEEP=$([ $? -eq 0 ] && echo true || echo false)
log "Quiet hours: $SLEEP"

# ------------------------------------------------------------
# Talk Enable
# ------------------------------------------------------------
whiptail --yesno "Enable voice playback?" 10 60
TALKFLAG=$([ $? -eq 0 ] && echo true || echo false)
log "Talk flag: $TALKFLAG"

DEBUG=false

# ------------------------------------------------------------
# Hold Timer
# ------------------------------------------------------------
HOLDTIME=$(whiptail --inputbox "Minutes to wait before repeating the same alert:" 10 60 "25" --title "Hold Timer" 3>&1 1>&2 2>&3)
log "Hold time: $HOLDTIME"

# ------------------------------------------------------------
# Cron Interval
# ------------------------------------------------------------
CRONINT=$(whiptail --inputbox "How often should alerts run? (minutes)" 10 60 "13" --title "Cron Interval" 3>&1 1>&2 2>&3)
log "Cron interval: $CRONINT"

# ------------------------------------------------------------
# Write config.php
# ------------------------------------------------------------
log "Writing config.php..."

cat > "$CONFIG" <<EOF
<?php
\$node = "$NODE";
\$tts  = "$TTSKEY";
\$lat = "$LAT";
\$lon = "$LON";
\$stormRadiusMiles = $STORMRADIUS;
\$detectCyclone    = $DETECTCYCLONE;
\$cycloneURL       = "$CYURL";
\$expanAlert       = $EXPANALERT;
\$local    = $LOCAL;
\$sleep    = $SLEEP;
\$talkFlag = $TALKFLAG;
\$debug    = $DEBUG;
\$theHoldtime = $HOLDTIME;
?>
EOF

log "config.php written successfully."

# ------------------------------------------------------------
# Install Cron Job
# ------------------------------------------------------------
log "Installing cron job..."

crontab -l 2>/dev/null | grep -v "cap_warn.sh" > /tmp/cron.tmp
echo "*/$CRONINT * * * * /usr/local/bin/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1" >> /tmp/cron.tmp
crontab /tmp/cron.tmp
rm /tmp/cron.tmp

log "Cron job installed."

# ------------------------------------------------------------
# Log Rotation
# ------------------------------------------------------------
log "Configuring logrotate..."

cat > /etc/logrotate.d/cap-warn <<EOF
/var/log/cap-warn/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
    create 644 root root
}
EOF

log "Logrotate configured."

whiptail --title "Installation Complete" \
--msgbox "\
CAP-Warn is now fully configured.

Cron will run the alert processor every $CRONINT minutes.
Your previous configuration was backed up to:
$BACKUP

Press OK to finish." 15 70
log "Displayed installation complete message."

echo ""
echo "============================================================"
echo " CAP-Warn Installation Complete"
echo "------------------------------------------------------------"
echo "You can run CAP-Warn manually at any time using:"
echo "    /usr/local/bin/cap_warn.sh"
echo ""
echo "Running it manually will preload all data immediately."
echo "============================================================"
echo ""



log "===== INSTALLER COMPLETE ====="

