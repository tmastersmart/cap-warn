<?php
/**
 * Pushover Notification Integration
 *
 * Pushover is a simple push notification service for iOS and Android devices.
 * It allows applications to send real-time notifications to users' mobile devices
 * via a straightforward HTTP REST API.
 *
 * Using code from API with some improvements 
 * API Documentation: https://support.pushover.net/i44-example-code-and-pushover-libraries#php
 *
 * How it works:
 * - You register an application on Pushover to get an API Token (App Token)
 * - Each user who wants to receive notifications provides their User Key
 * - You send notifications by making a POST request to:
 *   https://api.pushover.net/1/messages.json
 *
 * This section uses the Pushover API to send push notifications from the
 * AllStarLink / Asterisk system (or whatever your script does).
 *
 * Required parameters for sending a message:
 *   - token     : Your application API token
 *   - user      : The user/group key of the recipient
 *   - message   : The notification text
 *   Optional: title, priority, sound, url, etc.
 *
 *   Enter your keys in the confif file
 *
 * @author     KJ5MZL
 * @version    1.0
 * @link       https://support.pushover.net/i44-example-code-and-pushover-libraries#php
 */



function send_pushover_notification($message) {
global $user_key,$api_token,$push_limit,$push_file,$datum,$node ;
//   if(!$user_key or $api_token){return false;}
// ------------------------------
$datum   = date('m-d-Y H:i:s');
//$push_file = "/tmp/push_daily_counter.txt";
//$push_limit   = 10;   // max alarms per day
$today   = date("Ymd");$push_date = "";$push_count = 0;
if (file_exists($push_file)) {$parts= explode(",", trim(file_get_contents($push_file)));// Load existing file
 if (count($parts)==2) {$push_date=$parts[0];$push_count=intval($parts[1]);}
}
if ($push_date !== $today) {$push_date  = $today;$push_count=0;}// Reset
if ($push_count>= $push_limit) {echo "$datum Pushover limit reached ($push_count)\n"; return;}   // clear
$push_count++;file_put_contents($push_file, $push_date . "," . $push_count);

print "$datum Pushover $push_count sent today\n";
$message="[Node:$node] ($push_count) $message";
//    $user_key = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';  // Pushover User Key
//    $api_token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';  // Pushover API Token You create your own
$data = array(
    'token' => $api_token,
    'user' => $user_key,
    'message' => $message,
    'priority' => 1 // HIGH PRIORITY
);
$ch=curl_init('https://api.pushover.net:443/1/messages.json');
curl_setopt($ch, CURLOPT_POST, true);curl_setopt($ch, CURLOPT_POSTFIELDS, $data);curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response=curl_exec($ch);
 if(curl_errno($ch)) { echo 'Error:' . curl_error($ch); }
 curl_close($ch);
// echo $response;
return $response;
}





?>