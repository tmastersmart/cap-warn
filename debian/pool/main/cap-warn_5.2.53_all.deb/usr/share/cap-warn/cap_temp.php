<?php
//  ------------------------------------------------------------
//  (c) 2023/2026  by KJ5MZL WRXB288 lagmrs.com all rights reserved
//
//    for nodes to keep track of the temp (HAM/GMRS)
// -------------------------------------------------------------
//
//   _____ _____  _    _   _______                     __  __             _ _             
//  / ____|  __ \| |  | | |__   __|                   |  \/  |           (_) |            
// | |    | |__) | |  | |    | | ___ _ __ ___  _ __   | \  / | ___  _ __  _| |_ ___  _ __ 
// | |    |  ___/| |  | |    | |/ _ \ '_ ` _ \| '_ \  | |\/| |/ _ \| '_ \| | __/ _ \| '__|
// | |____| |    | |__| |    | |  __/ | | | | | |_) | | |  | | (_) | | | | | || (_) | |   
//  \_____|_|     \____/     |_|\___|_| |_| |_| .__/  |_|  |_|\___/|_| |_|_|\__\___/|_|   
//                                            | |                                         
//                                            |_| 


//
// From the PI specs: https://www.raspberrypi.com/documentation/computers/processors.html
//Pi must stay below 85c at all times. To be safe 70 is my danger zone. 
//The PI will regulate its own temp by throttling down when its hot, 
//but throttling down reduces cpu cycles. 
//
//
//  ------------------------------------------------------------
//   MODULE: TEMP
//   DO NOT FOLD, SPINDLE, OR MUTILATE
//   IF RUN STAND-ALONE: EXIT ON FAILURE
//   IF INCLUDED: RETURN CONTROL TO CALLER
//   ------------------------------------------------------------ 
//   
// v2.4 09/18/23 intergration into odd_min.php chron.
// v2.5 12/10/23 Bug fix systax error con printout
// v2.6 12/31/23 Tagline cleanup 
// v2.7 1/10/24 temp log moved and purging added.
// v2.8 10/25/25
// v2.9 05/25/2026 Conversion to a module of cap-warn
// v3
// v3.1  6/16/2026 beter anti spamming and better detection
// v3.2  6/18/2026 Pushover added Bug fix was not trigering on soft

$pathUSR = "/usr/share/cap-warn";$pathI = $pathUSR;// till its all changed over
$pathETC = "/etc/cap-warn";



require_once("$pathETC/config.php");
require_once("$pathETC/advanced_config.php");
// Program directory for internal includes

include_once("$pathUSR/sound_db.php");
include_once("$pathUSR/cap_functions.php");
$piSystem=false;if (is_readable("/proc/device-tree/model")) {$piVersion = file_get_contents ("/proc/device-tree/model");$piSystem=true;}
$out="";
$datum   = date('m-d-Y H:i:s');

// ------ new temp routine for up to pi 5 and hamvoip
$temp = 0;$tempf=0;
// Try vcgencmd first
$line = exec("sudo /usr/bin/vcgencmd measure_temp 2", $output, $return_var);
if ($return_var === 0 && !empty($line)) {
    // Normalize output
    // Examples:
    // temp=48.2'C
    // temp=48.2
    // 48.2
    $line = trim(str_replace(["temp=", "'", "C"], "", $line));
    if (is_numeric($line)) {$temp = (float)$line;}// Extract numeric value
}
// Fallback for Pi 5 or broken vcgencmd
if ($temp === 0) {
    $sys_temp = @file_get_contents('/sys/class/thermal/thermal_zone0/temp');
    if ($sys_temp !== false && is_numeric($sys_temp)) {$temp = $sys_temp / 1000;}  // millidegrees → °C

}
//---------------------
$tempf = (float)(($temp * 9 / 5) + 32);
print "$datum CPU Temp is $tempf F $temp C \n";

// ----  vcgencmd throttle monitor  ----
$cmd  = 'sudo /usr/bin/vcgencmd get_throttled 2>/dev/null';
$line = trim(shell_exec($cmd));

if (!$line) {
    save_task_log('ERROR: vcgencmd returned empty output');
    $val = 0;
} else {
    // Accept: throttled=0x50005, throttled=0X0, throttled=0x0
    if (preg_match('/^throttled=0[xX]([0-9A-Fa-f]+)$/', $line, $m)) {
        $val = hexdec($m[1]);
    } else {
        save_task_log("ERROR: unexpected throttled output: $line");
        $val = 0;
    }
}

// ----  Bit definitions (official Raspberry Pi)  ----
$messages = [];

if ($val & 0x00001) $messages[] = 'under-voltage-detected';
if ($val & 0x00002) $messages[] = 'arm-frequency-capped';
if ($val & 0x00004) $messages[] = 'currently-throttled';
if ($val & 0x00008) $messages[] = 'soft-temp-limit-active';

// Sticky bits  dont use they wont go away without reboot
// if ($val & 0x10000) $messages[] = 'under-voltage-occurred';
// if ($val & 0x20000) $messages[] = 'arm-frequency-capped-occurred';
// if ($val & 0x40000) $messages[] = 'throttling-occurred';
// if ($val & 0x80000) $messages[] = 'soft-temp-limit-occurred';

$throttled = $messages ? implode('_ ', $messages) : '';
// under-voltage-detected,-currently-throttled,-under-voltage-has-occurred,-throttling-has-occurred

$datum   = date('m-d-Y H:i:s');
$cmd=""; $action="";$TMPstatus="ok";
if($throttled){
//save_task_log($throttled);
echo "$datum $throttled\n";
    check_sound("star dull"); if ($file1) $action .= " $file1";
    check_sound("silence1"); if ($file1) $action .= " $file1"; 
    check_sound($throttled); if ($file1) $action .= " $file1";
    check_sound("star dull"); if ($file1) $action .= " $file1";
    check_sound("silence1"); if ($file1) $action .= " $file1";
    $TMPstatus="REPORT";


// we need serveral events befor this is considered true.
$datum   = date('m-d-Y H:i:s');
$LoV__counter = "/tmp/low_volt_counter.txt";
$LoV_limit   = 10;   // max alarms per day
$today   = date("Ymd");
$LoV_date = "";
$LoV_count = 0;
if (file_exists($LoV_file)) {$parts = explode(",", trim(file_get_contents($LoV_file)));// Load existing file
 if (count($parts) == 2) {$LoV_date  = $parts[0];$LoV_count = intval($parts[1]);}
}
if ($LoV_date !== $today) {$LoV_date  = $today;$LoV_count = 0;}// Reset if date changed
if ($LoV_count <= $LoV_limit) {
   $out= "LowVolt count:$LoV_count not high enough Event: $throttled\n";save_task_log($out);print"$datum $out\n";
   $throttled="";$action="";$TMPstatus="ok";// erase the event its minor  
   }
$LoV_count++;file_put_contents($LoV_file, $LoV_date . "," . $LoV_count);

// if it pases above its real process pushover
if($throttled){
   $out= "LowVolt counter:$LoV_count Event: $throttled\n";save_task_log($out);print"$datum $out\n";
   if($user_key && $api_token){ 
     send_pushover_notification($throttled);
     if($pushNotify = "pi_pushover"){$throttled="";$action="";$TMPstatus="ok";}// only send push
    }
  } 
}
//$soft     = 56;   // Soft warning temperature
//$hot      = 64;    // Critical temperature

if ($debug || $temp >= $soft) {

if($user_key && $api_token){ send_pushover_notification($out);}

$TMPstatus="REPORT";
check_sound("star dull");if($file1){$action = "$action $file1";}
check_sound($nodeName);if($file1){$action = "$action $file1";} // Name (server,repeater,node,tower,temperature) or any name in the database.");
// new temp in case no dec returns
$parts = explode('.', $temp, 2);
$whole   = $parts[0];
$decimal = isset($parts[1]) ? $parts[1] : 0;

$oh=false;make_number ($whole);$action = "$action $actionOut";
if($decimal>=1){
check_sound("point");if($file1){$action = "$action $file1";} 
$oh=false;make_number ($decimal); $action = "$action $actionOut";
}
check_sound("degrees");if($file1){$action = "$action $file1";} 
check_sound("celsius");if($file1){$action = "$action $file1";} 

if ($temp >=$hot){ //emergency,beep,attention-required 
  $status ="CPU High limit $temp deg, >$hot";save_task_log ($status); if($user_key && $api_token){ send_pushover_notification($out);}
 if ($temp >=$high){// 2 phase alert hot and emergency
  check_sound("emergency");if($file1){$action = "$action $file1";}
  check_sound("warning");if($file1){$action = "$action $file1";}
  check_sound("attention-required");if($file1){$action = "$action $file1";}
  } 
else{
  $status ="CPU overheat $temp deg, >$soft";save_task_log ($status); if($user_key && $api_token){ send_pushover_notification($out);}
  check_sound ("alert");if($file1){$action = "$action $file1";}
  check_sound ("high");if($file1){$action = "$action $file1";}
  }

check_sound("beep");if($file1){$action = "$action $file1";} 
}// end of high
check_sound ("silence1");if($file1){$action = "$action $file1";}

if ($pushNotify = "pi_pushover"){$throttled="";$action="";$TMPstatus="ok";}// only send pusover

}// end temp hot


if($action){ // we have sound to play 
// ------------------------------
// DAILY LIMIT FOR UV ALARMS
// ------------------------------
$datum   = date('m-d-Y H:i:s');
//$uv_file = "/tmp/uv_daily_counter.txt";
$today   = date("Ymd");
//$uv_limit   = 10;   // max alarms per day
$uv_date = "";
$uv_count = 0;
if (file_exists($uv_file)) {$parts = explode(",", trim(file_get_contents($uv_file)));// Load existing file
 if (count($parts) == 2) {$uv_date  = $parts[0];$uv_count = intval($parts[1]);}
}
if ($uv_date !== $today) {$uv_date  = $today;$uv_count = 0;}// Reset if date changed
// If limit reached, skip alarm
if ($uv_count >= $uv_limit) {echo "$datum Skipping UV alarm — daily limit reached ($uv_count)\n"; $action="";}   // clear the action audio playback
// Increment and save
$uv_count++;file_put_contents($uv_file, $uv_date . "," . $uv_count);
echo "$datum UV alarm #$uv_count for today\n";


$datum   = date('m-d-Y H:i:s');
if($debug){unlink($flag2);}// force playing
if (file_exists($flag2 )) {
    $ageSeconds  = time() - filemtime($flag2);$ageMinutes  = floor($ageSeconds / 60);
    echo "$datum Hold temp flag age: {$ageMinutes} minutes (limit: {$theHoldtime} minutes)\n";
    if ($ageSeconds > ($theHoldtime * 60)) {unlink($flag2);}
    elseif ($cron) {echo "$datum Cron override — resetting temp play timer.\n";unlink($flag2);}
    else {echo "$datum Skipping temp playback — still within hold window.\n";}
}
if (!file_exists($flag2)){ 
  if($action){ // retest it may have been cancled
    $file=$outTmp;playSound($out); $fileOUT = fopen($flag2, "w") ;flock( $fileOUT, LOCK_EX );fwrite ($fileOUT, "$datum,played alert,$action\n");flock( $fileOUT, LOCK_UN );fclose ($fileOUT);
    }// yes its still action
 } // only play if no holdback file
}// end if action

?>