<?php
/*
 © 2023–2026 KJ5MZL / WRXB288
 la2way.com • lagmrs.com
 All rights reserved. This module and all functions within it
 are fully copyrighted and NOT open‑source.

 You are granted permission to use this software on your personal
 node or repeater. HUB operators must provide a link back to me
 in some form (website, dashboard, documentation, etc.).

 This software may NOT be modified, redistributed, repackaged,
 incorporated into any image, or included in any distribution
 without explicit written approval from KJ5MZL.

 Donations are appreciated.
 This software is provided as FreeViewWare.

 Software made in loUiSiAna — it's just better.
*/

// v1 of cyclone module (moved into a module seperate froom the core
// v2 
// setup for seperate testing


$pathUSR = "/usr/share/cap-warn";$pathI = $pathUSR;// till its all changed over
$pathETC = "/etc/cap-warn";


require_once("$pathETC/advanced_config.php");// load first allows config to overide
require_once("$pathETC/config.php");
include_once("$pathUSR/sound_db.php");
include_once("$pathUSR/cap_functions.php");

//$debug = true;
$Cevent[] ="";$active="";
$verFile = "$pathUSR/version.txt";
$relFile = "$pathUSR/release.txt";
if (file_exists($verFile)) { $ver = "v" . trim(file_get_contents($verFile));} 
else { $ver = "v5.1.0";}
if (file_exists($relFile)) {  $release = trim(file_get_contents($relFile));}
else { $release = "5/26/2026";}
$zone = trim(shell_exec('timedatectl show -p Timezone --value'));
if (!$zone) {    $zone = 'America/Chicago';}
date_default_timezone_set($zone);
$phpzone = date_default_timezone_get();
$cron=false;if (!empty($argv[1])) {  if ($argv[1] =="cron"){$cron=true;} }

if(!$cron){
$mute=false;
if($sleep){
 if($hour>=1 and $hour <=6){
 $mute=true;$out="Sleep Mute $day $hour am";save_task_log ($out);print "$datum $out\n";
  }
 }
}
else{$mute=false;}

$datum   = date('m-d-Y H:i:s');
print"$datum Start Cyclone Module\n";

fetchNhcCyclones($cycloneURL, $cyclone, $cycloneTxt, $ver, 60, $cron);

if ($debug){$cyclone= "$pathUSR/test_cyclone_alert.xml";}// for testing overide

print "$datum Loading $cyclone\n";
$xmlString = file_get_contents($cyclone);
if ($xmlString === false) {print "$datum ERROR: Failed to read cyclone file: $cyclone\n";}
$cyclones  = parseNhcCycloneXml($xmlString);
if (empty($cyclones)) {
print "$datum None detected\n";
//    if (file_exists($cycloneLast)) {unlink($cycloneLast); echo "$datum Ccyclone keys cleared.\n";}
}
else {
print "$datum " . count($cyclones) . " entries\n";
//    print_r($cyclones[0]);



$active    = filterActiveCyclones($cyclones);
if (empty($active)) {print "$datum None Active\n";}
 else {
    print "$datum " . count($active) . " entries Active\n";
  //   print_r($active[0]);
 }

// Hur only mode set by setup
if ($hurOnly === true) {
    $active = array_filter($active, 'isHurricane');
    if (empty($active)) { 
    print "$datum No Hurricanes Active\n";

}
    
    
    
    }
   else {print "$datum " . count($active) . " Hurricanes Active\n";}
}

$datum   = date('m-d-Y H:i:s');
      
if ($active) {
$Cevent       = [];
$Cheadline    = [];
$Cdescription = [];
$Ctype        = [];
$Cname        = [];  
    foreach ($active as $cyclone) {
        // Skip stale advisories unless debug mode
        if ($debug === false) {
            if (!isCycloneCurrent($cyclone)) {
          
            $advTime = strtotime($cyclone['pubdate']);
            $now     = time();
            //$ageMin  = round(($now - $advTime) / 60);
            $ageHrs  = round(($now - $advTime) / 3600, 1);   // age in hours, 1 decimal
            print "$datum Skipping {$cyclone['name']} — advisory stale "."(Advisory: {$cyclone['pubdate']}, Age: {$ageHrs} Hrs)\n";
            continue;
            }
        }

        // Distance filter
        list($stormLat, $stormLon) = array_map('floatval', explode(',', $cyclone['center']));
        $distance = haversine($lat, $lon, $stormLat, $stormLon);

        if ($distance > $stormRadiusMiles) {
            print "$datum Skipping {$cyclone['name']} — too far away ({$distance} miles)\n";
            continue;
        }

        // Only announce if advisory changed
        if ($debug === false) {
         if (!isNewCycloneAdvisory($cyclone)) {
            print "$datum Skipping {$cyclone['name']} — already announced\n";
            continue;
        }
       }
    else {print"$datum DEBUG playing cyclone replay...\n";}
        // Clean headline
        $cyclone['headline'] = cleanCycloneHeadline($cyclone['headline']);
        $headline  = $cyclone['headline'];
//        $sentences = preg_split('/(?<=[.?!])\s+/', $headline);
//        $short     = trim(implode(' ', array_slice($sentences, 0, 2)));
        $summary = buildStormSummary($cyclone);
        $Cevent[] =  $cyclone['type'] . " " . $cyclone['name'] . ". " . $headline. " " . $summary;// better formated TTS see function to adjust
//        $Cevent[] = "Test 123"; 
    

print "$datum Cyclone added: "
    . "Type: {$cyclone['type']} "
    . "Name: {$cyclone['name']} "
    . "Code: {$cyclone['atcf']} "
    . "Date: {$cyclone['datetime']} "
    . "Distance: $distance miles\n";


    } // end foreach active cyclones


    // Build TTS only if we have events
 if ($Cevent) {
    $ttsEvents = [];
    foreach ($Cevent as $i => $ev) {
       if ($ev !== "") {$ttsEvents[] = $ev;}
    }
    // Build final TTS string
    if (count($ttsEvents) == 1) {$ttsString = $ttsEvents[0];}
 else {
        $parts = [];
       foreach ($ttsEvents as $txt) { $parts[] = $txt;}
        $ttsString = implode(" ", $parts);
    }
print "$datum $ttsString\n";



///PHP Warning:  Undefined variable $cycloneWAV in /usr/share/cap-warn/cap_cyclones.php on line 194
 
$cycloneTXT="/tmp/cyclone_text.txt"; // move to config
// New pushover send the text we got.....Only if on all
if($user_key && $api_token && $pushNotify == "all"){send_pushover_notification($ttsString);}

 build_tts_audio($ttsString, $cycloneWAV, $cycloneTXT, $cycloneUL, $node, $tts, "CYCLONE: ");

 
//now we have a sound file its either GSM or UL 
if(!$mute){
$out="";
if ($tts){$file=$cycloneWAV;}
else{$file = $cycloneUL;}

$action="";
check_gsm_db  ("silence1");    if($file1){$action = "$action $file1";}// space between them
check_wav_db  ("nbc");if($file1){$action = "$action $file1";}
$action="$action $file";
//print"$action\n";
$file=$outTmp;
playSound($out); 
// play a mdc just for fun.
//print "$datum MDC-1200 bursts for ID $node\n";   exec("sudo asterisk -rx 'rpt cmd $node cop 60 I,$node'",$output,$return_var);    

} 

  }// end if Cevent
}// end of none active

print"$datum End Cyclone Module\n";

// I mark each closing brace with a short label so it's obvious which
// block it closes. This makes the structure easier to follow and helps
// prevent mistakes when editing nested logic. (c)2026 KJ5MZL