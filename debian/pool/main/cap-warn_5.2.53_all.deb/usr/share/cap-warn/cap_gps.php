<?php
// © 2023–2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// GPS module

$GPS_DEBUG=false;

function detect_gps_position() {
global $datum,$GPS_DEBUG;
if (shell_exec("pgrep gpsd")) {
if ($GPS_DEBUG) print "$datum GPSD detected, reading TPV...\n";
$json=shell_exec("gpspipe -w -n 5 2>/dev/null | grep TPV | head -n 1");
if ($GPS_DEBUG) print "$datum GPSD RAW: $json\n";
$data=json_decode($json,true);
if (!empty($data) && (empty($data['lat'])||empty($data['lon']))) print "$datum GPSD detected but no fix yet (mode={$data['mode']})\n";
if (!empty($data['lat']) && !empty($data['lon'])) { print "$datum GPS: Using GPSD\n"; return [$data['lat'],$data['lon']]; }
}
foreach (glob("/dev/serial/by-id/*") as $dev) {
$pos=read_nmea_from_device($dev);
if ($pos==="NOFIX") continue; if (is_array($pos)) { print "$datum GPS: Using $dev\n"; return $pos; }
}
foreach (glob("/dev/ttyACM*") as $dev) {
$pos=read_nmea_from_device($dev);
if ($pos==="NOFIX") continue; if (is_array($pos)) { print "$datum GPS: Using $dev\n"; return $pos; }
}
foreach (glob("/dev/ttyUSB*") as $dev) {
$pos=read_nmea_from_device($dev);
if ($pos==="NOFIX") continue; if (is_array($pos)) { print "$datum GPS: Using $dev\n"; return $pos; }
}
return false;
}

function read_nmea_from_device($dev) {
global $GPS_DEBUG,$datum;
$line=shell_exec("timeout 1 cat $dev 2>/dev/null | grep GGA | head -n 1");
if ($GPS_DEBUG) { if ($line) print "$datum NMEA from $dev: $line\n"; else print "$datum No GGA from $dev\n"; }
if (!$line) return false;
$p=explode(",",$line);
$fix=$p[6]??"0"; $sats=$p[7]??"0";
if ($fix=="0"||$sats=="00") { print "$datum GPS detected at $dev no fix yet (sats=$sats)\n"; return "NOFIX"; }
$fixType=["0"=>"No Fix","1"=>"GPS Fix","2"=>"DGPS Fix","4"=>"RTK Fixed","5"=>"RTK Float","6"=>"Dead Reckoning","7"=>"Manual Input","8"=>"Simulation"];
$type=$fixType[$fix]??"Unknown";
$hdop=$p[8]??"N/A";
$rating=($hdop<=1)?"Excellent":(($hdop<=2)?"Good":(($hdop<=5)?"Fair":(($hdop<=10)?"Poor":"Very Poor")));
$accuracy_m=round($hdop*5,1);
print "$datum GPS (satellites=$sats, fix=$type, hdop=$hdop $rating, Accuracy {$accuracy_m}m)\n";
return parse_nmea_gga($line);
}

function parse_nmea_gga($line) {
$p=explode(",",$line);
if (count($p)<6) return false;
$latRaw=$p[2]; $latHem=$p[3]; $lonRaw=$p[4]; $lonHem=$p[5];
if (!$latRaw||!$lonRaw) return false;
$lat=floor($latRaw/100)+fmod($latRaw,100)/60; if ($latHem==="S") $lat=-$lat;
$lon=floor($lonRaw/100)+fmod($lonRaw,100)/60; if ($lonHem==="W") $lon=-$lon;
return [round($lat,4),round($lon,4)];
}
?>
