#!/bin/bash

# **** CAP-WARN setup (whiptail) ****
# little retro installer for cap-warn
# dont fold spindle or mutilate

cd /usr/share/cap-warn

# **** random retro joke list ****
JOKES=(
"Buckaroo Banzai: Wherever you go... there you are."
"Please do not fold spindle, or mutilate this installer"
"Would you like to play a game?"
"A strange game. The only winning move is not to play."
"Game over man game over!"
"Hack the planet!"
"Mess with the best, die like the rest."
"Peace love and harmony."
"Make love not war."
"Stay groovy, man."
"Far out totally far out."
"Can you dig it?"
"Outta sight!"
"Keep on truckin."
"Good vibes only."
"Flower power is in full bloom."
)

RANDOM_JOKE=${JOKES[$RANDOM % ${#JOKES[@]}]}

# **** fake C64 boot ****
echo " "
echo " **** COMMODORE 64 BASIC V2 ****"
echo " "
echo " 64K RAM SYSTEM  38911 BASIC BYTES FREE"
echo " "
echo "READY."
sleep 1
echo "LOAD \"CAP-WARN SETUP\",8,1"
echo "SEARCHING FOR CAP-WARN SETUP"
echo "LOADING"
sleep 1
echo "$RANDOM_JOKE"
echo " "

# **** logging ****
LOGDIR="/var/log/cap-warn"
LOGFILE="$LOGDIR/install.log"
mkdir -p "$LOGDIR"
touch "$LOGFILE"
chmod 644 "$LOGFILE"

log(){ echo "$(date '+%Y-%m-%d %H:%M:%S')  $1" >> "$LOGFILE"; }

log "*** CAP-WARN INSTALLER STARTED ***"

# **** paths ****
CONFIG="/etc/cap-warn/config.php"
mkdir -p /etc/cap-warn
chmod 755 /etc/cap-warn
log "ensured /etc/cap-warn exists"

# **** installer version bump ****
SETUPVERFILE="/usr/share/cap-warn/setup_version.txt"
[ ! -f "$SETUPVERFILE" ] && echo "1" > "$SETUPVERFILE"
SETUPVER=$(cat "$SETUPVERFILE")
NEWSETUPVER=$((SETUPVER+1))
echo "$NEWSETUPVER" > "$SETUPVERFILE"
INSTALLER_VERSION="$NEWSETUPVER"
log "edited $INSTALLER_VERSION times"

# **** load old config (if any) ****
OLD_PUSHKEY="";OLD_PUSHTOKEN="";OLD_NOTIFYMODE=""
OLD_NODE="";OLD_TTSKEY="";OLD_LAT="";OLD_LON=""
OLD_STORMRADIUS="";OLD_DETECTCYCLONE="";OLD_CYURL=""
OLD_EXPANALERT="";OLD_SEXPANALERT="";OLD_SLEEP=""
OLD_HOLDTIME="";OLD_CRONINT="";OLD_PIALARMS=""
OLD_SOFT="";OLD_HOT="";OLD_HURONLY=""

if [ -f "$CONFIG" ];then
 log "loading existing config $CONFIG"
 OLD_NODE=$(php -r "include '$CONFIG'; echo \$node ?? '';")
 OLD_TTSKEY=$(php -r "include '$CONFIG'; echo \$tts ?? '';")
 OLD_LAT=$(php -r "include '$CONFIG'; echo \$lat ?? '';")
 OLD_LON=$(php -r "include '$CONFIG'; echo \$lon ?? '';")
 OLD_STORMRADIUS=$(php -r "include '$CONFIG'; echo \$stormRadiusMiles ?? '';")
 OLD_DETECTCYCLONE=$(php -r "include '$CONFIG'; echo \$detectCyclone ?? '';")
 OLD_CYURL=$(php -r "include '$CONFIG'; echo \$cycloneURL ?? '';")
 OLD_EXPANALERT=$(php -r "include '$CONFIG'; echo \$expanAlert ?? '';")
 OLD_SEXPANALERT=$(php -r "include '$CONFIG'; echo \$specialExpand ?? '';")
 OLD_SLEEP=$(php -r "include '$CONFIG'; echo \$sleep ?? '';")
 OLD_HOLDTIME=$(php -r "include '$CONFIG'; echo \$theHoldtime ?? '';")
 OLD_CRONINT=$(php -r "include '$CONFIG'; echo \$cronInt ?? '';")
 OLD_PIALARMS=$(php -r "include '$CONFIG'; echo \$piAlarms ?? '';")
 OLD_SOFT=$(php -r "include '$CONFIG'; echo \$soft ?? '';")
 OLD_HOT=$(php -r "include '$CONFIG'; echo \$hot ?? '';")
 OLD_HURONLY=$(php -r "include '$CONFIG'; echo \$hurOnly ?? '';")
 OLD_NOTIFYMODE=$(php -r "include '$CONFIG'; echo \$pushNotify?? '';")
 OLD_PUSHKEY=$(php -r "include '$CONFIG'; echo \$user_key?? '';")
 OLD_PUSHTOKEN=$(php -r "include '$CONFIG'; echo \$api_token ?? '';")
fi

# **** defaults ****
[ -z "$OLD_STORMRADIUS" ] && OLD_STORMRADIUS="1000"
[ -z "$OLD_HOLDTIME" ] && OLD_HOLDTIME="25"
[ -z "$OLD_CRONINT" ] && OLD_CRONINT="13"
[ -z "$OLD_SOFT" ] && OLD_SOFT="65"
[ -z "$OLD_HOT" ] && OLD_HOT="75"
[ -z "$OLD_HURONLY" ] && OLD_HURONLY="false"
[ -z "$OLD_EXPANALERT" ] && OLD_EXPANALERT="true"
[ -z "$OLD_SEXPANALERT" ] && OLD_SEXPANALERT="false"
[ -z "$OLD_DETECTCYCLONE" ] && OLD_DETECTCYCLONE="false"

normalize_bool(){ [[ "$1" == "1" ]] && echo "true" || echo "false"; }

OLD_DETECTCYCLONE=$(normalize_bool "$OLD_DETECTCYCLONE")
OLD_HURONLY=$(normalize_bool "$OLD_HURONLY")
OLD_EXPANALERT=$(normalize_bool "$OLD_EXPANALERT")
OLD_SEXPANALERT=$(normalize_bool "$OLD_SEXPANALERT")
OLD_SLEEP=$(normalize_bool "$OLD_SLEEP")
OLD_PIALARMS=$(normalize_bool "$OLD_PIALARMS")

# **** detect pi ****
piSystem=false
if [[ -r /proc/device-tree/model ]];then
 piSystem=true
 piVersion=$(tr -d '\0' < /proc/device-tree/model)
else
 piVersion="$(uname -m -s -o -v)"
fi
log "Detected system: $piVersion"

# keep stdout on 3 for whiptail
exec 3>&1

# **** installer mode choice ****
if whiptail --title "CAP-Warn Installer Mode" --yesno "\
Installer can run in two modes:

  Graphic Mode (whiptail)
     Recommended for Raspberry Pi, SSH, and most terminals.
     Uses dialog-style menus and input boxes. With help.

  Text Mode (setup_text.sh)
     Recommended if:
       - You cannot type in whiptail boxes
       - Your terminal does not support dialog
       - You prefer plain text prompts
       - You dont need help

Would you like to continue in Graphic Mode?

Choose NO to switch to Text Mode." 20 70
then
 :
else
 echo ""
 clear
 echo "Switching to text-only installer..."
 echo ""
 sleep 1
 bash /usr/share/cap-warn/setup_text.sh
 exit 0
fi

# **** splash ****
if ! whiptail --title "CAP Warn Installer — Setup:$INSTALLER_VERSION" --yesno "\
CAP-Warn Setup Program
(c) 2023/2026 KJ5MZL  la2way.com
All rights reserved.
$piVersion

CAP-Warn is an automated alerting system that retrieves
National Weather Service CAP (Common Alerting Protocol)
messages, processes them, and plays alerts over your
AllStar node or repeater.

This installer will configure:
 1 Node number
 2 Lat/Lon defaults or GPS auto-detection
 3 Hurricane tracking region
 4 Alert behavior and timing
 5 Text-to-speech options

Press YES to begin installation.
Press NO to abort." 22 78
then
 echo "Installation aborted by user."
 exit 1
fi

log "Displayed splash screen."

# keep only 5 newest backups
BACKUP_DIR="/etc/cap-warn"
BACKUP_PATTERN="config.php.bak_*"
ls -1t $BACKUP_DIR/$BACKUP_PATTERN 2>/dev/null | tail -n +6 | while read old;do
 rm -f "$old"
 log "Removed old backup: $old"
done

# **** TTS info ****
whiptail --title "Text to Speech Options" \
--msgbox "CAP-Warn supports two text to speech engines:\n
1. VoiceRSS (Recommended)
   Most natural human sounding voice
   Requires internet and a FREE API key
   Used when cloud TTS is available\n
2. Piper / asl-tts (Offline Mode)
   No API key required
   Works without internet
   Slightly more robotic slower\n
   In testing on a PI3b it used 100% CPU not recomended for a PI

If you enter a VoiceRSS key, CAP-Warn will use the high quality cloud voice.
If you skip the key, CAP-Warn will use asl-tts (dont use on PI)" \
25 70
log "Displayed TTS engine information."

# **** TTS key ****
TTSKEY=$(whiptail --inputbox "Enter your VoiceRSS API key (leave blank for asl-tts):" \
10 70 "$OLD_TTSKEY" --title "VoiceRSS API Key (Optional)" 2>&1 1>&3)
log "TTS API key entered (blank means offline mode). $TTSKEY"

# detect asl-tts
if command -v asl-tts >/dev/null 2>&1;then HAS_PIPER=1;else HAS_PIPER=0;fi

if [ "$piSystem" = true ] && [ -z "$TTSKEY" ];then
 whiptail --title "WARNING: Local TTS Performance" \
 --yesno "No VoiceRSS API key detected.\n\nUsing locally generated TTS audio on a Raspberry Pi may cause:\n\n - 100% CPU usage\n - Audio dropouts\n - Jitter on RF output\n\nIt is strongly recommended to use VoiceRSS instead.\n\nDo you want to continue anyway?" 18 70
 if [ $? -ne 0 ];then
  echo "User cancelled due to TTS warning. Exiting installer."
  log "User cancelled due to TTS warning"
  exit 1
 fi
fi

# **** install asl-tts if needed ****
if [ -z "$TTSKEY" ] && [ "$HAS_PIPER" -eq 0 ];then
 {
  echo 10
  echo "20 Preparing to install offline Piper/asl-tts ..";sleep 0.2
  echo 40
  echo "60 Installing asl3-tts/asl-tts ...";sleep 0.2
  apt-get install -y asl3-tts >/dev/null 2>&1
  echo 90
  echo "100 Installation complete.";sleep 0.2
 } | whiptail --gauge "Installing offline Piper/asl-tts ..." 8 60 0
 log "Installed asl3-tts for offline TTS."
elif [ -z "$TTSKEY" ] && [ "$HAS_PIPER" -eq 1 ];then
 log "Offline Piper TTS already installed — skipping installation."
else
 log "Using VoiceRSS — offline Piper TTS not required."
fi

# **** lat/lon combined ****
COORDS=$(whiptail --inputbox "\
Enter your default Lat /Lon Coordinates:

Latitude Longitude (example: 31.00 -92.00) 
If you have a GPS it will overide once locked.

You can press Enter to keep current values." 14 70 "$OLD_LAT $OLD_LON" --title "Lat Lon Coordinates" 2>&1 1>&3)
[ $? -ne 0 ] && { echo "Cancelled by user.";exit 1; }

LAT=$(echo "$COORDS" | awk '{print $1}')
LON=$(echo "$COORDS" | awk '{print $2}')
[ -z "$LAT" ] && LAT="$OLD_LAT"
[ -z "$LON" ] && LON="$OLD_LON"
log "Latitude: $LAT"
log "Longitude: $LON"

# **** node ****
NODE=$(whiptail --inputbox "Enter your AllStar node number:" 10 60 "$OLD_NODE" --title "Node Number" 2>&1 1>&3)
[ $? -ne 0 ] && { echo "Cancelled by user.";exit 1; }
[ -z "$NODE" ] && NODE="$OLD_NODE"
log "Node number: $NODE"
sleep 0.3

# **** expanded alert behavior ****
DEFAULT_CHOICE="1"
if [[ "$OLD_EXPANALERT" == "true" && "$OLD_SEXPANALERT" == "false" ]];then
 DEFAULT_CHOICE="2"
elif [[ "$OLD_EXPANALERT" == "true" && "$OLD_SEXPANALERT" == "true" ]];then
 DEFAULT_CHOICE="3"
fi

CHOICE=$(whiptail --title "Expanded Alert Behavior" --default-item "$DEFAULT_CHOICE" --menu "\
Choose how CAP-Warn should handle expanded alert descriptions.

1. Do NOT expand alerts
   Only the short alert name is spoken (Tornado Warning, etc.)

2. Expand alerts (play once)
   CAP-Warn reads the full text description using TTS, but
   only plays the expanded version once.

3. Expand alerts AND repeat
   CAP-Warn reads the full text description and repeats the
   expanded version each cycle. Higher traffic on busy systems.

Select your preferred behavior:" \
29 75 10 \
"1" "Do NOT expand alerts" \
"2" "Expand alerts (play once)" \
"3" "Expand alerts AND repeat" \
3>&1 1>&2 2>&3)

case "$CHOICE" in
 1) EXPANALERT=false;SEXPANALERT=false;;
 2) EXPANALERT=true;SEXPANALERT=false;;
 3) EXPANALERT=true;SEXPANALERT=true;;
esac
log "Expanded Alerts: $EXPANALERT, Repeat Expanded: $SEXPANALERT"

# **** pushover keys ****
PUSHKEY=$(whiptail --inputbox "Pushover is an instant notification service used to send alerts to your phone.\n\nEnter your *Pushover User Key*. from https://pushover.net/\n\nLeave this blank to disable Pushover notifications." 15 70 "$OLD_PUSHKEY" --title "Pushover User Key" 3>&1 1>&2 2>&3)
[ $? -ne 0 ] && { echo "User cancelled.";exit 1; }

PUSHTOKEN=$(whiptail --inputbox "Cap-Warn needs its own *Pushover API Token*.\n\nTo create one:\n1. Log in at https://pushover.net/\n2. Go to 'Create an Application/API Token'\n3. Copy the API Token here.\n\nLeave blank to cancel." 18 70 "$OLD_PUSHTOKEN" --title "Pushover API Token" 3>&1 1>&2 2>&3)
[ $? -ne 0 ] && { echo "User cancelled.";exit 1; }

# **** hurricane basin ****
DEFAULT_CHOICE="0"
case "$OLD_CYURL" in
 "/gis-at.xml") DEFAULT_CHOICE="1";;
 "/gis-ep.xml") DEFAULT_CHOICE="2";;
 "/gis-cp.xml") DEFAULT_CHOICE="3";;
 *) DEFAULT_CHOICE="0";;
esac

CHOICE=$(whiptail --default-item "$DEFAULT_CHOICE" --title "Select Hurricane Feed (NHC GIS)" --menu "\
CAP-Warn can monitor tropical systems from the National
Hurricane Center (NHC), including tropical depressions,
storms, hurricanes, and other cyclone advisories.

These alerts are in addition to normal NWS warnings and
are spoken once when released. Timing follows NHC update
schedules and may not match local quiet hours.

Recommended for nearby nodes. On wide-area systems this
may increase traffic. Reduce the distance filter if needed.

Choose the region closest to your location:" \
29 78 10 \
"1" "Atlantic / Gulf (LA TX MS AL FL GA SC NC VA MD NJ NY MA ME)" \
"2" "Eastern Pacific (CA AZ Baja California Mexico West Coast)" \
"3" "Central Pacific (Hawaii region)" \
"0" "Disable hurricane detection" \
3>&1 1>&2 2>&3)

case $CHOICE in
 1) CYURL="/gis-at.xml";DETECTCYCLONE=true;;
 2) CYURL="/gis-ep.xml";DETECTCYCLONE=true;;
 3) CYURL="/gis-cp.xml";DETECTCYCLONE=true;;
 0) CYURL="disabled";DETECTCYCLONE=false;;
esac
log "Cyclone detection: $DETECTCYCLONE, URL: $CYURL"

# **** storm radius ****
if [ "$DETECTCYCLONE" = true ];then
 STORMRADIUS=$(whiptail --inputbox "\
Enter the maximum distance (in miles) to announce tropical systems.

This setting applies ONLY to tropical cyclones from the
National Hurricane Center (NHC) such as Tropical Storms
and Hurricanes. It does NOT affect NWS tornado or severe
weather alerts.

Set to 0 to disable distance filtering." \
12 70 "$OLD_STORMRADIUS" \
--title "Cyclone Distance Filter" \
2>&1 1>&3)
else
 STORMRADIUS=0
fi
log "Storm radius: $STORMRADIUS"

REPORT_HURRICANE_ONLY="$OLD_HURONLY"

whiptail --title "Tropical Storm Reporting" \
--yesno "Do you want to announce ALL tropical systems (Tropical Storms, Depressions, etc.)?\n\nChoose NO to announce ONLY Hurricanes." \
10 60

if [ $? -eq 0 ];then
 REPORT_HURRICANE_ONLY="false"
else
 REPORT_HURRICANE_ONLY="true"
fi
log "Hurricane only: $REPORT_HURRICANE_ONLY"
sleep 0.3

# **** quiet hours ****
if [[ "$OLD_SLEEP" == "true" ]];then DEFAULT="--defaultyes";else DEFAULT="--defaultno";fi

whiptail $DEFAULT --yesno "\
Enable Quiet Hours (1AM - 6AM)?

When Quiet Hours are enabled, CAP-Warn will NOT speak
any alerts during overnight hours. This includes NWS
warnings and tropical cyclone announcements.

Alerts will still be logged, but no audio will be played.
This option is useful if your node is in a bedroom or
you prefer silence overnight.

Enable Quiet Hours?" \
14 70 --title "Quiet Hours (Mute Overnight)"

SLEEP=$([ $? -eq 0 ] && echo true || echo false)
log "Quiet hours: $SLEEP"

# **** hold timer ****
HOLDTIME=$(whiptail --inputbox "\
Minutes to wait before repeating the SAME NWS alert.

This applies ONLY to National Weather Service alerts
(Tornado Warnings, Severe Thunderstorm Warnings, etc.).

If the same alert is still active, CAP-Warn will wait
this long before speaking it again. This prevents
repeating the same alert too often.

Recommended: 25 minutes." \
14 70 "$OLD_HOLDTIME" \
--title "Hold Timer (NWS Alerts Only)" \
2>&1 1>&3)
log "Hold time: $HOLDTIME"

# **** cron interval ****
CRONINT=$(whiptail --inputbox "\
How often should CAP-Warn check for new alerts?

This controls how frequently the system runs its update
cycle (via cron). During each run, CAP-Warn checks for:

  New NWS alerts
  Expired alerts
  Updated alerts
  New tropical cyclone advisories (if enabled)

Shorter intervals mean faster updates, but more system
activity. Longer intervals reduce load but may delay
alert playback slightly.

Recommended: 5–10 minutes." \
16 70 "$OLD_CRONINT" \
--title "Alert Update Interval" \
2>&1 1>&3)
log "Cron interval: $CRONINT"

# **** pi alarms ****
piAlarms="${OLD_PIALARMS:-false}"
piSoftTemp="$OLD_SOFT"
piHotTemp="$OLD_HOT"

if [[ "$piSystem" == true ]];then
 if [[ "$piAlarms" == "true" ]];then
  whiptail --yesno "Detected: $piVersion

Raspberry Pi alarms are currently ENABLED.

NOTE:
This feature is recommended for local Pi-based nodes.
It has a limiter to prevent to many alerts but you can
set it to only send Pushover events.

Would you like to keep them enabled?" \
 18 70
  [ $? -ne 0 ] && piAlarms="false"
 else
  whiptail --yesno "Detected: $piVersion

Would you like to enable the following alarms?

 High CPU Temperature
 Throttling Detection
 Low Voltage Alerts
 
NOTE:
This feature is recommended for local Pi-based nodes.
It has a limiter to stop exessive alerts and you may set
it to only send Pushover alerts only.

Recommended for Raspberry Pi nodes." \
 18 70
  [ $? -eq 0 ] && piAlarms="true"
 fi

 if [[ "$piAlarms" == "true" ]];then
  whiptail --title "Raspberry Pi Temperature Guidance" --msgbox "\
Detected: $piVersion

Raspberry Pi boards have built-in thermal protection:
 Soft throttling begins around 80 C
 Hard throttling begins around 85 C
 Emergency shutdown occurs near 90 C

Recommended alarm levels:
 Soft Warning: 65 C
 Critical Alarm: 75 C

You may manually adjust later in config files.

You will now be asked to enter your preferred thresholds." \
 22 75

  piSoftTemp=$(whiptail --inputbox "Detected: $piVersion

Enter SOFT warning temperature C:" \
 12 60 "$piSoftTemp" --title "Soft Temp Warning" 2>&1 1>&3)

  piHotTemp=$(whiptail --inputbox "Detected: $piVersion

Enter CRITICAL temperature C:" \
 12 60 "$piHotTemp" --title "Critical Temp Alarm" 2>&1 1>&3)
 fi
fi
log "Pi alarms: $piAlarms, soft: $piSoftTemp, hot: $piHotTemp"

# **** pushover notify mode ****
if [ -n "$PUSHKEY" ] && [ -n "$PUSHTOKEN" ];then
 if [ "$PIALARMS" != "true" ];then
  NOTIFYMODE="all"
 else
  DEFAULT_MODE="${OLD_NOTIFYMODE:-all}"
  NOTIFYMODE=$(whiptail --title "Notification Options" --menu \
"Choose how you want to receive alerts.\n\nAll Alerts = Weather + Pi alerts (voice + Pushover)\nPi Alerts Only = Only Pi temp/undervoltage\nPushover Only = Pi alerts sent silently to phone\n" \
15 70 5 \
"all"        "1) All alerts by Voice + Pushover" \
"pi_both"    "2) Pi Temp/UV only (Voice + Pushover)" \
"pi_pushover" "3) Pi Temp/UV only (Pushover only, no voice)" \
3>&1 1>&2 2>&3)
  [ $? -ne 0 ] && { echo "User cancelled.";exit 1; }
 fi
else
 NOTIFYMODE="all"
fi

TODAY=$(date +"%m-%d-%Y")

# **** final confirm ****
if whiptail --title "CAP-Warn Configuration Summary $TODAY" --yesno "\
Ready to save the following configuration:

Node Number:          $NODE
Lat Lon:              $LAT / $LON
VoiceRSS Key:         ${TTSKEY:-(None - using offline TTS)}
Hurricane Detection:  $DETECTCYCLONE ($CYURL)
Storm Radius:         $STORMRADIUS miles
Hurricane Only:       $REPORT_HURRICANE_ONLY
Expanded Alerts:      $EXPANALERT
Repeat Exp Alerts:    $SEXPANALERT
Quiet Hours:          $SLEEP
Hold Time:            $HOLDTIME minutes
Cron Interval:        $CRONINT minutes
Raspberry Pi Alarms:  $piAlarms
  Soft Warning:       $piSoftTemp C
  Critical:           $piHotTemp C
Pushover KEY          $PUSHKEY
Pushover TOKEN        $PUSHTOKEN
Pushover Mode         $NOTIFYMODE
Press YES to save and continue.
Press NO to abort." 25 78
then
 echo "User confirmed - proceeding with save."
else
 echo "Installation aborted by user."
 exit 1
fi

# **** write config.php ****
log "Writing config.php..."

cat > "$CONFIG" <<EOF
<?php
// CAP-Warn config (auto)
// System: $piVersion
// Installer: $INSTALLER_VERSION $TODAY
\$editDate          = "$TODAY";
\$installerVer      = "$INSTALLER_VERSION";
\$node              = "$NODE";
\$tts               = "$TTSKEY";
\$lat               = "$LAT";
\$lon               = "$LON";
\$stormRadiusMiles  = $STORMRADIUS;
\$detectCyclone     = $DETECTCYCLONE;
\$cycloneURL        = "$CYURL";
\$hurOnly           = $REPORT_HURRICANE_ONLY;
\$expanAlert        = $EXPANALERT;
\$specialExpand     = $SEXPANALERT;
\$sleep             = $SLEEP;
\$theHoldtime       = $HOLDTIME;
\$cronInt           = $CRONINT;
\$user_key          = "$PUSHKEY";
\$api_token         = "$PUSHTOKEN";
\$pushNotify        = "$NOTIFYMODE"; // all pi-both pi-pushover
\$piAlarms          = $piAlarms;
\$soft              = $piSoftTemp;
\$hot               = $piHotTemp;
?>
EOF

log "config.php written"

# **** cron job ****
log "Installing cron job..."
CRON_FILE="/etc/cron.d/cap-warn"
echo "2-59/$CRONINT * * * * root /usr/bin/cap-warn/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1" > "$CRON_FILE"
chmod 644 "$CRON_FILE"
chown root:root "$CRON_FILE"
log "Cron job installed"

# **** logrotate ****
log "Configuring logrotate..."

cat > /etc/logrotate.d/cap-warn <<EOF
/var/log/cap-warn/*.log {
    daily
    rotate 14
    compress
    missingok
    notifempty
}
EOF

log "Logrotate configured"

whiptail --title "Installation Complete" \
--msgbox "\
CAP-Warn is now fully configured.

Cron will run the alert processor every $CRONINT minutes.
Previous configuration backup:
$BACKUP

Edited $INSTALLER_VERSION Times

Press OK to finish." 15 70
log "Displayed installation complete message."

echo
echo " **** CAP-WARN INSTALL COMPLETE ****"
echo " System: $piVersion"
echo " Edited $INSTALLER_VERSION times"
echo " Run: sudo bash /usr/bin/cap-warn/cap_warn.sh"
echo " or:  sudo cap_warn"
echo " Weather waits for no one."
echo " RANDOM_JOKE: $RANDOM_JOKE"
echo
log "*** INSTALLER COMPLETE ***"
