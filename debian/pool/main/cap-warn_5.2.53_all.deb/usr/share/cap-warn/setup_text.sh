#!/bin/bash

cd /usr/share/cap-warn

echo
echo "====--=--= CAP WARN SETUP text mode v3 =--=--===="
echo
echo "this will setup:"
echo " node number"
echo " lat/lon (or gps)"
echo " hurricane feed"
echo " storm radius"
echo " hurricane only"
echo " expanded alerts"
echo " quiet hours"
echo " hold timer"
echo " cron interval"
echo " tts engine"
echo " pi alarms (if pi)"
echo
echo "hit enter to start"
read

LOGDIR="/var/log/cap-warn"
LOGFILE="$LOGDIR/install.log"
sudo mkdir -p "$LOGDIR"
sudo touch "$LOGFILE"
sudo chmod 644 "$LOGFILE"

log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') $1" | sudo tee -a "$LOGFILE" >/dev/null; }

sudo mkdir -p /etc/cap-warn
sudo chmod 755 /etc/cap-warn

# detect pi
piSystem=false
if [[ -r /proc/device-tree/model ]];then
 piSystem=true
 piVersion=$(tr -d '\0' < /proc/device-tree/model)
else
 piVersion="$(uname -m -s -o -v)"
fi

echo "system: $piVersion"
log "system: $piVersion"

CONFIG="/etc/cap-warn/config.php"

# load old config
OLD_NODE="";OLD_TTSKEY="";OLD_LAT="";OLD_LON=""
OLD_STORMRADIUS="";OLD_DETECTCYCLONE="";OLD_CYURL=""
OLD_EXPANALERT="";OLD_SEXPANALERT="";OLD_SLEEP=""
OLD_HOLDTIME="";OLD_CRONINT="";OLD_PIALARMS=""
OLD_SOFT="";OLD_HOT="";OLD_HURONLY=""
OLD_NOTIFYMODE="";OLD_PUSHKEY="";OLD_PUSHTOKEN=""

if [ -f "$CONFIG" ];then
 log "loading old config"
 OLD_NODE=$(php -r "include '$CONFIG';echo \$node??'';")
 OLD_TTSKEY=$(php -r "include '$CONFIG';echo \$tts??'';")
 OLD_LAT=$(php -r "include '$CONFIG';echo \$lat??'';")
 OLD_LON=$(php -r "include '$CONFIG';echo \$lon??'';")
 OLD_STORMRADIUS=$(php -r "include '$CONFIG';echo \$stormRadiusMiles??'';")
 OLD_DETECTCYCLONE=$(php -r "include '$CONFIG';echo \$detectCyclone??'';")
 OLD_CYURL=$(php -r "include '$CONFIG';echo \$cycloneURL??'';")
 OLD_EXPANALERT=$(php -r "include '$CONFIG';echo \$expanAlert??'';")
 OLD_SEXPANALERT=$(php -r "include '$CONFIG';echo \$specialExpand??'';")
 OLD_SLEEP=$(php -r "include '$CONFIG';echo \$sleep??'';")
 OLD_HOLDTIME=$(php -r "include '$CONFIG';echo \$theHoldtime??'';")
 OLD_CRONINT=$(php -r "include '$CONFIG';echo \$cronInt??'';")
 OLD_PIALARMS=$(php -r "include '$CONFIG';echo \$piAlarms??'';")
 OLD_SOFT=$(php -r "include '$CONFIG';echo \$soft??'';")
 OLD_HOT=$(php -r "include '$CONFIG';echo \$hot??'';")
 OLD_HURONLY=$(php -r "include '$CONFIG';echo \$hurOnly??'';")
 OLD_NOTIFYMODE=$(php -r "include '$CONFIG';echo \$pushNotify??'';")
 OLD_PUSHKEY=$(php -r "include '$CONFIG';echo \$user_key??'';")
 OLD_PUSHTOKEN=$(php -r "include '$CONFIG';echo \$api_token??'';")
fi

# defaults
[ -z "$OLD_STORMRADIUS" ] && OLD_STORMRADIUS=1000
[ -z "$OLD_HOLDTIME" ] && OLD_HOLDTIME=25
[ -z "$OLD_CRONINT" ] && OLD_CRONINT=13
[ -z "$OLD_SOFT" ] && OLD_SOFT=65
[ -z "$OLD_HOT" ] && OLD_HOT=75
[ -z "$OLD_HURONLY" ] && OLD_HURONLY=false
[ -z "$OLD_EXPANALERT" ] && OLD_EXPANALERT=true
[ -z "$OLD_SEXPANALERT" ] && OLD_SEXPANALERT=false
[ -z "$OLD_DETECTCYCLONE" ] && OLD_DETECTCYCLONE=false

norm(){ [[ "$1" == "1" ]] && echo true || echo false; }

OLD_DETECTCYCLONE=$(norm "$OLD_DETECTCYCLONE")
OLD_HURONLY=$(norm "$OLD_HURONLY")
OLD_EXPANALERT=$(norm "$OLD_EXPANALERT")
OLD_SEXPANALERT=$(norm "$OLD_SEXPANALERT")
OLD_SLEEP=$(norm "$OLD_SLEEP")
OLD_PIALARMS=$(norm "$OLD_PIALARMS")

# installer version bump
SETUPVERFILE="/usr/share/cap-warn/setup_version.txt"
[ ! -f "$SETUPVERFILE" ] && echo 1 > "$SETUPVERFILE"
SETUPVER=$(cat "$SETUPVERFILE")
NEWSETUPVER=$((SETUPVER+1))
echo "$NEWSETUPVER" > "$SETUPVERFILE"
INSTALLER_VERSION="$NEWSETUPVER"
log "edited $INSTALLER_VERSION times"

echo
echo "cap-warn setup"
echo "--------------"

read -p "VoiceRSS key [$OLD_TTSKEY]: " TTSKEY
TTSKEY=${TTSKEY:-$OLD_TTSKEY}

echo
echo "lat/lon"
read -p "lat [$OLD_LAT]: " LAT
read -p "lon [$OLD_LON]: " LON
LAT=${LAT:-$OLD_LAT}
LON=${LON:-$OLD_LON}

echo
read -p "AllStar node [$OLD_NODE]: " NODE
NODE=${NODE:-$OLD_NODE}

echo
echo "hurricane feed:"
echo "1 atl"
echo "2 epac"
echo "3 cpac"
echo "0 off"
read -p "select [$OLD_CYURL]: " HF

case $HF in
 1) CYURL="/gis-at.xml"; DETECTCYCLONE=true;;
 2) CYURL="/gis-ep.xml"; DETECTCYCLONE=true;;
 3) CYURL="/gis-cp.xml"; DETECTCYCLONE=true;;
 0) CYURL="disabled"; DETECTCYCLONE=false;;
 *) CYURL="$OLD_CYURL"; DETECTCYCLONE="$OLD_DETECTCYCLONE";;
esac

if [ "$DETECTCYCLONE" = true ];then
 echo
 read -p "storm radius [$OLD_STORMRADIUS]: " STORMRADIUS
 STORMRADIUS=${STORMRADIUS:-$OLD_STORMRADIUS}

 echo
 read -p "hurricane only y/n [$OLD_HURONLY]: " HUR
 [[ "$HUR" =~ ^[Yy]$ ]] && REPORT_HURRICANE_ONLY=true || REPORT_HURRICANE_ONLY=false
else
 STORMRADIUS=0
 REPORT_HURRICANE_ONLY=false
fi

echo
read -p "expanded alerts y/n [$OLD_EXPANALERT]: " EA
[[ "$EA" =~ ^[Yy]$ ]] && EXPANALERT=true || EXPANALERT=false

echo
read -p "repeat expanded y/n [$OLD_SEXPANALERT]: " SEA
[[ "$SEA" =~ ^[Yy]$ ]] && SEXPANALERT=true || SEXPANALERT=false

echo
read -p "quiet hours y/n [$OLD_SLEEP]: " QS
[[ "$QS" =~ ^[Yy]$ ]] && SLEEP=true || SLEEP=false

echo
read -p "hold time [$OLD_HOLDTIME]: " HOLDTIME
HOLDTIME=${HOLDTIME:-$OLD_HOLDTIME}

echo
read -p "cron interval [$OLD_CRONINT]: " CRONINT
CRONINT=${CRONINT:-$OLD_CRONINT}

if [ "$piSystem" = true ];then
 echo
 echo "pi detected: $piVersion"
 read -p "enable pi alarms y/n [$OLD_PIALARMS]: " PA
 if [[ "$PA" =~ ^[Yy]$ ]];then
  piAlarms=true
  read -p "soft temp [$OLD_SOFT]: " piSoftTemp
  read -p "hot temp [$OLD_HOT]: " piHotTemp
  piSoftTemp=${piSoftTemp:-$OLD_SOFT}
  piHotTemp=${piHotTemp:-$OLD_HOT}
 else
  piAlarms=false
  piSoftTemp=$OLD_SOFT
  piHotTemp=$OLD_HOT
 fi
else
 echo
 echo "not a pi, skipping alarms"
 piAlarms=false
 piSoftTemp=$OLD_SOFT
 piHotTemp=$OLD_HOT
fi

read -p "Pushover user key [$OLD_PUSHKEY]: " PUSHKEY
PUSHKEY=${PUSHKEY:-$OLD_PUSHKEY}

read -p "Pushover token [$OLD_PUSHTOKEN]: " PUSHTOKEN
PUSHTOKEN=${PUSHTOKEN:-$OLD_PUSHTOKEN}

if [[ -n "$PUSHKEY" && -n "$PUSHTOKEN" ]];then
 if [[ "$OLD_PIALARMS" == true ]];then
  echo
  echo "notify modes:"
  echo "1 all"
  echo "2 pi both"
  echo "3 pi pushover"
  read -p "mode [$OLD_NOTIFYMODE]: " MODE
  case $MODE in
   1) NOTIFYMODE="all";;
   2) NOTIFYMODE="pi_both";;
   3) NOTIFYMODE="pi_pushover";;
   *) NOTIFYMODE="$OLD_NOTIFYMODE";;
  esac
 else
  NOTIFYMODE="all"
 fi
else
 NOTIFYMODE="$OLD_NOTIFYMODE"
fi

TODAY=$(date +"%m-%d-%Y")

echo
echo "==== summary ===="
echo "node: $NODE"
echo "lat/lon: $LAT / $LON"
echo "tts: $TTSKEY"
echo "cyclone: $DETECTCYCLONE $CYURL"
echo "radius: $STORMRADIUS"
echo "hur only: $REPORT_HURRICANE_ONLY"
echo "expand: $EXPANALERT"
echo "repeat: $SEXPANALERT"
echo "sleep: $SLEEP"
echo "hold: $HOLDTIME"
echo "cron: $CRONINT"
echo "pi alarms: $piAlarms soft:$piSoftTemp hot:$piHotTemp"
echo "pushover: $PUSHKEY / $PUSHTOKEN mode:$NOTIFYMODE"
echo "==============="
echo

read -p "save? y/N: " CONFIRM
[[ "$CONFIRM" =~ ^[Yy]$ ]] || { echo "not saved"; exit 0; }

echo "saving..."

sudo tee "$CONFIG" >/dev/null <<EOF
<?php
\$editDate="$TODAY";
\$installerVer="$INSTALLER_VERSION";
\$node="$NODE";
\$tts="$TTSKEY";
\$lat="$LAT";
\$lon="$LON";
\$stormRadiusMiles=$STORMRADIUS;
\$detectCyclone=$DETECTCYCLONE;
\$cycloneURL="$CYURL";
\$hurOnly=$REPORT_HURRICANE_ONLY;
\$expanAlert=$EXPANALERT;
\$specialExpand=$SEXPANALERT;
\$sleep=$SLEEP;
\$theHoldtime=$HOLDTIME;
\$cronInt=$CRONINT;
\$user_key="$PUSHKEY";
\$api_token="$PUSHTOKEN";
\$pushNotify="$NOTIFYMODE";
\$piAlarms=$piAlarms;
\$soft=$piSoftTemp;
\$hot=$piHotTemp;
?>
EOF

echo
echo "cron job:"
echo "1 install"
echo "2 remove"
echo "3 skip"
read -p "choice: " CRONCHOICE

case $CRONCHOICE in
 1)
  sudo bash -c "echo \"2-59/$CRONINT * * * * root /usr/bin/cap-warn/cap_warn.sh >> /var/log/cap-warn/cron.log 2>&1\" > /etc/cron.d/cap-warn"
  sudo chmod 644 /etc/cron.d/cap-warn
 ;;
 2)
  sudo rm -f /etc/cron.d/cap-warn
 ;;
esac

sudo tee /etc/logrotate.d/cap-warn >/dev/null <<EOF
/var/log/cap-warn/*.log {
 daily
 rotate 14
 compress
 missingok
 notifempty
}
EOF

echo "==== install done "
echo "run: /usr/bin/cap-warn/cap_warn.sh"

