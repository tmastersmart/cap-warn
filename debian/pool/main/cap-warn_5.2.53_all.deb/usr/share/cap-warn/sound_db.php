<?php
// (c) 2023/2026 KJ5MZL / WRXB288
// la2way.com • lagmrs.com
// All rights reserved. This is not open‑source software.
//
// You may use this software on your personal node.
// If you use it on a HUB, you must provide a link back to me
// in some form (website, dashboard, documentation, etc.).
//
// This software may NOT be modified, redistributed, repackaged,
// or included inside any image without explicit approval
// from KJ5MZL.
//
// Donations are appreciated.
// This software is provided as FreeViewWare.
//
// Software made in loUiSiAna — it's just better.

//
// shared sound processor and file locator module
// automaticaly finds the file and provides its path  Allows use of package
// sound files and can make its on on the fly.
// 
// v2.0  07/27/2023
// v2.1  09/03/2023 ULAW bug fixed 
// v2.3  09/17/2023 fix for missing words and missing files
// v2.4  10/14/2023 if not in wav auto search gsm
// v2.5  01/24/24  Some debugging after new sounds . Error correction added
// v2.6  10/31/24 added date support 
// v2.7  11/25/24  Added dates and protection
// v2.8  2/13/2025 Better database error checking
//------------------------------------------------------------------------------
// v2.9  7/11/2025 Major upgrade. New non database version.  Saves 100k of memory
// v3.1  updated_weather_info,updated weather information
// v3.3 .4
// v3.4 cleanup of old code- major rewrite 
// v3.5 fixed error something in the time was sending 04 so it was throwing error
// v3.5 a  release in cap_warn to speak alerts
// v3.6 6/5/26 adding second option to build a sound file with no key. Moved new sounds into a seperate directory
// v3.7 removing non used code., 

require_once("$pathI/voicerss_tts.php");
//$vpath ="/var/lib/asterisk/sounds";// old non database path


// following is the upgrade functions everything gets redirected to the new routine
// Still  old code using this,
function check_wav_db ($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}
function check_gsm_db ($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}
function check_ulaw_db($in){global $tts,$file1,$datum,$debug,$path;check_sound($in);}

// new function to find a file with no database.
function check_sound($in) {
    global $tts,$file1,$datum,$debug,$path;

if (trim($in) === '') {
 $out="Warning: Sound input was blank.";save_task_log ($out);print"$datum $out\n";
 return false;
}
  $raw_in = $in; // Save original input for logging

    $file1 = ""; // Clear output
    $filePlay = "";
    $cache_file = "/var/log/cap-warn/sound_cache.csv";  
    
     $replacements=[
'january'=>'mon-0','february'=>'mon-1','march'=>'mon-2','april'=>'mon-3','may'=>'mon-4',
'june'=>'mon-5','july'=>'mon-6','august'=>'mon-7','september'=>'mon-8','october'=>'mon-9',
'november'=>'mon-10','december'=>'mon-11',

'sunday'=>'day-0','monday'=>'day-1','tuesday'=>'day-2','wednesday'=>'day-3',
'thursday'=>'day-4','friday'=>'day-5','saturday'=>'day-6',

'am'=>'a-m','pm'=>'p-m',

'nws'=>'national-weather-service',
'warning-bridged'=>'bridged',
'updated-weather-information'=>'updated_weather_info',
'extreme-heat-warning'=>'excessive_heat_warning',
'extreme-heat-watch'=>'excessive_heat_watch',

'strong-click'=>'boop','light-click'=>'boop','star-dull'=>'boop',

'.'=>'dot','`'=>'ascii96','_'=>'ascii95','^'=>'ascii94',']'=>'ascii93','\\'=>'ascii92',
'['=>'ascii91','?'=>'ascii63','>'=>'ascii62','<'=>'ascii60',';'=>'ascii59',':' =>'ascii58',
','=>'comma1','*'=>'ascii42',')'=>'ascii41','('=>'ascii40',"'"=>'ascii39','&'=>'ascii38',
'%'=>'ascii37','$'=>'ascii36','"'=>'ascii34','~'=>'ascii126','}'=>'ascii125','|'=>'ascii124',
'{'=>'ascii123'
];


// Normalize the input:
$lookup = strtolower(trim($in));
$lookup = str_replace(['_', ' '], '-', $lookup); // treat _, space as dash


    if (isset($replacements[$lookup])) {        $lookup = $replacements[$lookup];    }
    $lookup = str_replace(' ', '-', $lookup);
    $variants = [$lookup];
    if (strpos($lookup, '-') !== false) {        $variants[] = str_replace('-', '_', $lookup);    }
    if (strpos($lookup, '_') !== false) {        $variants[] = str_replace('_', '-', $lookup);    }


// Remove duplicates just in case
$variants = array_unique($variants);

$paths = [
 "/usr/share/cap-warn/sounds",
  "/var/lib/cap-warn/sounds",
 "/var/lib/cap-warn/new_sounds",// our new files will go here easer to find new ones
// Asterisk core + extra sounds (from apt packages)
 "/usr/share/asterisk/sounds/en",
   "/usr/share/asterisk/sounds/en/digits",
 "/usr/share/asterisk/sounds/en/letters",
"/usr/share/asterisk/sounds/en/phonetic",
"/usr/share/asterisk/sounds/en/silence",
"/usr/share/asterisk/sounds/en/followme",
"/usr/share/asterisk/sounds/en/dictate",
"/usr/share/asterisk/sounds/en/queue",
"/usr/share/asterisk/sounds/en/confbridge",
// AllStarLink RPT sounds (ASL3)
"/var/lib/asterisk/sounds/rpt",
];


// File extensions to check


    if (file_exists($cache_file)) {
        $handle = fopen($cache_file, "r");
        if ($handle) {
            while (($line = fgetcsv($handle, 0, '|')) !== false) {
                if (strtolower($line[0]) === strtolower($lookup) && file_exists($line[1])) {
                    $file1 = $line[1];
                    fclose($handle);
                    return $file1;
                }
            }
            fclose($handle);
        }
    }



$extensions = ['gsm', 'ul', 'wav', 'ulaw'];
    foreach ($variants as $variant) {
        foreach ($paths as $pathSound) {
            foreach ($extensions as $ext) {
                $filePlay = "$pathSound/$variant.$ext";
                if (file_exists($filePlay)) {
                    $file1 = ($ext === 'ulaw') ? "$pathSound/$variant.ul" : $filePlay;
                    if ($ext === 'ulaw' && !file_exists($file1)) {copy($filePlay, $file1);}
                    file_put_contents($cache_file, "$lookup|$file1\n", FILE_APPEND);
                    return $file1;
                }// end if file exist
            } //for end
        }//for end ext
    }//for end var
    
   $out="$raw_in ($lookup) not found in search";save_task_log ($out);print"$datum $out\n";
    $out="Warning: Input was [$in] with length: " . strlen($in);save_task_log($out);print"$datum $out \n";


$raw_in = str_replace(['_', '-'], ' ', $raw_in); 
// /var/lib/cap-warn/sounds

// safety need to do this firstime
$makeDir = "/var/lib/cap-warn/new_sounds";if (!is_dir($makeDir)) { mkdir($makeDir, 0755, true);}

$makeFile = "/var/lib/cap-warn/new_sounds/$lookup.gsm";
$ttsDir = "/tmp/tts";
$dateTag = date("Ymd_His");  // Example: 20250730_151105
$tmpSound = "$ttsDir/tts_$dateTag.wav";
$tmpSoundUL = "$ttsDir/tts_$dateTag.ul";
// Ensure the directory exists
if (!is_dir($ttsDir)) {
    if (!mkdir($ttsDir, 0777, true)) { $out = "Failed to create TTS directory: $ttsDir"; save_task_log($out); print "$datum $out\n"; add_word($in);return false; }
}


// we will now build a new audio file if we have a key
if($tts ){
$out="Using our tts key to create ($lookup)";save_task_log ($out);print"$datum $out\n";
// Create an instance of the VoiceRSS class
$voiceRSS = new VoiceRSS();
// Define the settings for the speech request
$settings = array(
    'key' => $tts,
    'src' => $raw_in, // Your text here
    'hl' => 'en-us', // Language (English - US)
    'v'  => 'Amy', // Voice (optional)
    'r'  => '0', // Rate (optional)
    'f'  => '8khz_16bit_mono',
    'c'  => 'wav', 
);

// Call the speech function to get the response
$response = $voiceRSS->speech($settings);
// Check if there was an error in the response
if ($response['error']) { echo "Error: " . $response['error'];}
else {
    $mp3Data = $response['response']; // The MP3 binary data
    if (file_put_contents($tmpSound, $mp3Data)) { $out="created $tmpSound ok";save_task_log($out);print"$datum $out \n";} 
   else {$out="failed to create a sound file";save_task_log($out);print"$datum $out \n"; add_word($in); return false;} 
}
}// end tss
 else {
// use asl tts
    print "$datum Building sound $raw_in asl-tts \n";
    $specialUL_noext = preg_replace('/\.ul$/', '', $tmpSoundUL);
    $cmd = "asl-tts -n $node -t " . escapeshellarg($raw_in) . " -f " . escapeshellarg($specialUL_noext);
    exec($cmd, $output, $return);

    if ($return === 0) {echo "$datum $tmpSound generated via asl-tts\n";}
  else { $out="ERROR: asl-tts failed to generate audio";save_task_log ($out);print "$datum $out\n";}
}
 
$file="";
if(file_exists($tmpSound)){ $file=$tmpSound;}
if(file_exists($tmpSoundUL)){ $file=$tmpSoundUL;}

if(file_exists($file)){
exec("sox -V $file -r 8000 -c 1 -t gsm $makeFile",$output,$return_var); 
   if (file_exists($makeFile)){  $out="created:$makeFile ";save_task_log($out);print"$datum $out \n";}
   else {  $out="Can Not Create:$makeFile ";save_task_log($out);print"$datum $out \n";}
    $file1=$makeFile;sleep(2);if (file_exists($file)){unlink($file);}
    return $file1;
}
// else {  add_word($in);  return false;} // old code from node manager


}






// v4 cleaned to handel all the numbers not 1 to 1000 
function make_number($in) {
    global $datum, $vpath, $debug, $oh, $actionOut;
//  $vpath = "/var/lib/asterisk/sounds/digits";  // The old hamvoip paths
    $vpath= "/usr/share/asterisk/sounds/en/digits";
    $actionOut= ""; $in=intval($in);$input=$in;$files=[];
    if ($in < 0) {$files[]="$vpath/minus.gsm";$in=abs($in);}
    if ($in >= 1000) {
        $thousands = floor($in / 1000);
        if ($thousands > 0) {$files[]="$vpath/$thousands.gsm";$files[]="$vpath/thousand.gsm";}
        $in %= 1000;
    }
    if ($in >= 100) {
        $hundreds = floor($in / 100);
        if ($hundreds > 0) {$files[]="$vpath/$hundreds.gsm";$files[]="$vpath/hundred.gsm";}
        $in %= 100;
    }
    if ($in >= 20) {$tens = floor($in / 10) * 10;$files[]="$vpath/$tens.gsm";$in %= 10;}
    if ($in > 0) {
       if ($oh && $in < 10 && empty($files)) {$files[]="$vpath/oh.gsm";}
       $files[]="$vpath/$in.gsm";
    }
    if (empty($files)) {$files[]="$vpath/0.gsm";}
    $actionOut=implode(" ", $files);
    if ($debug){print "$datum DEBUG: in:$input $actionOut\n";}
    return $actionOut;
}



// v3 
// Makes a proper day of the week string
function make_date_number($in){
global $datum,$debug,$actionOut;
$vpath="/usr/share/asterisk/sounds/en/digits";
$actionOut="";$in=abs(round($in));$input=$in;

$special=[
1=>"h-1.gsm",2=>"h-2.gsm",3=>"h-3.gsm",5=>"h-5.gsm",
8=>"h-8.gsm",9=>"h-9.gsm",12=>"h-12.gsm",
20=>"h-20.gsm",30=>"h-30.gsm"
];

if(isset($special[$in])) $actionOut="$vpath/".$special[$in];
elseif($in>=21&&$in<=29) $actionOut="$vpath/20.gsm $vpath/h-".($in-20).".gsm";
elseif($in>=31&&$in<=32) $actionOut="$vpath/30.gsm $vpath/h-".($in-30).".gsm";
else $actionOut="$vpath/h-$in.gsm";

if($debug) print"$datum DEBUG: in:$input $actionOut\n";
}


// Removing we dont need this on cap-warn was for node manager
// This keeps track of words not in the database
// 
//function add_word($in){
//    global $datum, $path, $fileplay, $file1, $debug;
//
//      $file = "/var/log/cap-warn/words_to_add.log";
//    $save = true;
//    if (is_readable($file)) {
//        $fileIN1=file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
//        if ($fileIN1===false) { save_task_log ("$datum ERROR: Failed to read $file");}
//        if (in_array(trim($in), $fileIN1, true)) { $save = false; }
//    }// end if readable
//
//    if ($save) {
//        $fileOUT = fopen($file, 'a+');
//        if (!$fileOUT) {  save_task_log ("$datum ERROR: Failed to open $file for writing");}
//        if (flock($fileOUT, LOCK_EX)) {$write_result=fwrite($fileOUT, "$in\n");flock($fileOUT, LOCK_UN);} 
//        else {save_task_log ("$datum ERROR: Could not lock $file for writing");}
//
//        fclose($fileOUT);

        // Verify
//    if ($write_result===false){save_task_log ("$datum ERROR: Failed to write to $file");}
//    else{print "$datum Adding [$in] to the missing sounds list\n";}
//    }//end save

//if ($debug){print "$datum DEBUG: in:$in is not in the database\n"; }
//}


?>
